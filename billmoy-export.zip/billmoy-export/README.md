# Billmoy - Programa de Facturación

## Estructura del proyecto

```
billmoy-export/
├── dist/                  # Aplicación compilada (lista para producción)
│   ├── index.cjs          # Servidor Express (backend)
│   └── public/            # Frontend React compilado
├── src/                   # Código fuente completo (para desarrollo)
│   ├── client/            # Frontend React + Tailwind + shadcn/ui
│   ├── server/            # Backend Express
│   ├── shared/            # Esquemas compartidos (Drizzle/Zod)
│   └── attached_assets/   # Logos e imágenes
├── package.json           # Dependencias
├── Dockerfile             # Para despliegue con Docker
├── docker-compose.yml     # Docker Compose
└── .env.example           # Variables de entorno
```

## Despliegue rápido (producción)

### Opción 1: Node.js directo

```bash
# 1. Instalar dependencias
npm install --omit=dev

# 2. Iniciar servidor
NODE_ENV=production PORT=5000 node dist/index.cjs
```

La app estará en `http://tu-servidor:5000`

### Opción 2: Docker

```bash
# Construir y arrancar
docker-compose up -d

# O manualmente
docker build -t billmoy .
docker run -d -p 5000:5000 --name billmoy billmoy
```

### Opción 3: VPS (Ubuntu/Debian) con PM2

```bash
# 1. Instalar Node.js 20+
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

# 2. Instalar PM2 (gestor de procesos)
sudo npm install -g pm2

# 3. Subir los archivos al servidor (dist/, package.json, package-lock.json)

# 4. Instalar dependencias
npm install --omit=dev

# 5. Iniciar con PM2
pm2 start dist/index.cjs --name billmoy --env NODE_ENV=production

# 6. Auto-arranque con el sistema
pm2 save
pm2 startup
```

### Opción 4: Railway / Render / Fly.io

Sube el repositorio y configura:
- **Build command**: (no hace falta, ya está compilado)
- **Start command**: `node dist/index.cjs`
- **Puerto**: `5000` (o variable `PORT`)

## Configurar Nginx como proxy inverso (recomendado)

```nginx
server {
    listen 80;
    server_name tu-dominio.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Para SSL con Certbot:
```bash
sudo apt install certbot python3-certbot-nginx
sudo certbot --nginx -d tu-dominio.com
```

## Desarrollo local

Para modificar el código fuente:

```bash
# 1. Copiar src/ al directorio raíz
cp -r src/* .

# 2. Instalar TODAS las dependencias (dev + prod)
npm install

# 3. Iniciar servidor de desarrollo (hot reload)
npm run dev

# 4. Cuando termines, compilar para producción
npm run build
```

## Notas técnicas

- **Storage**: Actualmente usa almacenamiento en memoria (MemStorage). Los datos se reinician al reiniciar el servidor. Para persistencia, conectar una base de datos PostgreSQL.
- **Puerto**: Por defecto `5000`. Cambiar con variable `PORT`.
- **API**: Todas las rutas API están en `/api/*`
- **Frontend**: SPA React con hash routing (`/#/ruta`)
- **Node.js**: Requiere v18+ (recomendado v20+)

## Stack tecnológico

- Frontend: React 19, Tailwind CSS 3, shadcn/ui, @dnd-kit, Wouter
- Backend: Express 4, Drizzle ORM
- Fuentes: Catamaran (incluidas en `/dist/public/fonts/`)
