import { pgTable, text, serial, integer, boolean, numeric, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// ── Users ──
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
});
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// ── Brand Settings ──
export const brandSettings = pgTable("brand_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  logoUrl: text("logo_url"),
  primaryColor: text("primary_color").default("#3F4694"),
  accentColor: text("accent_color").default("#F25075"),
  backgroundColor: text("background_color").default("#FBFBFB"),
  fontFamily: text("font_family").default("Catamaran"),
  defaultOrientation: text("default_orientation").default("portrait"),
  companyName: text("company_name"),
  taxId: text("tax_id"),
  address: text("address"),
  city: text("city"),
  province: text("province"),
  country: text("country").default("España"),
  zipCode: text("zip_code"),
  phone: text("phone"),
});
export const insertBrandSettingsSchema = createInsertSchema(brandSettings).omit({ id: true });
export type InsertBrandSettings = z.infer<typeof insertBrandSettingsSchema>;
export type BrandSettings = typeof brandSettings.$inferSelect;

// ── Clients ──
export const clients = pgTable("clients", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  taxId: text("tax_id"),
  address: text("address"),
  city: text("city"),
  province: text("province"),
  country: text("country").default("España"),
  zipCode: text("zip_code"),
  phone: text("phone"),
  email: text("email"),
  sector: text("sector"),
  notes: text("notes"),
  imageUrl: text("image_url"),
});
export const insertClientSchema = createInsertSchema(clients).omit({ id: true });
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

// ── Products / Services ──
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  basePrice: numeric("base_price", { precision: 10, scale: 2 }).notNull(),
  taxRate: numeric("tax_rate", { precision: 5, scale: 2 }).default("21"),
  category: text("category"),
  isService: boolean("is_service").default(true),
});
export const insertProductSchema = createInsertSchema(products).omit({ id: true });
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;

// ── Portfolio Items ──
export const portfolioItems = pgTable("portfolio_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category"),
  imageUrl: text("image_url"),
  externalLink: text("external_link"),
});
export const insertPortfolioItemSchema = createInsertSchema(portfolioItems).omit({ id: true });
export type InsertPortfolioItem = z.infer<typeof insertPortfolioItemSchema>;
export type PortfolioItem = typeof portfolioItems.$inferSelect;

// ── Contract Templates ──
export const contractTemplates = pgTable("contract_templates", {
  id: serial("id").primaryKey(),
  userId: integer("user_id"),
  name: text("name").notNull(),
  type: text("type").notNull().default("system"),
  body: text("body").notNull(),
});
export const insertContractTemplateSchema = createInsertSchema(contractTemplates).omit({ id: true });
export type InsertContractTemplate = z.infer<typeof insertContractTemplateSchema>;
export type ContractTemplate = typeof contractTemplates.$inferSelect;

// ── Documents (invoices, quotes, quote_max) ──
export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  clientId: integer("client_id"),
  type: text("type").notNull(), // "invoice", "quote_normal", "quote_max"
  number: text("number"),
  series: text("series"),
  issueDate: text("issue_date"),
  dueDate: text("due_date"),
  status: text("status").notNull().default("draft"), // "draft","sent","accepted","rejected","paid","partial"
  currency: text("currency").default("EUR"),
  subtotal: numeric("subtotal", { precision: 10, scale: 2 }).default("0"),
  taxTotal: numeric("tax_total", { precision: 10, scale: 2 }).default("0"),
  total: numeric("total", { precision: 10, scale: 2 }).default("0"),
  notes: text("notes"),
  relatedDocumentId: integer("related_document_id"),
});
export const insertDocumentSchema = createInsertSchema(documents).omit({ id: true });
export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;

// ── Document Line Items ──
export const documentLineItems = pgTable("document_line_items", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  productId: integer("product_id"),
  description: text("description").notNull(),
  quantity: numeric("quantity", { precision: 10, scale: 2 }).default("1"),
  unitPrice: numeric("unit_price", { precision: 10, scale: 2 }).notNull(),
  taxRate: numeric("tax_rate", { precision: 5, scale: 2 }).default("21"),
  lineTotal: numeric("line_total", { precision: 10, scale: 2 }).notNull(),
});
export const insertDocumentLineItemSchema = createInsertSchema(documentLineItems).omit({ id: true });
export type InsertDocumentLineItem = z.infer<typeof insertDocumentLineItemSchema>;
export type DocumentLineItem = typeof documentLineItems.$inferSelect;

// ── Max Document Pages ──
export const maxDocumentPages = pgTable("max_document_pages", {
  id: serial("id").primaryKey(),
  documentId: integer("document_id").notNull(),
  pageNumber: integer("page_number").notNull(),
  pageType: text("page_type").notNull().default("blank"), // "cover","intro","process","services","portfolio","pricing","contract","testimonials","closing","blank"
  orientation: text("orientation").default("portrait"),
});
export const insertMaxDocumentPageSchema = createInsertSchema(maxDocumentPages).omit({ id: true });
export type InsertMaxDocumentPage = z.infer<typeof insertMaxDocumentPageSchema>;
export type MaxDocumentPage = typeof maxDocumentPages.$inferSelect;

// ── Max Blocks ──
export const maxBlocks = pgTable("max_blocks", {
  id: serial("id").primaryKey(),
  pageId: integer("page_id").notNull(),
  blockType: text("block_type").notNull(), // "cover","text","process","services","pricing","portfolio","testimonial","contract","closing","basic_heading","basic_paragraph","basic_image","basic_button","basic_separator","basic_space","basic_social_icons"
  position: integer("position").notNull().default(0),
  data: jsonb("data").default({}),
});
export const insertMaxBlockSchema = createInsertSchema(maxBlocks).omit({ id: true });
export type InsertMaxBlock = z.infer<typeof insertMaxBlockSchema>;
export type MaxBlock = typeof maxBlocks.$inferSelect;

// ── Expenses ──
export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  provider: text("provider").notNull(),
  date: text("date"),
  category: text("category"),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  taxAmount: numeric("tax_amount", { precision: 10, scale: 2 }).default("0"),
  status: text("status").default("pending"),
  notes: text("notes"),
});
export const insertExpenseSchema = createInsertSchema(expenses).omit({ id: true });
export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;
