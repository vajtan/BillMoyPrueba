import { Switch, Route, Router, Link, useLocation } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { AppSidebar } from "@/components/app-sidebar";
import { PerplexityAttribution } from "@/components/PerplexityAttribution";
import Dashboard from "@/pages/dashboard";
import Facturas from "@/pages/facturas";
import FacturaEditor from "@/pages/factura-editor";
import Presupuestos from "@/pages/presupuestos";
import PresupuestoEditor from "@/pages/presupuesto-editor";
import PresupuestoMaxEditor from "@/pages/presupuesto-max-editor";
import Contactos from "@/pages/contactos";
import ContactoForm from "@/pages/contacto-form";
import Productos from "@/pages/productos";
import Gastos from "@/pages/gastos";
import Contratos from "@/pages/contratos";
import Portfolio from "@/pages/portfolio";
import Ajustes from "@/pages/ajustes";
import AuthPage from "@/pages/auth";
import NotFound from "@/pages/not-found";
import { useState, useRef, useEffect } from "react";
import { Bell, Settings, User, LogOut } from "lucide-react";

function UserMenu() {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const [, navigate] = useLocation();

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={() => setOpen(!open)}
        className="w-9 h-9 rounded-full bg-[#3F4694] text-white flex items-center justify-center text-sm font-semibold hover:bg-[#2e3570] transition-colors cursor-pointer"
        data-testid="avatar-user"
      >
        D
      </button>
      {open && (
        <div className="absolute right-0 top-full mt-2 z-50 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden min-w-[200px] animate-in fade-in slide-in-from-top-1 duration-150">
          <div className="px-4 py-3 border-b border-gray-100">
            <p className="text-sm font-semibold text-gray-700">Demo Studio</p>
            <p className="text-xs text-gray-400">demo@billmoy.com</p>
          </div>
          <div className="py-1">
            <button
              onClick={() => { navigate("/ajustes"); setOpen(false); }}
              className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-gray-600 hover:text-[#3F4694] hover:bg-[#3F4694]/5 transition-colors"
              data-testid="menu-settings"
            >
              <Settings className="w-4 h-4" />
              Ajustes de empresa
            </button>
            <button
              onClick={() => { navigate("/ajustes"); setOpen(false); }}
              className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-gray-600 hover:text-[#3F4694] hover:bg-[#3F4694]/5 transition-colors"
              data-testid="menu-profile"
            >
              <User className="w-4 h-4" />
              Mi perfil
            </button>
            <div className="border-t border-gray-100 mt-1 pt-1">
              <button
                className="flex items-center gap-3 w-full px-4 py-2.5 text-sm text-gray-600 hover:text-red-600 hover:bg-red-50 transition-colors"
                data-testid="menu-logout"
              >
                <LogOut className="w-4 h-4" />
                Cerrar sesión
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function AppLayout() {
  return (
    <div className="flex h-screen w-full bg-[#FBFBFB]">
      <AppSidebar />
      <div className="flex flex-col flex-1 overflow-hidden">
        <header className="flex items-center justify-end gap-3 px-6 py-3 bg-white border-b border-border">
          <button
            className="relative p-2 text-gray-400 hover:text-[#3F4694] transition-colors"
            data-testid="button-notifications"
          >
            <Bell className="w-5 h-5" />
          </button>
          <UserMenu />
        </header>
        <main className="flex-1 overflow-auto">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/facturas" component={Facturas} />
            <Route path="/facturas/nueva" component={FacturaEditor} />
            <Route path="/facturas/:id" component={FacturaEditor} />
            <Route path="/presupuestos" component={Presupuestos} />
            <Route path="/presupuestos/nuevo" component={PresupuestoEditor} />
            <Route path="/presupuestos/max/nuevo" component={PresupuestoMaxEditor} />
            <Route path="/presupuestos/max/:id" component={PresupuestoMaxEditor} />
            <Route path="/presupuestos/:id" component={PresupuestoEditor} />
            <Route path="/contactos" component={Contactos} />
            <Route path="/contactos/nuevo" component={ContactoForm} />
            <Route path="/contactos/:id" component={ContactoForm} />
            <Route path="/productos" component={Productos} />
            <Route path="/gastos" component={Gastos} />
            <Route path="/contratos" component={Contratos} />
            <Route path="/proyectos" component={Portfolio} />
            <Route path="/ajustes" component={Ajustes} />
            <Route component={NotFound} />
          </Switch>
        </main>
        <PerplexityAttribution />
      </div>
    </div>
  );
}

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(true);

  if (!isAuthenticated) {
    return (
      <QueryClientProvider client={queryClient}>
        <Router hook={useHashLocation}>
          <AuthPage onLogin={() => setIsAuthenticated(true)} />
        </Router>
        <Toaster />
      </QueryClientProvider>
    );
  }

  return (
    <QueryClientProvider client={queryClient}>
      <Router hook={useHashLocation}>
        <AppLayout />
      </Router>
      <Toaster />
    </QueryClientProvider>
  );
}
