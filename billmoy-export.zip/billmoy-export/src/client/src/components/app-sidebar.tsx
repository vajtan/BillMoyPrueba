import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  FileText,
  ClipboardList,
  Users,
  Package,
  ArrowUpCircle,
  ScrollText,
  FolderOpen,
  Settings,
} from "lucide-react";
import logoBlueSrc from "@assets/logo-blue.png";

const navItems = [
  { title: "General", href: "/", icon: LayoutDashboard },
  { title: "Facturas", href: "/facturas", icon: FileText },
  { title: "Presupuestos", href: "/presupuestos", icon: ClipboardList },
  { title: "Contactos", href: "/contactos", icon: Users },
  { title: "Productos", href: "/productos", icon: Package },
  { title: "Gastos", href: "/gastos", icon: ArrowUpCircle },
  { title: "Contratos", href: "/contratos", icon: ScrollText },
  { title: "Proyectos", href: "/proyectos", icon: FolderOpen },
];

const bottomItems = [
  { title: "Ajustes", href: "/ajustes", icon: Settings },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-[180px] min-w-[180px] bg-white border-r border-border flex flex-col h-screen sticky top-0">
      <div className="p-5 pb-6">
        <img
          src={logoBlueSrc}
          alt="Billmoy"
          className="h-7 w-auto"
          data-testid="text-logo"
        />
      </div>
      <nav className="flex-1 px-3">
        {navItems.map((item) => {
          const isActive =
            item.href === "/"
              ? location === "/"
              : location.startsWith(item.href);
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md mb-0.5 text-sm cursor-pointer transition-colors ${
                  isActive
                    ? "text-[#3F4694] font-semibold bg-[#3F4694]/5"
                    : "text-gray-500 hover:text-[#3F4694] hover:bg-gray-50"
                }`}
                data-testid={`nav-${item.title.toLowerCase()}`}
              >
                <item.icon className="w-[18px] h-[18px]" />
                <span>{item.title}</span>
              </div>
            </Link>
          );
        })}
      </nav>
      <div className="px-3 pb-4 border-t border-gray-100 pt-2">
        {bottomItems.map((item) => {
          const isActive = location.startsWith(item.href);
          return (
            <Link key={item.href} href={item.href}>
              <div
                className={`flex items-center gap-3 px-3 py-2.5 rounded-md mb-0.5 text-sm cursor-pointer transition-colors ${
                  isActive
                    ? "text-[#3F4694] font-semibold bg-[#3F4694]/5"
                    : "text-gray-500 hover:text-[#3F4694] hover:bg-gray-50"
                }`}
                data-testid={`nav-${item.title.toLowerCase()}`}
              >
                <item.icon className="w-[18px] h-[18px]" />
                <span>{item.title}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </aside>
  );
}
