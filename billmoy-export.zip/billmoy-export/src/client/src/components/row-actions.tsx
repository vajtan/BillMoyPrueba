import { useState, useRef, useEffect } from "react";
import { MoreHorizontal, Pencil, Copy, Trash2, PauseCircle, FileText, Eye } from "lucide-react";

export interface RowAction {
  icon: typeof Pencil;
  label: string;
  onClick: () => void;
  variant?: "default" | "danger" | "accent";
}

interface RowActionsProps {
  actions: RowAction[];
}

export function RowActions({ actions }: RowActionsProps) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    if (open) document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, [open]);

  const variantStyles: Record<string, string> = {
    default: "text-gray-600 hover:text-[#3F4694] hover:bg-[#3F4694]/5",
    danger: "text-gray-600 hover:text-red-600 hover:bg-red-50",
    accent: "text-gray-600 hover:text-[#F25075] hover:bg-[#F25075]/5",
  };

  return (
    <div className="relative" ref={ref}>
      <button
        onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
        className="p-1 rounded hover:bg-gray-100 transition-colors"
        data-testid="button-row-actions"
      >
        <MoreHorizontal className="w-4 h-4 text-gray-400" />
      </button>

      {open && (
        <div
          className="absolute right-0 top-full mt-1 z-50 bg-white rounded-lg shadow-lg border border-gray-200 overflow-hidden min-w-[200px] animate-in fade-in slide-in-from-top-1 duration-150"
          data-testid="menu-row-actions"
        >
          <div className="flex flex-col py-1">
            {actions.map((action, i) => (
              <button
                key={i}
                onClick={(e) => { e.stopPropagation(); action.onClick(); setOpen(false); }}
                className={`flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${variantStyles[action.variant || "default"]}`}
                data-testid={`action-${action.label.toLowerCase().replace(/\s/g, "-")}`}
              >
                <action.icon className="w-4 h-4 flex-shrink-0" />
                <span>{action.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// Pre-built action sets for common use cases
export function useDocumentActions(opts: {
  onEdit: () => void;
  onDuplicate: () => void;
  onDelete: () => void;
  onArchive: () => void;
  onView?: () => void;
  onConvert?: () => void;
}): RowAction[] {
  const actions: RowAction[] = [];
  if (opts.onView) {
    actions.push({ icon: Eye, label: "Ver", onClick: opts.onView });
  }
  actions.push({ icon: Pencil, label: "Editar", onClick: opts.onEdit });
  actions.push({ icon: Copy, label: "Duplicar", onClick: opts.onDuplicate });
  if (opts.onConvert) {
    actions.push({ icon: FileText, label: "Convertir a factura", onClick: opts.onConvert, variant: "accent" });
  }
  actions.push({ icon: PauseCircle, label: "Archivar", onClick: opts.onArchive });
  actions.push({ icon: Trash2, label: "Eliminar", onClick: opts.onDelete, variant: "danger" });
  return actions;
}

export function useEntityActions(opts: {
  onEdit: () => void;
  onDuplicate?: () => void;
  onDelete: () => void;
}): RowAction[] {
  const actions: RowAction[] = [
    { icon: Pencil, label: "Editar", onClick: opts.onEdit },
  ];
  if (opts.onDuplicate) {
    actions.push({ icon: Copy, label: "Duplicar", onClick: opts.onDuplicate });
  }
  actions.push({ icon: Trash2, label: "Eliminar", onClick: opts.onDelete, variant: "danger" });
  return actions;
}
