import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, Plus, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import type { Product } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { RowActions, useEntityActions } from "@/components/row-actions";
import { useToast } from "@/hooks/use-toast";

export default function Productos() {
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ name: "", description: "", basePrice: "", taxRate: "21", category: "", isService: true });
  const { toast } = useToast();

  const { data: products = [] } = useQuery<Product[]>({ queryKey: ["/api/products"] });

  const filtered = products.filter((p) =>
    search ? p.name.toLowerCase().includes(search.toLowerCase()) || (p.category || "").toLowerCase().includes(search.toLowerCase()) : true
  );

  const resetForm = () => {
    setFormData({ name: "", description: "", basePrice: "", taxRate: "21", category: "", isService: true });
    setEditingId(null);
  };

  const handleCreate = async () => {
    if (editingId) {
      await apiRequest("PATCH", `/api/products/${editingId}`, formData);
      toast({ title: "Producto actualizado" });
    } else {
      await apiRequest("POST", "/api/products", { ...formData, userId: 1 });
      toast({ title: "Producto creado" });
    }
    queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    setShowForm(false);
    resetForm();
  };

  const handleEdit = (product: Product) => {
    setFormData({
      name: product.name,
      description: product.description || "",
      basePrice: String(product.basePrice),
      taxRate: String(product.taxRate || "21"),
      category: product.category || "",
      isService: product.isService ?? true,
    });
    setEditingId(product.id);
    setShowForm(true);
  };

  const handleDuplicate = async (product: Product) => {
    await apiRequest("POST", "/api/products", {
      userId: product.userId,
      name: `${product.name} (copia)`,
      description: product.description,
      basePrice: product.basePrice,
      taxRate: product.taxRate,
      category: product.category,
      isService: product.isService,
    });
    queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    toast({ title: "Producto duplicado" });
  };

  const handleDelete = async (id: number) => {
    await apiRequest("DELETE", `/api/products/${id}`);
    queryClient.invalidateQueries({ queryKey: ["/api/products"] });
    toast({ title: "Producto eliminado" });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }} data-testid="text-page-title">
        Productos / Servicios
      </h1>

      <div className="flex items-center justify-between mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input placeholder="Buscar..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-3 py-1.5 text-sm border rounded-md w-60" data-testid="input-search" />
        </div>
        <Dialog open={showForm} onOpenChange={(open) => { setShowForm(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="bg-[#F25075] hover:bg-[#d9446a] text-white text-sm" data-testid="button-create-product">
              <Plus className="w-4 h-4 mr-1" /> Crear producto
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingId ? "Editar producto / servicio" : "Nuevo producto / servicio"}</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder="Nombre" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} data-testid="input-product-name" />
              <Input placeholder="Descripción" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="Precio base" value={formData.basePrice} onChange={(e) => setFormData({ ...formData, basePrice: e.target.value })} data-testid="input-product-price" />
                <Input placeholder="IVA %" value={formData.taxRate} onChange={(e) => setFormData({ ...formData, taxRate: e.target.value })} />
              </div>
              <Input placeholder="Categoría" value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} />
              <div className="flex items-center gap-3">
                <label className="text-sm text-gray-600">Tipo:</label>
                <button
                  onClick={() => setFormData({ ...formData, isService: true })}
                  className={`px-3 py-1.5 text-xs rounded-md border transition-colors ${formData.isService ? "bg-[#3F4694] text-white border-[#3F4694]" : "text-gray-500 border-gray-300"}`}
                >
                  Servicio
                </button>
                <button
                  onClick={() => setFormData({ ...formData, isService: false })}
                  className={`px-3 py-1.5 text-xs rounded-md border transition-colors ${!formData.isService ? "bg-[#3F4694] text-white border-[#3F4694]" : "text-gray-500 border-gray-300"}`}
                >
                  Producto
                </button>
              </div>
              <Button onClick={handleCreate} className="w-full bg-[#F25075] hover:bg-[#d9446a] text-white" data-testid="button-save-product">
                {editingId ? "Actualizar" : "Guardar"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-100">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b text-gray-400 text-left">
              <th className="px-5 py-3 font-medium">Nombre</th>
              <th className="px-3 py-3 font-medium">Tipo</th>
              <th className="px-3 py-3 font-medium">Precio base</th>
              <th className="px-3 py-3 font-medium">Impuestos</th>
              <th className="px-3 py-3 font-medium">Categoría</th>
              <th className="px-3 py-3 w-12"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="px-5 py-12 text-center">
                  <AlertCircle className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-400">No hay productos todavía.</p>
                </td>
              </tr>
            )}
            {filtered.map((product) => (
              <tr key={product.id} className="border-b border-gray-50 hover:bg-gray-50/50" data-testid={`row-product-${product.id}`}>
                <td className="px-5 py-3 text-gray-700 font-medium">{product.name}</td>
                <td className="px-3 py-3 text-gray-600">
                  <span className={`inline-block px-2 py-0.5 rounded-full text-xs ${product.isService ? "bg-blue-50 text-blue-600" : "bg-green-50 text-green-600"}`}>
                    {product.isService ? "Servicio" : "Producto"}
                  </span>
                </td>
                <td className="px-3 py-3 text-gray-700 font-semibold">{Number(product.basePrice).toLocaleString("es-ES", { minimumFractionDigits: 2 })} €</td>
                <td className="px-3 py-3 text-gray-600">{product.taxRate}%</td>
                <td className="px-3 py-3 text-gray-600">{product.category || "—"}</td>
                <td className="px-3 py-3">
                  <RowActions
                    actions={useEntityActions({
                      onEdit: () => handleEdit(product),
                      onDuplicate: () => handleDuplicate(product),
                      onDelete: () => handleDelete(product.id),
                    })}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length > 0 && (
          <div className="flex items-center px-5 py-3 text-sm text-gray-400 border-t border-gray-50">
            <span>{filtered.length} producto{filtered.length !== 1 ? "s" : ""}</span>
          </div>
        )}
      </div>
    </div>
  );
}
