import { useState, useEffect } from "react";
import { Link, useLocation, useRoute } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, Plus, Search, ChevronDown, Trash2, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import type { Client, Product, BrandSettings } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface LineItem {
  id: number;
  description: string;
  quantity: string;
  price: string;
  taxRate: string;
  total: string;
  productId?: number;
}

export default function FacturaEditor() {
  const [, navigate] = useLocation();
  const [match, params] = useRoute("/facturas/:id");
  const editId = match && params?.id !== "nueva" ? Number(params.id) : null;
  const { toast } = useToast();

  // Data queries
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: products = [] } = useQuery<Product[]>({ queryKey: ["/api/products"] });
  const { data: brand } = useQuery<BrandSettings | null>({ queryKey: ["/api/brand-settings", "1"] });
  const { data: existingDoc } = useQuery<any>({
    queryKey: ["/api/documents", editId],
    enabled: !!editId,
  });

  // Form state
  const [selectedClientId, setSelectedClientId] = useState<number | null>(null);
  const [clientDropdown, setClientDropdown] = useState(false);
  const [issueDate, setIssueDate] = useState(new Date().toISOString().split("T")[0]);
  const [dueDate, setDueDate] = useState("");
  const [invoiceNumber, setInvoiceNumber] = useState("");
  const [notes, setNotes] = useState("");
  const [status, setStatus] = useState("draft");
  const [lines, setLines] = useState<LineItem[]>([
    { id: 1, description: "", quantity: "1", price: "0", taxRate: "21", total: "0" },
  ]);
  const [productSearch, setProductSearch] = useState<number | null>(null);

  // Load existing doc
  useEffect(() => {
    if (existingDoc) {
      setSelectedClientId(existingDoc.clientId);
      setIssueDate(existingDoc.issueDate || "");
      setDueDate(existingDoc.dueDate || "");
      setInvoiceNumber(existingDoc.number || "");
      setNotes(existingDoc.notes || "");
      setStatus(existingDoc.status || "draft");
    }
  }, [existingDoc]);

  const selectedClient = clients.find((c) => c.id === selectedClientId);

  const addLine = () => {
    setLines([...lines, { id: Date.now(), description: "", quantity: "1", price: "0", taxRate: "21", total: "0" }]);
  };

  const removeLine = (idx: number) => {
    if (lines.length <= 1) return;
    setLines(lines.filter((_, i) => i !== idx));
  };

  const updateLine = (idx: number, field: string, value: string) => {
    const updated = [...lines];
    (updated[idx] as any)[field] = value;
    const qty = parseFloat(updated[idx].quantity) || 0;
    const price = parseFloat(updated[idx].price) || 0;
    updated[idx].total = (qty * price).toFixed(2);
    setLines(updated);
  };

  const selectProduct = (idx: number, product: Product) => {
    const updated = [...lines];
    updated[idx] = {
      ...updated[idx],
      description: product.name,
      price: String(product.basePrice),
      taxRate: String(product.taxRate || "21"),
      productId: product.id,
    };
    const qty = parseFloat(updated[idx].quantity) || 0;
    const price = parseFloat(updated[idx].price) || 0;
    updated[idx].total = (qty * price).toFixed(2);
    setLines(updated);
    setProductSearch(null);
  };

  const subtotal = lines.reduce((sum, l) => sum + (parseFloat(l.total) || 0), 0);
  const taxByRate = lines.reduce<Record<string, number>>((acc, l) => {
    const rate = l.taxRate || "21";
    const lineTotal = parseFloat(l.total) || 0;
    acc[rate] = (acc[rate] || 0) + lineTotal * (parseFloat(rate) / 100);
    return acc;
  }, {});
  const totalTax = Object.values(taxByRate).reduce((a, b) => a + b, 0);
  const total = subtotal + totalTax;

  const saveDocument = async (newStatus: string) => {
    const payload = {
      userId: 1,
      clientId: selectedClientId,
      type: "invoice" as const,
      number: invoiceNumber || `FAC-${String(Date.now()).slice(-4)}`,
      issueDate,
      dueDate,
      status: newStatus,
      currency: "EUR",
      subtotal: subtotal.toFixed(2),
      taxTotal: totalTax.toFixed(2),
      total: total.toFixed(2),
      notes,
    };

    if (editId) {
      await apiRequest("PATCH", `/api/documents/${editId}`, payload);
    } else {
      await apiRequest("POST", "/api/documents", payload);
    }

    queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    toast({
      title: newStatus === "draft" ? "Borrador guardado" : "Factura emitida",
      description: newStatus === "sent" ? "La factura se ha marcado como emitida." : undefined,
    });

    if (newStatus !== "draft") navigate("/facturas");
  };

  const statusBanners: Record<string, { bg: string; title: string; desc: string }> = {
    draft: { bg: "bg-gray-50 border-gray-200", title: "Borrador", desc: "Todavía no has terminado esta factura. Prueba a emitirla." },
    sent: { bg: "bg-blue-50 border-blue-200", title: "Emitida", desc: "Esta factura ha sido emitida al cliente. Pendiente de cobro." },
    paid: { bg: "bg-green-50 border-green-200", title: "Cobrada", desc: "Esta factura ha sido cobrada correctamente." },
    partial: { bg: "bg-orange-50 border-orange-200", title: "Pago parcial", desc: "Se ha recibido un pago parcial por esta factura." },
  };

  const banner = statusBanners[status] || statusBanners.draft;

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }}>
        {editId ? "Editar factura" : "Nueva factura"}
      </h1>

      {/* Top bar */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <Link href="/facturas">
            <span className="text-sm text-[#3F4694] font-semibold cursor-pointer flex items-center gap-1" data-testid="link-back">
              <ArrowLeft className="w-4 h-4" /> Volver
            </span>
          </Link>
          <Button variant="outline" className="text-sm h-9 border-gray-300" onClick={() => saveDocument("draft")} data-testid="button-save-draft">
            Guardar borrador
          </Button>
        </div>
        <div className="flex gap-2">
          {status === "draft" && (
            <Button variant="outline" className="text-sm h-9 border-[#3F4694] text-[#3F4694]" onClick={() => saveDocument("sent")} data-testid="button-emit">
              Emitir
            </Button>
          )}
          {status === "sent" && (
            <Button variant="outline" className="text-sm h-9 border-green-600 text-green-600" onClick={() => saveDocument("paid")} data-testid="button-mark-paid">
              Marcar como cobrada
            </Button>
          )}
          <Button className="text-sm h-9 bg-[#F25075] hover:bg-[#d9446a] text-white" onClick={() => saveDocument("sent")} data-testid="button-emit-send">
            Emitir y enviar
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_260px] gap-6">
        {/* Document canvas */}
        <div>
          {/* Status banner */}
          <div className={`rounded-lg p-4 mb-4 border ${banner.bg}`}>
            <p className="text-sm font-bold text-gray-700">{banner.title}</p>
            <p className="text-xs text-gray-500">{banner.desc}</p>
          </div>

          {/* A4 canvas */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 min-h-[700px]">
            {/* Header: logo + company + client */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="border border-dashed border-gray-300 rounded-lg p-6 flex items-center justify-center text-gray-400 text-sm cursor-pointer hover:border-[#3F4694]/30">
                <Plus className="w-5 h-5 mr-1" /> Añade tu logo
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Tus datos de facturación:</p>
                <p className="text-sm font-semibold text-gray-700">{brand?.companyName || "Tu empresa"}</p>
                <p className="text-xs text-gray-500">{brand?.taxId || ""}</p>
                <p className="text-xs text-gray-400 mt-1">{brand?.address || ""}</p>
                <p className="text-xs text-gray-400">{brand?.city ? `${brand.city} ${brand.zipCode || ""}` : ""}</p>
                <p className="text-xs text-gray-400">{brand?.phone || ""}</p>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Datos de cliente:</p>
                <div className="relative">
                  <button
                    onClick={() => setClientDropdown(!clientDropdown)}
                    className="w-full text-left flex items-center justify-between border rounded-md px-3 py-2 text-sm hover:border-[#3F4694]/50 transition-colors"
                    data-testid="button-select-client"
                  >
                    <span className={selectedClient ? "text-gray-700 font-medium" : "text-gray-400"}>
                      {selectedClient ? selectedClient.name : "Seleccionar cliente..."}
                    </span>
                    <ChevronDown className="w-4 h-4 text-gray-400" />
                  </button>
                  {clientDropdown && (
                    <div className="absolute z-50 mt-1 w-full bg-white rounded-lg shadow-lg border max-h-48 overflow-auto">
                      {clients.map((c) => (
                        <button
                          key={c.id}
                          onClick={() => { setSelectedClientId(c.id); setClientDropdown(false); }}
                          className="flex items-center gap-2 w-full px-3 py-2 text-sm text-gray-700 hover:bg-gray-50"
                          data-testid={`option-client-${c.id}`}
                        >
                          <div className="w-6 h-6 rounded-full bg-[#3F4694] text-white flex items-center justify-center text-[10px] font-semibold">
                            {c.name.charAt(0)}
                          </div>
                          <span>{c.name}</span>
                          {c.id === selectedClientId && <Check className="w-3 h-3 text-green-500 ml-auto" />}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                {selectedClient && (
                  <div className="mt-2 text-xs text-gray-400 space-y-0.5">
                    <p>{selectedClient.taxId || ""}</p>
                    <p>{selectedClient.address || ""}</p>
                    <p>{selectedClient.city ? `${selectedClient.city} ${selectedClient.zipCode || ""}` : ""}</p>
                    <p>{selectedClient.phone || ""}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Invoice number + dates */}
            <div className="grid grid-cols-3 gap-4 mb-6">
              <div>
                <label className="text-xs text-gray-500 mb-1 block">N° de Factura</label>
                <Input
                  value={invoiceNumber}
                  onChange={(e) => setInvoiceNumber(e.target.value)}
                  placeholder="FAC-0001"
                  className="h-8 text-xs"
                  data-testid="input-invoice-number"
                />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Fecha de facturación</label>
                <Input type="date" value={issueDate} onChange={(e) => setIssueDate(e.target.value)} className="h-8 text-xs" />
              </div>
              <div>
                <label className="text-xs text-gray-500 mb-1 block">Fecha de vencimiento</label>
                <Input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} className="h-8 text-xs" />
              </div>
            </div>

            {/* Line items table */}
            <table className="w-full text-sm mb-4">
              <thead>
                <tr className="border-b text-gray-400 text-left">
                  <th className="py-2 font-medium">Concepto</th>
                  <th className="py-2 font-medium w-20">Cantidad</th>
                  <th className="py-2 font-medium w-24">Precio</th>
                  <th className="py-2 font-medium w-16">IVA %</th>
                  <th className="py-2 font-medium w-24">Total</th>
                  <th className="w-16"></th>
                </tr>
              </thead>
              <tbody>
                {lines.map((line, idx) => (
                  <tr key={line.id} className="border-b border-gray-50">
                    <td className="py-2 pr-2">
                      <div className="relative">
                        <Input
                          placeholder="Buscar producto o escribir..."
                          value={line.description}
                          onChange={(e) => { updateLine(idx, "description", e.target.value); setProductSearch(idx); }}
                          onFocus={() => setProductSearch(idx)}
                          onBlur={() => setTimeout(() => setProductSearch(null), 200)}
                          className="h-8 text-xs pr-7"
                          data-testid={`input-concept-${idx}`}
                        />
                        <Search className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                        {productSearch === idx && line.description && (
                          <div className="absolute z-50 mt-1 w-full bg-white rounded-lg shadow-lg border max-h-36 overflow-auto">
                            {products
                              .filter((p) => p.name.toLowerCase().includes(line.description.toLowerCase()))
                              .slice(0, 5)
                              .map((p) => (
                                <button
                                  key={p.id}
                                  onMouseDown={() => selectProduct(idx, p)}
                                  className="flex items-center justify-between w-full px-3 py-2 text-xs text-gray-700 hover:bg-gray-50"
                                >
                                  <span>{p.name}</span>
                                  <span className="text-gray-400">{Number(p.basePrice).toFixed(2)} €</span>
                                </button>
                              ))}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="py-2 px-1">
                      <Input value={line.quantity} onChange={(e) => updateLine(idx, "quantity", e.target.value)} className="h-8 text-xs text-center" data-testid={`input-qty-${idx}`} />
                    </td>
                    <td className="py-2 px-1">
                      <Input value={line.price} onChange={(e) => updateLine(idx, "price", e.target.value)} className="h-8 text-xs text-right" data-testid={`input-price-${idx}`} />
                    </td>
                    <td className="py-2 px-1">
                      <select
                        value={line.taxRate}
                        onChange={(e) => updateLine(idx, "taxRate", e.target.value)}
                        className="h-8 w-full text-xs border rounded-md px-1"
                      >
                        <option value="21">21%</option>
                        <option value="10">10%</option>
                        <option value="4">4%</option>
                        <option value="0">0%</option>
                      </select>
                    </td>
                    <td className="py-2 px-1 text-right text-gray-700 font-medium">
                      {line.total} €
                    </td>
                    <td className="py-2 px-1 text-center">
                      <div className="flex items-center gap-1">
                        <button onClick={addLine} className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center hover:bg-gray-50" data-testid="button-add-line">
                          <Plus className="w-3 h-3" />
                        </button>
                        {lines.length > 1 && (
                          <button onClick={() => removeLine(idx)} className="w-6 h-6 rounded-full border border-gray-300 flex items-center justify-center hover:bg-red-50 hover:text-red-500">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {/* Notes */}
            <div className="mb-4">
              <textarea
                placeholder="Notas u observaciones (aparecerán en el documento)..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full text-xs border rounded-md px-3 py-2 text-gray-600 min-h-[50px] resize-y"
                data-testid="input-notes"
              />
            </div>

            {/* Totals */}
            <div className="flex justify-end">
              <div className="w-72 space-y-1 text-sm">
                <div className="flex justify-between text-gray-500">
                  <span>Base imponible</span>
                  <span>{subtotal.toFixed(2)} €</span>
                </div>
                {Object.entries(taxByRate).map(([rate, amount]) => (
                  <div key={rate} className="flex justify-between text-gray-500">
                    <span>IVA ({rate}%)</span>
                    <span>{amount.toFixed(2)} €</span>
                  </div>
                ))}
                <div className="flex justify-between font-bold text-gray-800 border-t pt-1">
                  <span>Total</span>
                  <span data-testid="text-total">{total.toFixed(2)} €</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right panel */}
        <div className="space-y-3">
          {/* Status change */}
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <label className="text-xs text-gray-500 font-medium mb-2 block">Estado</label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              className="w-full text-sm border rounded-md px-3 py-2 text-gray-700"
              data-testid="select-status"
            >
              <option value="draft">Borrador</option>
              <option value="sent">Emitida</option>
              <option value="paid">Cobrada</option>
              <option value="partial">Pago parcial</option>
            </select>
          </div>

          {[
            { label: "Personalizar", key: "personalizar" },
            { label: "Métodos de pago", key: "metodos" },
            { label: "Recurrencia", key: "recurrencia" },
          ].map((item) => (
            <button
              key={item.key}
              className="flex items-center justify-between w-full bg-white rounded-lg p-3 shadow-sm border border-gray-100 text-sm text-gray-700 hover:bg-gray-50"
              data-testid={`panel-${item.key}`}
            >
              {item.label}
              <ChevronDown className="w-4 h-4 text-gray-400" />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
