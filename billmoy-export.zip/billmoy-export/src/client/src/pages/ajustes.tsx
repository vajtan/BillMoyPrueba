import { useQuery, useMutation } from "@tanstack/react-query";
import { useState, useEffect, useRef } from "react";
import {
  Save, Building, Receipt, CreditCard, Landmark, Hash, Percent, Globe,
  Upload, Trash2, Eye, EyeOff, Palette, Type, AlignLeft, AlignCenter,
  AlignRight, Maximize2, Columns2, Image, Droplets, PenLine, FileText,
  Stamp, ChevronDown, ChevronUp, LayoutGrid, Layers, Ruler, Shield,
  Languages, CalendarDays, SeparatorHorizontal, GripVertical, Bold,
  Italic, Underline, RotateCcw, Sun, Moon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { BrandSettings } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import logoBlueSrc from "@assets/logo-blue.png";

export default function Ajustes() {
  const { toast } = useToast();
  const { data: brand } = useQuery<BrandSettings | null>({ queryKey: ["/api/brand-settings", "1"] });
  const [activeTab, setActiveTab] = useState("empresa");

  const logoFileRef = useRef<HTMLInputElement>(null);
  const [form, setForm] = useState({
    companyName: "",
    taxId: "",
    address: "",
    city: "",
    province: "",
    country: "España",
    zipCode: "",
    phone: "",
    primaryColor: "#3F4694",
    secondaryColor: "#1a1a1a",
    accentColor: "#F25075",
    backgroundColor: "#FBFBFB",
    fontFamily: "Catamaran",
    defaultOrientation: "portrait",
  });

  // Personalización visual ampliada
  const [visualSettings, setVisualSettings] = useState({
    // Logo
    logoUrl: "",
    logoPosition: "left",
    logoMaxWidth: "180",
    // Tipografía
    headingFont: "Catamaran",
    bodyFont: "Catamaran",
    headingSize: "24",
    bodySize: "13",
    headingWeight: "700",
    headingColor: "#1a1a1a",
    bodyColor: "#555555",
    lineHeight: "1.6",
    letterSpacing: "0",
    // Documento
    pageMarginTop: "20",
    pageMarginBottom: "20",
    pageMarginLeft: "24",
    pageMarginRight: "24",
    headerHeight: "80",
    footerHeight: "60",
    showHeader: true,
    showFooter: true,
    showPageNumbers: true,
    pageNumberPosition: "center",
    // Bordes y sombra
    documentBorder: false,
    documentBorderColor: "#e5e7eb",
    documentBorderWidth: "1",
    documentBorderRadius: "0",
    documentShadow: false,
    // Tabla de conceptos
    tableHeaderBg: "#3F4694",
    tableHeaderTextColor: "#ffffff",
    tableAlternateRows: true,
    tableAlternateColor: "#f8f9fa",
    tableBorderColor: "#e5e7eb",
    tableShowBorders: true,
    // Cabecera del documento
    headerBgColor: "#3F4694",
    headerTextColor: "#ffffff",
    headerLayout: "logo-left",
    // Pie de documento
    footerBgColor: "#f8f9fa",
    footerTextColor: "#888888",
    footerText: "",
    // Textos legales
    showLegalText: false,
    legalText: "",
    showWatermark: false,
    watermarkText: "BORRADOR",
    watermarkOpacity: "15",
    // Formato
    dateFormat: "DD/MM/YYYY",
    numberFormat: "es-ES",
    language: "es",
    // Botones/Links
    buttonRadius: "6",
    buttonStyle: "filled",
    // Secciones visibles
    showClientSection: true,
    showDateSection: true,
    showSubtotals: true,
    showTaxBreakdown: true,
    showPaymentInfo: true,
    showNotes: true,
  });

  // Tax/invoice settings (local state, not persisted yet)
  const [taxSettings, setTaxSettings] = useState({
    defaultTaxRate: "21",
    reducedTaxRate: "10",
    superReducedRate: "4",
    invoiceSeries: "FAC",
    quoteSeries: "PRE",
    nextInvoiceNum: "1",
    nextQuoteNum: "1",
    currency: "EUR",
    currencySymbol: "€",
    decimalPlaces: "2",
  });

  const [paymentSettings, setPaymentSettings] = useState({
    defaultPaymentMethod: "transferencia",
    bankName: "",
    iban: "",
    swift: "",
    paymentTermsDays: "30",
    lateInterestRate: "0",
    notes: "",
  });

  useEffect(() => {
    if (brand) {
      setForm({
        companyName: brand.companyName || "",
        taxId: brand.taxId || "",
        address: brand.address || "",
        city: brand.city || "",
        province: brand.province || "",
        country: brand.country || "España",
        zipCode: brand.zipCode || "",
        phone: brand.phone || "",
        primaryColor: brand.primaryColor || "#3F4694",
        accentColor: brand.accentColor || "#F25075",
        backgroundColor: brand.backgroundColor || "#FBFBFB",
        fontFamily: brand.fontFamily || "Catamaran",
        defaultOrientation: brand.defaultOrientation || "portrait",
      });
    }
  }, [brand]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PUT", "/api/brand-settings", { userId: 1, ...form });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/brand-settings", "1"] });
      toast({ title: "Ajustes guardados", description: "Los datos se han actualizado correctamente." });
    },
  });

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  const tabs = [
    { key: "empresa", label: "Empresa", icon: Building },
    { key: "impuestos", label: "Impuestos y numeración", icon: Percent },
    { key: "pagos", label: "Pagos y banco", icon: CreditCard },
    { key: "visual", label: "Personalización", icon: Globe },
  ];

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }} data-testid="text-page-title">
        Ajustes
      </h1>

      {/* Tab navigation */}
      <div className="flex gap-1 mb-6 bg-white rounded-lg p-1 shadow-sm border border-gray-100 w-fit">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setActiveTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2 text-sm rounded-md transition-colors ${
              activeTab === t.key
                ? "text-white bg-[#3F4694] font-semibold"
                : "text-gray-500 hover:text-[#3F4694] hover:bg-gray-50"
            }`}
            data-testid={`tab-${t.key}`}
          >
            <t.icon className="w-4 h-4" />
            {t.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_320px] gap-6">
        <div className="space-y-6">
          {/* ── Datos fiscales ── */}
          {activeTab === "empresa" && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
              <h2 className="text-sm font-bold text-[#3F4694] mb-4 flex items-center gap-2">
                <Building className="w-4 h-4" /> Datos fiscales
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Nombre de la empresa</label>
                  <Input value={form.companyName} onChange={(e) => handleChange("companyName", e.target.value)} placeholder="Tu empresa SL" data-testid="input-company-name" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">CIF / NIF</label>
                  <Input value={form.taxId} onChange={(e) => handleChange("taxId", e.target.value)} placeholder="B12345678" data-testid="input-tax-id" />
                </div>
                <div className="md:col-span-2">
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Dirección</label>
                  <Input value={form.address} onChange={(e) => handleChange("address", e.target.value)} placeholder="Calle, número, piso" data-testid="input-address" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Ciudad</label>
                  <Input value={form.city} onChange={(e) => handleChange("city", e.target.value)} placeholder="Madrid" data-testid="input-city" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Provincia</label>
                  <Input value={form.province} onChange={(e) => handleChange("province", e.target.value)} placeholder="Madrid" data-testid="input-province" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">País</label>
                  <Input value={form.country} onChange={(e) => handleChange("country", e.target.value)} placeholder="España" data-testid="input-country" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Código postal</label>
                  <Input value={form.zipCode} onChange={(e) => handleChange("zipCode", e.target.value)} placeholder="28001" data-testid="input-zip" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Teléfono</label>
                  <Input value={form.phone} onChange={(e) => handleChange("phone", e.target.value)} placeholder="+34 600 000 000" data-testid="input-phone" />
                </div>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Email</label>
                  <Input placeholder="info@tuempresa.com" data-testid="input-email" />
                </div>
              </div>
            </div>
          )}

          {/* ── Impuestos y numeración ── */}
          {activeTab === "impuestos" && (
            <>
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-4 flex items-center gap-2">
                  <Percent className="w-4 h-4" /> Tipos de IVA
                </h2>
                <p className="text-xs text-gray-400 mb-4">Configura los tipos impositivos que se aplicarán a tus documentos.</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">IVA general (%)</label>
                    <Input value={taxSettings.defaultTaxRate} onChange={(e) => setTaxSettings({ ...taxSettings, defaultTaxRate: e.target.value })} data-testid="input-default-tax" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">IVA reducido (%)</label>
                    <Input value={taxSettings.reducedTaxRate} onChange={(e) => setTaxSettings({ ...taxSettings, reducedTaxRate: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">IVA superreducido (%)</label>
                    <Input value={taxSettings.superReducedRate} onChange={(e) => setTaxSettings({ ...taxSettings, superReducedRate: e.target.value })} />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-4 flex items-center gap-2">
                  <Hash className="w-4 h-4" /> Series de numeración
                </h2>
                <p className="text-xs text-gray-400 mb-4">Define los prefijos y el siguiente número para cada tipo de documento.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Serie de facturas</label>
                    <div className="flex gap-2">
                      <Input value={taxSettings.invoiceSeries} onChange={(e) => setTaxSettings({ ...taxSettings, invoiceSeries: e.target.value })} className="w-24" data-testid="input-invoice-series" />
                      <Input value={taxSettings.nextInvoiceNum} onChange={(e) => setTaxSettings({ ...taxSettings, nextInvoiceNum: e.target.value })} placeholder="Siguiente nº" className="flex-1" />
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1">Ejemplo: {taxSettings.invoiceSeries}-{String(taxSettings.nextInvoiceNum).padStart(4, "0")}</p>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Serie de presupuestos</label>
                    <div className="flex gap-2">
                      <Input value={taxSettings.quoteSeries} onChange={(e) => setTaxSettings({ ...taxSettings, quoteSeries: e.target.value })} className="w-24" data-testid="input-quote-series" />
                      <Input value={taxSettings.nextQuoteNum} onChange={(e) => setTaxSettings({ ...taxSettings, nextQuoteNum: e.target.value })} placeholder="Siguiente nº" className="flex-1" />
                    </div>
                    <p className="text-[10px] text-gray-400 mt-1">Ejemplo: {taxSettings.quoteSeries}-{String(taxSettings.nextQuoteNum).padStart(4, "0")}</p>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-4 flex items-center gap-2">
                  <Globe className="w-4 h-4" /> Moneda
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Moneda</label>
                    <select
                      className="w-full text-sm border rounded-md px-3 py-2 text-gray-700"
                      value={taxSettings.currency}
                      onChange={(e) => setTaxSettings({ ...taxSettings, currency: e.target.value })}
                      data-testid="select-currency"
                    >
                      <option value="EUR">Euro (EUR)</option>
                      <option value="USD">Dólar USA (USD)</option>
                      <option value="GBP">Libra esterlina (GBP)</option>
                      <option value="MXN">Peso mexicano (MXN)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Símbolo</label>
                    <Input value={taxSettings.currencySymbol} onChange={(e) => setTaxSettings({ ...taxSettings, currencySymbol: e.target.value })} />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Decimales</label>
                    <Input value={taxSettings.decimalPlaces} onChange={(e) => setTaxSettings({ ...taxSettings, decimalPlaces: e.target.value })} />
                  </div>
                </div>
              </div>
            </>
          )}

          {/* ── Pagos y banco ── */}
          {activeTab === "pagos" && (
            <>
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-4 flex items-center gap-2">
                  <CreditCard className="w-4 h-4" /> Métodos de pago
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Método de pago por defecto</label>
                    <select
                      className="w-full text-sm border rounded-md px-3 py-2 text-gray-700"
                      value={paymentSettings.defaultPaymentMethod}
                      onChange={(e) => setPaymentSettings({ ...paymentSettings, defaultPaymentMethod: e.target.value })}
                      data-testid="select-payment-method"
                    >
                      <option value="transferencia">Transferencia bancaria</option>
                      <option value="efectivo">Efectivo</option>
                      <option value="tarjeta">Tarjeta de crédito/débito</option>
                      <option value="paypal">PayPal</option>
                      <option value="bizum">Bizum</option>
                      <option value="domiciliacion">Domiciliación bancaria</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Plazo de pago (días)</label>
                    <Input value={paymentSettings.paymentTermsDays} onChange={(e) => setPaymentSettings({ ...paymentSettings, paymentTermsDays: e.target.value })} data-testid="input-payment-terms" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Interés por demora (%)</label>
                    <Input value={paymentSettings.lateInterestRate} onChange={(e) => setPaymentSettings({ ...paymentSettings, lateInterestRate: e.target.value })} />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-4 flex items-center gap-2">
                  <Landmark className="w-4 h-4" /> Datos bancarios
                </h2>
                <p className="text-xs text-gray-400 mb-4">Estos datos aparecerán en tus facturas para que tus clientes sepan dónde pagar.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">Nombre del banco</label>
                    <Input value={paymentSettings.bankName} onChange={(e) => setPaymentSettings({ ...paymentSettings, bankName: e.target.value })} placeholder="BBVA, Santander, etc." data-testid="input-bank-name" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 font-medium mb-1 block">SWIFT / BIC</label>
                    <Input value={paymentSettings.swift} onChange={(e) => setPaymentSettings({ ...paymentSettings, swift: e.target.value })} placeholder="BBVAESMMXXX" />
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-xs text-gray-500 font-medium mb-1 block">IBAN</label>
                    <Input value={paymentSettings.iban} onChange={(e) => setPaymentSettings({ ...paymentSettings, iban: e.target.value })} placeholder="ES00 0000 0000 0000 0000 0000" data-testid="input-iban" />
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-4 flex items-center gap-2">
                  <Receipt className="w-4 h-4" /> Notas de pago
                </h2>
                <div>
                  <label className="text-xs text-gray-500 font-medium mb-1 block">Notas que aparecen al pie de las facturas</label>
                  <textarea
                    className="w-full text-sm border rounded-md px-3 py-2 text-gray-700 min-h-[80px] resize-y"
                    value={paymentSettings.notes}
                    onChange={(e) => setPaymentSettings({ ...paymentSettings, notes: e.target.value })}
                    placeholder="Ej: Forma de pago: transferencia bancaria a la cuenta indicada..."
                    data-testid="input-payment-notes"
                  />
                </div>
              </div>
            </>
          )}

          {/* ── Personalización visual ── */}
          {activeTab === "visual" && (
            <div className="space-y-5">
              {/* ─── Logotipo ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Upload className="w-4 h-4" /> Logotipo</h2>
                <p className="text-[11px] text-gray-400 mb-4">Tu logo aparecerá en la cabecera de todos los documentos.</p>
                <div className="flex gap-4 items-start">
                  <div className="w-32 h-20 rounded-lg border-2 border-dashed border-gray-200 flex items-center justify-center bg-gray-50 overflow-hidden cursor-pointer hover:border-[#3F4694]/40 transition-colors" onClick={() => logoFileRef.current?.click()} data-testid="logo-upload-area">
                    {visualSettings.logoUrl ? (
                      <img src={visualSettings.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <div className="text-center">
                        <Image className="w-5 h-5 text-gray-300 mx-auto" />
                        <span className="text-[9px] text-gray-400 mt-1 block">Subir logo</span>
                      </div>
                    )}
                  </div>
                  <input ref={logoFileRef} type="file" accept="image/*" className="hidden" onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      const reader = new FileReader();
                      reader.onload = (ev) => setVisualSettings(s => ({ ...s, logoUrl: ev.target?.result as string }));
                      reader.readAsDataURL(file);
                    }
                  }} />
                  <div className="flex-1 space-y-3">
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] text-gray-500 font-medium mb-1 block">Posición del logo</label>
                        <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.logoPosition} onChange={(e) => setVisualSettings(s => ({ ...s, logoPosition: e.target.value }))} data-testid="select-logo-position">
                          <option value="left">Izquierda</option>
                          <option value="center">Centro</option>
                          <option value="right">Derecha</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-gray-500 font-medium mb-1 block">Ancho máximo (px)</label>
                        <Input value={visualSettings.logoMaxWidth} onChange={(e) => setVisualSettings(s => ({ ...s, logoMaxWidth: e.target.value }))} className="text-xs h-8" data-testid="input-logo-width" />
                      </div>
                    </div>
                    {visualSettings.logoUrl && (
                      <button onClick={() => setVisualSettings(s => ({ ...s, logoUrl: "" }))} className="text-[10px] text-red-500 hover:text-red-700 flex items-center gap-1"><Trash2 className="w-3 h-3" /> Eliminar logo</button>
                    )}
                  </div>
                </div>
              </div>

              {/* ─── Paleta de colores ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Palette className="w-4 h-4" /> Paleta de colores</h2>
                <p className="text-[11px] text-gray-400 mb-4">Define los colores que se aplicarán por defecto en todos tus documentos.</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { key: "primaryColor", label: "Principal", desc: "Cabecera, títulos" },
                    { key: "secondaryColor", label: "Secundario", desc: "Textos, subtítulos" },
                    { key: "accentColor", label: "Acento", desc: "Botones, destacados" },
                    { key: "backgroundColor", label: "Fondo", desc: "Fondo del documento" },
                  ].map((c) => (
                    <div key={c.key}>
                      <label className="text-[11px] text-gray-500 font-medium mb-1 block">{c.label}</label>
                      <div className="flex items-center gap-2">
                        <input type="color" value={(form as any)[c.key]} onChange={(e) => handleChange(c.key, e.target.value)} className="w-8 h-8 rounded border cursor-pointer flex-shrink-0" data-testid={`input-color-${c.key}`} />
                        <Input value={(form as any)[c.key]} onChange={(e) => handleChange(c.key, e.target.value)} className="text-[11px] h-8" />
                      </div>
                      <p className="text-[9px] text-gray-400 mt-0.5">{c.desc}</p>
                    </div>
                  ))}
                </div>
                {/* Quick preset palettes */}
                <div className="mt-4 pt-3 border-t border-gray-100">
                  <p className="text-[10px] text-gray-500 font-medium mb-2 uppercase tracking-wider">Paletas predefinidas</p>
                  <div className="flex gap-2 flex-wrap">
                    {[
                      { name: "BillMoy", colors: ["#3F4694", "#1a1a1a", "#F25075", "#FBFBFB"] },
                      { name: "Corporativo", colors: ["#1a365d", "#2d3748", "#3182ce", "#ffffff"] },
                      { name: "Minimalista", colors: ["#111111", "#444444", "#000000", "#ffffff"] },
                      { name: "Cálido", colors: ["#b45309", "#78350f", "#f59e0b", "#fffbeb"] },
                      { name: "Verde", colors: ["#065f46", "#1f2937", "#10b981", "#f0fdf4"] },
                      { name: "Morado", colors: ["#6b21a8", "#374151", "#a855f7", "#faf5ff"] },
                    ].map((palette) => (
                      <button key={palette.name} onClick={() => { setForm(f => ({ ...f, primaryColor: palette.colors[0], secondaryColor: palette.colors[1], accentColor: palette.colors[2], backgroundColor: palette.colors[3] })); }} className="flex items-center gap-1.5 px-2.5 py-1.5 border border-gray-200 rounded-lg hover:border-[#3F4694]/30 hover:bg-gray-50 transition-all" data-testid={`palette-${palette.name}`}>
                        <div className="flex gap-0.5">
                          {palette.colors.map((c, i) => (<div key={i} className="w-3.5 h-3.5 rounded-full border border-white shadow-sm" style={{ backgroundColor: c }} />))}
                        </div>
                        <span className="text-[10px] text-gray-600 font-medium">{palette.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* ─── Tipografía ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Type className="w-4 h-4" /> Tipografía</h2>
                <p className="text-[11px] text-gray-400 mb-4">Controla las fuentes, tamaños y estilos de texto.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Fuente de encabezados</label>
                    <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.headingFont} onChange={(e) => setVisualSettings(s => ({ ...s, headingFont: e.target.value }))} data-testid="select-heading-font">
                      {["Catamaran", "Inter", "Roboto", "Montserrat", "Lato", "Open Sans", "Playfair Display", "Raleway", "Poppins", "Oswald", "Merriweather", "Georgia", "Times New Roman", "Arial", "Helvetica"].map(f => <option key={f} value={f}>{f}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Fuente de cuerpo</label>
                    <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.bodyFont} onChange={(e) => setVisualSettings(s => ({ ...s, bodyFont: e.target.value }))} data-testid="select-body-font">
                      {["Catamaran", "Inter", "Roboto", "Montserrat", "Lato", "Open Sans", "Raleway", "Poppins", "Source Sans Pro", "Noto Sans", "Arial", "Helvetica", "Georgia"].map(f => <option key={f} value={f}>{f}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Tamaño título</label>
                    <div className="flex items-center gap-1">
                      <Input value={visualSettings.headingSize} onChange={(e) => setVisualSettings(s => ({ ...s, headingSize: e.target.value }))} className="text-xs h-8" data-testid="input-heading-size" />
                      <span className="text-[10px] text-gray-400">px</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Tamaño cuerpo</label>
                    <div className="flex items-center gap-1">
                      <Input value={visualSettings.bodySize} onChange={(e) => setVisualSettings(s => ({ ...s, bodySize: e.target.value }))} className="text-xs h-8" data-testid="input-body-size" />
                      <span className="text-[10px] text-gray-400">px</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Interlineado</label>
                    <Input value={visualSettings.lineHeight} onChange={(e) => setVisualSettings(s => ({ ...s, lineHeight: e.target.value }))} className="text-xs h-8" />
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Espaciado letras</label>
                    <div className="flex items-center gap-1">
                      <Input value={visualSettings.letterSpacing} onChange={(e) => setVisualSettings(s => ({ ...s, letterSpacing: e.target.value }))} className="text-xs h-8" />
                      <span className="text-[10px] text-gray-400">px</span>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Peso del título</label>
                    <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.headingWeight} onChange={(e) => setVisualSettings(s => ({ ...s, headingWeight: e.target.value }))}>
                      <option value="300">Light (300)</option>
                      <option value="400">Regular (400)</option>
                      <option value="500">Medium (500)</option>
                      <option value="600">Semibold (600)</option>
                      <option value="700">Bold (700)</option>
                      <option value="800">Extra Bold (800)</option>
                      <option value="900">Black (900)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color de títulos</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.headingColor} onChange={(e) => setVisualSettings(s => ({ ...s, headingColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.headingColor} onChange={(e) => setVisualSettings(s => ({ ...s, headingColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color de texto</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.bodyColor} onChange={(e) => setVisualSettings(s => ({ ...s, bodyColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.bodyColor} onChange={(e) => setVisualSettings(s => ({ ...s, bodyColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                </div>
                {/* Font preview */}
                <div className="mt-4 pt-3 border-t border-gray-100 bg-gray-50 rounded-lg p-3">
                  <p className="text-[9px] text-gray-400 uppercase tracking-wider mb-2">Vista previa tipografía</p>
                  <p style={{ fontFamily: visualSettings.headingFont, fontSize: `${Math.min(Number(visualSettings.headingSize) || 24, 28)}px`, fontWeight: Number(visualSettings.headingWeight), color: visualSettings.headingColor }}>Título de ejemplo</p>
                  <p style={{ fontFamily: visualSettings.bodyFont, fontSize: `${visualSettings.bodySize}px`, color: visualSettings.bodyColor, lineHeight: visualSettings.lineHeight, letterSpacing: `${visualSettings.letterSpacing}px` }} className="mt-1">Este es un texto de ejemplo para previsualizar la tipografía del cuerpo en tus documentos.</p>
                </div>
              </div>

              {/* ─── Orientación y márgenes ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Ruler className="w-4 h-4" /> Orientación y márgenes</h2>
                <p className="text-[11px] text-gray-400 mb-4">Configuración de la página por defecto para documentos nuevos.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Orientación por defecto</label>
                    <div className="flex gap-2">
                      {[{ val: "portrait", label: "Vertical", icon: "📄" }, { val: "landscape", label: "Horizontal", icon: "📃" }].map(o => (
                        <button key={o.val} onClick={() => handleChange("defaultOrientation", o.val)} className={`flex-1 flex items-center justify-center gap-2 px-3 py-2.5 border rounded-lg text-xs transition-all ${form.defaultOrientation === o.val ? "border-[#3F4694] bg-[#3F4694]/5 text-[#3F4694] font-semibold" : "border-gray-200 text-gray-500 hover:border-gray-300"}`} data-testid={`btn-orientation-${o.val}`}>
                          <span>{o.icon}</span> {o.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] text-gray-500 font-medium mb-1 block">Alto cabecera (mm)</label>
                      <Input value={visualSettings.headerHeight} onChange={(e) => setVisualSettings(s => ({ ...s, headerHeight: e.target.value }))} className="text-xs h-8" />
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 font-medium mb-1 block">Alto pie (mm)</label>
                      <Input value={visualSettings.footerHeight} onChange={(e) => setVisualSettings(s => ({ ...s, footerHeight: e.target.value }))} className="text-xs h-8" />
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3">
                  {[
                    { key: "pageMarginTop", label: "Margen superior" },
                    { key: "pageMarginBottom", label: "Margen inferior" },
                    { key: "pageMarginLeft", label: "Margen izquierdo" },
                    { key: "pageMarginRight", label: "Margen derecho" },
                  ].map(m => (
                    <div key={m.key}>
                      <label className="text-[11px] text-gray-500 font-medium mb-1 block">{m.label}</label>
                      <div className="flex items-center gap-1">
                        <Input value={(visualSettings as any)[m.key]} onChange={(e) => setVisualSettings(s => ({ ...s, [m.key]: e.target.value }))} className="text-xs h-8" />
                        <span className="text-[10px] text-gray-400">mm</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* ─── Cabecera del documento ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><LayoutGrid className="w-4 h-4" /> Cabecera del documento</h2>
                <p className="text-[11px] text-gray-400 mb-4">Personaliza el aspecto de la cabecera en tus facturas y presupuestos.</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Disposición</label>
                    <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.headerLayout} onChange={(e) => setVisualSettings(s => ({ ...s, headerLayout: e.target.value }))}>
                      <option value="logo-left">Logo izquierda, datos derecha</option>
                      <option value="logo-right">Logo derecha, datos izquierda</option>
                      <option value="logo-center">Logo centrado, datos debajo</option>
                      <option value="no-logo">Sin logo, solo texto</option>
                      <option value="full-width">Cabecera a ancho completo</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color de fondo</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.headerBgColor} onChange={(e) => setVisualSettings(s => ({ ...s, headerBgColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.headerBgColor} onChange={(e) => setVisualSettings(s => ({ ...s, headerBgColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color de texto</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.headerTextColor} onChange={(e) => setVisualSettings(s => ({ ...s, headerTextColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.headerTextColor} onChange={(e) => setVisualSettings(s => ({ ...s, headerTextColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                </div>
                <div className="flex gap-4 mt-3">
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.showHeader} onChange={(e) => setVisualSettings(s => ({ ...s, showHeader: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Mostrar cabecera
                  </label>
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.showFooter} onChange={(e) => setVisualSettings(s => ({ ...s, showFooter: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Mostrar pie
                  </label>
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.showPageNumbers} onChange={(e) => setVisualSettings(s => ({ ...s, showPageNumbers: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Numeración de página
                  </label>
                </div>
              </div>

              {/* ─── Tabla de conceptos ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Layers className="w-4 h-4" /> Tabla de conceptos</h2>
                <p className="text-[11px] text-gray-400 mb-4">Configura el aspecto de la tabla de líneas de factura/presupuesto.</p>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Fondo cabecera tabla</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.tableHeaderBg} onChange={(e) => setVisualSettings(s => ({ ...s, tableHeaderBg: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.tableHeaderBg} onChange={(e) => setVisualSettings(s => ({ ...s, tableHeaderBg: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Texto cabecera tabla</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.tableHeaderTextColor} onChange={(e) => setVisualSettings(s => ({ ...s, tableHeaderTextColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.tableHeaderTextColor} onChange={(e) => setVisualSettings(s => ({ ...s, tableHeaderTextColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color filas alternas</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.tableAlternateColor} onChange={(e) => setVisualSettings(s => ({ ...s, tableAlternateColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.tableAlternateColor} onChange={(e) => setVisualSettings(s => ({ ...s, tableAlternateColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color bordes tabla</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.tableBorderColor} onChange={(e) => setVisualSettings(s => ({ ...s, tableBorderColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.tableBorderColor} onChange={(e) => setVisualSettings(s => ({ ...s, tableBorderColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                </div>
                <div className="flex gap-4 mt-3">
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.tableAlternateRows} onChange={(e) => setVisualSettings(s => ({ ...s, tableAlternateRows: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Filas alternas coloreadas
                  </label>
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.tableShowBorders} onChange={(e) => setVisualSettings(s => ({ ...s, tableShowBorders: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Mostrar bordes de tabla
                  </label>
                </div>
                {/* Table preview */}
                <div className="mt-4 pt-3 border-t border-gray-100">
                  <p className="text-[9px] text-gray-400 uppercase tracking-wider mb-2">Vista previa tabla</p>
                  <div className="rounded-lg overflow-hidden border" style={{ borderColor: visualSettings.tableBorderColor }}>
                    <div className="grid grid-cols-4 text-[10px] font-semibold px-3 py-1.5" style={{ backgroundColor: visualSettings.tableHeaderBg, color: visualSettings.tableHeaderTextColor }}>  
                      <span>Concepto</span><span>Cantidad</span><span>Precio</span><span className="text-right">Total</span>
                    </div>
                    {[0,1,2].map(i => (
                      <div key={i} className="grid grid-cols-4 text-[10px] px-3 py-1.5" style={{ backgroundColor: visualSettings.tableAlternateRows && i % 2 === 1 ? visualSettings.tableAlternateColor : "transparent", borderTop: visualSettings.tableShowBorders ? `1px solid ${visualSettings.tableBorderColor}` : "none" }}>
                        <span className="text-gray-600">Servicio {i+1}</span><span className="text-gray-500">1</span><span className="text-gray-500">0,00 €</span><span className="text-right text-gray-700 font-medium">0,00 €</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* ─── Bordes y estilo del documento ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Maximize2 className="w-4 h-4" /> Bordes y estilo del documento</h2>
                <p className="text-[11px] text-gray-400 mb-4">Aplica borde y sombra al documento impreso.</p>
                <div className="flex gap-6">
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.documentBorder} onChange={(e) => setVisualSettings(s => ({ ...s, documentBorder: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Borde del documento
                  </label>
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.documentShadow} onChange={(e) => setVisualSettings(s => ({ ...s, documentShadow: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Sombra externa
                  </label>
                </div>
                {visualSettings.documentBorder && (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-3">
                    <div>
                      <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color del borde</label>
                      <div className="flex items-center gap-2">
                        <input type="color" value={visualSettings.documentBorderColor} onChange={(e) => setVisualSettings(s => ({ ...s, documentBorderColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                        <Input value={visualSettings.documentBorderColor} onChange={(e) => setVisualSettings(s => ({ ...s, documentBorderColor: e.target.value }))} className="text-[11px] h-8" />
                      </div>
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 font-medium mb-1 block">Grosor (px)</label>
                      <Input value={visualSettings.documentBorderWidth} onChange={(e) => setVisualSettings(s => ({ ...s, documentBorderWidth: e.target.value }))} className="text-xs h-8" />
                    </div>
                    <div>
                      <label className="text-[11px] text-gray-500 font-medium mb-1 block">Radio esquinas (px)</label>
                      <Input value={visualSettings.documentBorderRadius} onChange={(e) => setVisualSettings(s => ({ ...s, documentBorderRadius: e.target.value }))} className="text-xs h-8" />
                    </div>
                  </div>
                )}
              </div>

              {/* ─── Pie de documento ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><SeparatorHorizontal className="w-4 h-4" /> Pie de documento</h2>
                <p className="text-[11px] text-gray-400 mb-4">Texto y diseño del pie de tus facturas y presupuestos.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color de fondo</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.footerBgColor} onChange={(e) => setVisualSettings(s => ({ ...s, footerBgColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.footerBgColor} onChange={(e) => setVisualSettings(s => ({ ...s, footerBgColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Color de texto</label>
                    <div className="flex items-center gap-2">
                      <input type="color" value={visualSettings.footerTextColor} onChange={(e) => setVisualSettings(s => ({ ...s, footerTextColor: e.target.value }))} className="w-7 h-7 rounded border cursor-pointer flex-shrink-0" />
                      <Input value={visualSettings.footerTextColor} onChange={(e) => setVisualSettings(s => ({ ...s, footerTextColor: e.target.value }))} className="text-[11px] h-8" />
                    </div>
                  </div>
                </div>
                <div className="mt-3">
                  <label className="text-[11px] text-gray-500 font-medium mb-1 block">Texto del pie (aparece en cada página)</label>
                  <textarea className="w-full text-xs border rounded-md px-3 py-2 text-gray-700 min-h-[60px] resize-y" value={visualSettings.footerText} onChange={(e) => setVisualSettings(s => ({ ...s, footerText: e.target.value }))} placeholder="Ej: Inscrita en el Registro Mercantil de Madrid, Tomo XXXX..." />
                </div>
                <div className="mt-2">
                  <label className="text-[11px] text-gray-500 font-medium mb-1 block">Posición número de página</label>
                  <div className="flex gap-2">
                    {[{ val: "left", icon: AlignLeft, label: "Izq" }, { val: "center", icon: AlignCenter, label: "Centro" }, { val: "right", icon: AlignRight, label: "Der" }].map(p => (
                      <button key={p.val} onClick={() => setVisualSettings(s => ({ ...s, pageNumberPosition: p.val }))} className={`flex items-center gap-1.5 px-3 py-1.5 border rounded-md text-[11px] transition-all ${visualSettings.pageNumberPosition === p.val ? "border-[#3F4694] bg-[#3F4694]/5 text-[#3F4694] font-medium" : "border-gray-200 text-gray-500"}`}>
                        <p.icon className="w-3 h-3" /> {p.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* ─── Marca de agua y textos legales ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Shield className="w-4 h-4" /> Marca de agua y textos legales</h2>
                <p className="text-[11px] text-gray-400 mb-4">Añade una marca de agua o textos legales a tus documentos.</p>
                <div className="space-y-3">
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.showWatermark} onChange={(e) => setVisualSettings(s => ({ ...s, showWatermark: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Activar marca de agua en borradores
                  </label>
                  {visualSettings.showWatermark && (
                    <div className="grid grid-cols-2 gap-3 pl-6">
                      <div>
                        <label className="text-[11px] text-gray-500 font-medium mb-1 block">Texto</label>
                        <Input value={visualSettings.watermarkText} onChange={(e) => setVisualSettings(s => ({ ...s, watermarkText: e.target.value }))} className="text-xs h-8" />
                      </div>
                      <div>
                        <label className="text-[11px] text-gray-500 font-medium mb-1 block">Opacidad (%)</label>
                        <Input value={visualSettings.watermarkOpacity} onChange={(e) => setVisualSettings(s => ({ ...s, watermarkOpacity: e.target.value }))} className="text-xs h-8" />
                      </div>
                    </div>
                  )}
                  <label className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer">
                    <input type="checkbox" checked={visualSettings.showLegalText} onChange={(e) => setVisualSettings(s => ({ ...s, showLegalText: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                    Incluir texto legal al pie
                  </label>
                  {visualSettings.showLegalText && (
                    <div className="pl-6">
                      <textarea className="w-full text-xs border rounded-md px-3 py-2 text-gray-700 min-h-[60px] resize-y" value={visualSettings.legalText} onChange={(e) => setVisualSettings(s => ({ ...s, legalText: e.target.value }))} placeholder="Según la Ley 37/1992 del IVA, esta factura está sujeta al..." />
                    </div>
                  )}
                </div>
              </div>

              {/* ─── Secciones visibles ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Eye className="w-4 h-4" /> Secciones visibles por defecto</h2>
                <p className="text-[11px] text-gray-400 mb-4">Elige qué secciones se muestran por defecto en documentos nuevos.</p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {[
                    { key: "showClientSection", label: "Datos del cliente" },
                    { key: "showDateSection", label: "Fecha y número" },
                    { key: "showSubtotals", label: "Subtotales" },
                    { key: "showTaxBreakdown", label: "Desglose de impuestos" },
                    { key: "showPaymentInfo", label: "Información de pago" },
                    { key: "showNotes", label: "Notas / Observaciones" },
                  ].map(s => (
                    <label key={s.key} className="flex items-center gap-2 text-xs text-gray-600 cursor-pointer p-2 rounded-lg border border-gray-100 hover:bg-gray-50 transition-colors">
                      <input type="checkbox" checked={(visualSettings as any)[s.key]} onChange={(e) => setVisualSettings(vs => ({ ...vs, [s.key]: e.target.checked }))} className="rounded border-gray-300 text-[#3F4694] focus:ring-[#3F4694]" />
                      {s.label}
                    </label>
                  ))}
                </div>
              </div>

              {/* ─── Formato y localización ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><Languages className="w-4 h-4" /> Formato y localización</h2>
                <p className="text-[11px] text-gray-400 mb-4">Idioma, formato de fecha y números para tus documentos.</p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Idioma</label>
                    <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.language} onChange={(e) => setVisualSettings(s => ({ ...s, language: e.target.value }))}>
                      <option value="es">Español</option>
                      <option value="en">Inglés</option>
                      <option value="fr">Francés</option>
                      <option value="de">Alemán</option>
                      <option value="pt">Portugués</option>
                      <option value="it">Italiano</option>
                      <option value="ca">Catalán</option>
                      <option value="eu">Euskera</option>
                      <option value="gl">Gallego</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Formato de fecha</label>
                    <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.dateFormat} onChange={(e) => setVisualSettings(s => ({ ...s, dateFormat: e.target.value }))}>
                      <option value="DD/MM/YYYY">DD/MM/AAAA (31/12/2026)</option>
                      <option value="MM/DD/YYYY">MM/DD/AAAA (12/31/2026)</option>
                      <option value="YYYY-MM-DD">AAAA-MM-DD (2026-12-31)</option>
                      <option value="D MMMM YYYY">D Mes AAAA (31 Diciembre 2026)</option>
                      <option value="D MMM YY">D Mes AA (31 Dic 26)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Formato de números</label>
                    <select className="w-full text-xs border rounded-md px-2.5 py-1.5 text-gray-700" value={visualSettings.numberFormat} onChange={(e) => setVisualSettings(s => ({ ...s, numberFormat: e.target.value }))}>
                      <option value="es-ES">1.234,56 (España)</option>
                      <option value="en-US">1,234.56 (EEUU)</option>
                      <option value="de-DE">1.234,56 (Alemania)</option>
                      <option value="fr-FR">1 234,56 (Francia)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* ─── Estilo de botones ─── */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5">
                <h2 className="text-sm font-bold text-[#3F4694] mb-1 flex items-center gap-2"><PenLine className="w-4 h-4" /> Estilo de botones y CTAs</h2>
                <p className="text-[11px] text-gray-400 mb-4">Estilo por defecto de los botones de acción en tus documentos.</p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Estilo</label>
                    <div className="flex gap-2">
                      {[{ val: "filled", label: "Relleno" }, { val: "outline", label: "Contorno" }, { val: "ghost", label: "Fantasma" }].map(bs => (
                        <button key={bs.val} onClick={() => setVisualSettings(s => ({ ...s, buttonStyle: bs.val }))} className={`flex-1 px-3 py-2 border rounded-lg text-xs transition-all ${visualSettings.buttonStyle === bs.val ? "border-[#3F4694] bg-[#3F4694]/5 text-[#3F4694] font-semibold" : "border-gray-200 text-gray-500"}`}>
                          {bs.label}
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-[11px] text-gray-500 font-medium mb-1 block">Radio de bordes (px)</label>
                    <div className="flex items-center gap-3">
                      <input type="range" min="0" max="24" value={visualSettings.buttonRadius} onChange={(e) => setVisualSettings(s => ({ ...s, buttonRadius: e.target.value }))} className="flex-1 accent-[#3F4694]" />
                      <span className="text-xs text-gray-500 w-8 text-right">{visualSettings.buttonRadius}px</span>
                    </div>
                    <div className="flex gap-2 mt-2">
                      <div className="px-4 py-1.5 text-xs font-medium text-white" style={{ backgroundColor: form.accentColor, borderRadius: `${visualSettings.buttonRadius}px` }}>Acento</div>
                      <div className="px-4 py-1.5 text-xs font-medium text-white" style={{ backgroundColor: form.primaryColor, borderRadius: `${visualSettings.buttonRadius}px` }}>Principal</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Preview sidebar */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-5 sticky top-6">
            <h3 className="text-sm font-bold text-[#3F4694] mb-3">Vista previa del documento</h3>
            <div className="rounded-lg overflow-hidden border" style={{ backgroundColor: form.backgroundColor, borderColor: activeTab === "visual" && visualSettings.documentBorder ? visualSettings.documentBorderColor : "#e5e7eb", borderWidth: activeTab === "visual" && visualSettings.documentBorder ? `${visualSettings.documentBorderWidth}px` : "1px", borderRadius: activeTab === "visual" ? `${visualSettings.documentBorderRadius}px` : "8px", boxShadow: activeTab === "visual" && visualSettings.documentShadow ? "0 4px 12px rgba(0,0,0,0.1)" : "none" }}>
              {/* Header */}
              <div className="px-3 py-2.5 flex items-center justify-between" style={{ backgroundColor: activeTab === "visual" ? visualSettings.headerBgColor : form.primaryColor }}>
                <div>
                  {visualSettings.logoUrl ? (
                    <img src={visualSettings.logoUrl} alt="Logo" className="h-5 object-contain" />
                  ) : null}
                  <p className="text-xs font-semibold mt-0.5" style={{ fontFamily: visualSettings.headingFont || form.fontFamily, color: activeTab === "visual" ? visualSettings.headerTextColor : "#ffffff" }}>
                    {form.companyName || "Tu empresa SL"}
                  </p>
                  <p className="text-[9px] opacity-70" style={{ color: activeTab === "visual" ? visualSettings.headerTextColor : "#ffffff" }}>{form.taxId || "B12345678"}</p>
                </div>
                <div className="text-right">
                  <p className="text-[8px] opacity-60" style={{ color: activeTab === "visual" ? visualSettings.headerTextColor : "#ffffff" }}>Factura</p>
                  <p className="text-[9px] font-bold" style={{ color: activeTab === "visual" ? visualSettings.headerTextColor : "#ffffff" }}>FAC-0001</p>
                </div>
              </div>
              {/* Body */}
              <div className="p-3 space-y-2">
                <p style={{ fontFamily: visualSettings.headingFont || form.fontFamily, fontSize: "11px", fontWeight: Number(visualSettings.headingWeight || 700), color: visualSettings.headingColor || "#1a1a1a" }}>Factura de ejemplo</p>
                <div className="space-y-1">
                  <div className="h-1.5 rounded" style={{ backgroundColor: form.primaryColor, width: "55%", opacity: 0.15 }} />
                  <div className="h-1.5 rounded" style={{ backgroundColor: form.primaryColor, width: "75%", opacity: 0.1 }} />
                </div>
                {/* Mini table */}
                <div className="rounded overflow-hidden mt-1" style={{ border: visualSettings.tableShowBorders ? `1px solid ${visualSettings.tableBorderColor}` : "none" }}>
                  <div className="flex text-[7px] font-bold px-2 py-1" style={{ backgroundColor: visualSettings.tableHeaderBg, color: visualSettings.tableHeaderTextColor }}>
                    <span className="flex-1">Concepto</span><span className="w-10 text-right">Total</span>
                  </div>
                  {[0,1].map(i => (
                    <div key={i} className="flex text-[7px] px-2 py-0.5" style={{ backgroundColor: visualSettings.tableAlternateRows && i % 2 === 1 ? visualSettings.tableAlternateColor : "transparent", color: visualSettings.bodyColor }}>
                      <span className="flex-1">Servicio {i+1}</span><span className="w-10 text-right">0,00 €</span>
                    </div>
                  ))}
                </div>
                {/* Totals */}
                <div className="flex justify-end pt-1">
                  <div className="text-right">
                    <p className="text-[7px]" style={{ color: visualSettings.bodyColor }}>Base: 0,00 €</p>
                    <p className="text-[7px]" style={{ color: visualSettings.bodyColor }}>IVA 21%: 0,00 €</p>
                    <p className="text-[8px] font-bold" style={{ color: visualSettings.headingColor }}>Total: 0,00 €</p>
                  </div>
                </div>
                <div className="flex gap-1.5 mt-1">
                  <div className="px-2 py-0.5 text-[7px] text-white font-medium" style={{ backgroundColor: form.accentColor, borderRadius: `${visualSettings.buttonRadius || 6}px` }}>Pagar</div>
                  <div className="px-2 py-0.5 text-[7px] text-white font-medium" style={{ backgroundColor: form.primaryColor, borderRadius: `${visualSettings.buttonRadius || 6}px` }}>Descargar</div>
                </div>
              </div>
              {/* Footer */}
              {visualSettings.showFooter && (
                <div className="px-3 py-1.5 text-center" style={{ backgroundColor: visualSettings.footerBgColor }}>
                  <p className="text-[7px]" style={{ color: visualSettings.footerTextColor }}>{visualSettings.footerText || "www.tuempresa.es | info@tuempresa.es"}</p>
                </div>
              )}
            </div>

            {/* Color swatches */}
            <div className="mt-3 flex items-center gap-2">
              <p className="text-[9px] text-gray-400">Colores:</p>
              {[form.primaryColor, form.secondaryColor, form.accentColor, form.backgroundColor].map((c, i) => (
                <div key={i} className="w-5 h-5 rounded-full border border-gray-200 shadow-sm" style={{ backgroundColor: c }} title={c} />
              ))}
            </div>
          </div>

          <Button
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending}
            className="w-full bg-[#3F4694] hover:bg-[#2e3570] text-white sticky top-[400px]"
            data-testid="button-save-settings"
          >
            <Save className="w-4 h-4 mr-2" />
            {saveMutation.isPending ? "Guardando..." : "Guardar ajustes"}
          </Button>
        </div>
      </div>
    </div>
  );
}
