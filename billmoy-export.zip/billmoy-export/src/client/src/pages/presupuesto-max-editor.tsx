import { useState, useRef, useEffect, useCallback } from "react";
import { Link } from "wouter";
import {
  ArrowLeft, Plus, Trash2, GripVertical, Type, Image, ChevronDown, ChevronUp,
  Settings2, Copy, Eye, EyeOff, MoveUp, MoveDown, Minus, Save, Send,
  MousePointer2, ZoomIn, ZoomOut, Columns2, Columns3, LayoutGrid,
  AlignLeft, AlignCenter, AlignRight, Bold, Italic, Underline, Calculator,
  Layers, Award, FileText, LayoutList, Square, PanelRight, Palette, Globe,
  Maximize2, ArrowDown, Undo2, List, Play, MapPin, Quote, Hash, Table2,
  QrCode, Stamp, MoveVertical, SeparatorHorizontal, Share2, CreditCard,
  Repeat, FileCheck, Upload, Paintbrush, Ruler, BoxSelect, CircleDot,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import logoBlueSrc from "@assets/logo-blue.png";
import {
  DndContext, closestCenter, pointerWithin, rectIntersection,
  PointerSensor, useSensor, useSensors, useDroppable, useDraggable,
  DragEndEvent, DragOverlay, DragStartEvent, DragOverEvent, UniqueIdentifier,
  CollisionDetection, getFirstCollision,
} from "@dnd-kit/core";
import {
  SortableContext, verticalListSortingStrategy, useSortable, arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

// ═══════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════
interface BlockStyle {
  fontFamily?: string;
  fontSize?: number;
  fontWeight?: string;
  fontStyle?: string;
  textDecoration?: string;
  textTransform?: string;
  letterSpacing?: number;
  lineHeight?: number;
  wordSpacing?: number;
  color?: string;
  textAlign?: string;
  backgroundColor?: string;
  paddingTop?: number;
  paddingBottom?: number;
  paddingLeft?: number;
  paddingRight?: number;
  marginTop?: number;
  marginBottom?: number;
  marginLeft?: number;
  marginRight?: number;
  borderRadius?: number;
  borderWidth?: number;
  borderStyle?: string;
  borderColor?: string;
  boxShadowX?: number;
  boxShadowY?: number;
  boxShadowBlur?: number;
  boxShadowSpread?: number;
  boxShadowColor?: string;
  boxShadowEnabled?: boolean;
  opacity?: number;
  gradient?: boolean;
  gradientDirection?: number;
  gradientColor1?: string;
  gradientColor2?: string;
  minHeight?: number;
  width?: string;
}

interface EditorBlock {
  id: string;
  type: string;
  data: Record<string, any>;
  style: BlockStyle;
}

interface EditorColumn {
  id: string;
  width: number;
  blocks: EditorBlock[];
  style: { backgroundColor?: string; paddingTop?: number; paddingBottom?: number; paddingLeft?: number; paddingRight?: number; verticalAlign?: string; borderRadius?: number; borderWidth?: number; borderColor?: string; borderStyle?: string };
}

interface EditorRow {
  id: string;
  columns: EditorColumn[];
  style: { backgroundColor?: string; paddingTop?: number; paddingBottom?: number; paddingLeft?: number; paddingRight?: number; borderRadius?: number; borderWidth?: number; borderColor?: string; borderStyle?: string; minHeight?: number; gradient?: boolean; gradientDirection?: number; gradientColor1?: string; gradientColor2?: string; verticalAlign?: string };
  visible?: boolean;
}

interface EditorPage {
  id: string;
  pageNumber: number;
  rows: EditorRow[];
}

interface DocumentSettings {
  orientation: "vertical" | "horizontal";
  pageMarginTop: number;
  pageMarginBottom: number;
  pageMarginLeft: number;
  pageMarginRight: number;
  pageBackground: string;
  pageBorderEnabled: boolean;
  pageBorderColor: string;
  pageBorderWidth: number;
  brandPrimary: string;
  brandSecondary: string;
  brandAccent: string;
  brandBackground: string;
  defaultFont: string;
  defaultHeadingSize: number;
  defaultBodySize: number;
  headingColor: string;
  headingWeight: string;
  headingTransform: string;
  textColor: string;
  textLineHeight: number;
  logoUrl: string;
  logoPosition: string;
  docType: string;
  paymentMethods: string[];
  iban: string;
  paymentNotes: string;
  isRecurring: boolean;
  recurringFrequency: string;
}

type Selection =
  | { type: "row"; rowId: string }
  | { type: "column"; rowId: string; colId: string }
  | { type: "block"; rowId: string; colId: string; blockId: string }
  | null;

// ═══════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════
let _counter = 0;
function uid(prefix = "e") {
  return `${prefix}_${Date.now().toString(36)}_${(++_counter).toString(36)}`;
}

const FONTS = ["Catamaran", "Arial", "Helvetica", "Georgia", "Times New Roman", "Courier New", "Roboto", "Montserrat", "Lato", "Open Sans", "Playfair Display", "Raleway"];
const FONT_SIZES = [8, 9, 10, 11, 12, 13, 14, 16, 18, 20, 22, 24, 28, 32, 36, 40, 48, 56, 64, 72, 80, 96];

function defaultBlockStyle(): BlockStyle {
  return { fontFamily: "Catamaran", fontSize: 14, color: "#333333", textAlign: "left", paddingTop: 8, paddingBottom: 8, paddingLeft: 0, paddingRight: 0, opacity: 100, lineHeight: 1.5, letterSpacing: 0 };
}

function defaultColumnStyle() {
  return { backgroundColor: "transparent", paddingTop: 8, paddingBottom: 8, paddingLeft: 12, paddingRight: 12, verticalAlign: "top" };
}

function defaultRowStyle() {
  return { backgroundColor: "transparent", paddingTop: 4, paddingBottom: 4, paddingLeft: 0, paddingRight: 0 };
}

function defaultDocSettings(): DocumentSettings {
  return {
    orientation: "vertical", pageMarginTop: 0, pageMarginBottom: 0, pageMarginLeft: 0, pageMarginRight: 0,
    pageBackground: "#ffffff", pageBorderEnabled: false, pageBorderColor: "#e5e7eb", pageBorderWidth: 1,
    brandPrimary: "#3F4694", brandSecondary: "#1a1a1a", brandAccent: "#F25075", brandBackground: "#FBFBFB",
    defaultFont: "Catamaran", defaultHeadingSize: 28, defaultBodySize: 14,
    headingColor: "#1a1a1a", headingWeight: "700", headingTransform: "none",
    textColor: "#555555", textLineHeight: 1.5,
    logoUrl: "", logoPosition: "left",
    docType: "presupuesto", paymentMethods: ["transferencia"], iban: "", paymentNotes: "",
    isRecurring: false, recurringFrequency: "mensual",
  };
}

function buildBackground(style: any): string | undefined {
  if (style.gradient && style.gradientColor1 && style.gradientColor2) {
    return `linear-gradient(${style.gradientDirection || 180}deg, ${style.gradientColor1}, ${style.gradientColor2})`;
  }
  return undefined;
}

function buildBoxShadow(s: BlockStyle): string | undefined {
  if (!s.boxShadowEnabled) return undefined;
  const inset = "";
  return `${inset}${s.boxShadowX || 0}px ${s.boxShadowY || 2}px ${s.boxShadowBlur || 8}px ${s.boxShadowSpread || 0}px ${s.boxShadowColor || "rgba(0,0,0,0.15)"}`;
}

// ═══════════════════════════════════════════════════════
// BLOCK FACTORY
// ═══════════════════════════════════════════════════════
function makeBlock(type: string): EditorBlock {
  const base: EditorBlock = { id: uid("blk"), type, data: {}, style: defaultBlockStyle() };
  switch (type) {
    case "heading":
      base.data = { text: "Escribe tu título aquí", level: 2 };
      base.style = { ...base.style, fontSize: 28, fontWeight: "700", color: "#1a1a1a" };
      break;
    case "text":
      base.data = { text: "Escribe tu texto aquí. Haz clic para editar directamente." };
      base.style = { ...base.style, fontSize: 14, color: "#555555" };
      break;
    case "image":
      base.data = { url: "", alt: "Imagen", fit: "cover" };
      break;
    case "logo":
      base.data = { url: "", maxWidth: 180, alignment: "left" };
      break;
    case "button":
      base.data = { text: "Botón de acción", url: "#", variant: "primary" };
      base.style = { ...base.style, textAlign: "center" };
      break;
    case "spacer":
      base.data = { height: 32 };
      break;
    case "separator":
      base.data = { lineColor: "#e5e7eb", lineWidth: 1, lineStyle: "solid" };
      break;
    case "social":
      base.data = { networks: ["instagram", "linkedin", "behance"] };
      base.style = { ...base.style, textAlign: "center" };
      break;
    case "presupuesto":
      base.data = {
        clientName: "", clientNif: "", numero: "0001", fecha: "",
        items: [{ concepto: "Servicio ejemplo", descripcion: "Descripción del servicio", cantidad: 1, precio: 0, descuento: 0, iva: 21 }],
      };
      break;
    case "list":
      base.data = { items: ["Elemento 1", "Elemento 2", "Elemento 3"], listStyle: "disc" };
      break;
    case "video":
      base.data = { url: "", placeholder: "Pega la URL del vídeo" };
      break;
    case "table":
      base.data = { rows: 3, cols: 3, cells: [["", "", ""], ["", "", ""], ["", "", ""]] };
      break;
    case "quote":
      base.data = { text: "Cita o testimonio aquí", author: "Nombre" };
      base.style = { ...base.style, fontStyle: "italic", fontSize: 16, borderWidth: 3, borderColor: "#3F4694", borderStyle: "solid", paddingLeft: 16 };
      break;
    case "counter":
      base.data = { number: "150", suffix: "+", label: "Proyectos realizados" };
      base.style = { ...base.style, textAlign: "center", fontSize: 48, fontWeight: "900" };
      break;
    case "qrcode":
      base.data = { value: "https://tuempresa.es", size: 120 };
      base.style = { ...base.style, textAlign: "center" };
      break;
    case "map":
      base.data = { address: "Tu dirección aquí" };
      break;
    default:
      break;
  }
  return base;
}

function makeRow(colCount: number, firstBlockType?: string): EditorRow {
  const widths = colCount === 1 ? [100] : colCount === 2 ? [50, 50] : [33.33, 33.33, 33.34];
  const cols: EditorColumn[] = widths.map((w, i) => ({
    id: uid("col"),
    width: w,
    blocks: i === 0 && firstBlockType ? [makeBlock(firstBlockType)] : [],
    style: defaultColumnStyle(),
  }));
  return { id: uid("row"), columns: cols, style: defaultRowStyle(), visible: true };
}

// ═══════════════════════════════════════════════════════
// DEFAULT PAGES
// ═══════════════════════════════════════════════════════
function defaultPages(): EditorPage[] {
  const coverTitleBlock = makeBlock("heading");
  coverTitleBlock.data.text = "Presupuesto";
  coverTitleBlock.style = { ...coverTitleBlock.style, fontSize: 48, fontWeight: "700", color: "#3F4694", paddingTop: 80 };
  const coverSubBlock = makeBlock("heading");
  coverSubBlock.data = { text: "Identidad de marca & Landing", level: 3 };
  coverSubBlock.style = { ...coverSubBlock.style, fontSize: 24, fontWeight: "300", color: "#666666", paddingBottom: 60 };
  const coverFooterRow = makeRow(3);
  coverFooterRow.style = { ...coverFooterRow.style, backgroundColor: "#3F4694", paddingTop: 24, paddingBottom: 24, paddingLeft: 24, paddingRight: 24 };
  const dirBlock = makeBlock("text"); dirBlock.data.text = "Dirección\nDirección de tu empresa\nCiudad, CP"; dirBlock.style = { ...dirBlock.style, color: "#ffffff", fontSize: 11 };
  const telBlock = makeBlock("text"); telBlock.data.text = "Teléfono\n+34 600 000 000"; telBlock.style = { ...telBlock.style, color: "#ffffff", fontSize: 11 };
  const webBlock = makeBlock("text"); webBlock.data.text = "Online\nwww.tuempresa.es\nhola@tuempresa.es"; webBlock.style = { ...webBlock.style, color: "#ffffff", fontSize: 11 };
  coverFooterRow.columns[0].blocks = [dirBlock];
  coverFooterRow.columns[1].blocks = [telBlock];
  coverFooterRow.columns[2].blocks = [webBlock];
  coverFooterRow.columns.forEach(c => { c.style = { ...c.style, paddingTop: 4, paddingBottom: 4 }; });

  const coverRow1 = makeRow(1);
  coverRow1.columns[0].blocks = [coverTitleBlock, coverSubBlock];
  coverRow1.columns[0].style.paddingLeft = 48;

  const p1: EditorPage = { id: uid("pg"), pageNumber: 1, rows: [coverRow1, coverFooterRow] };

  const sectionBar = makeBlock("separator"); sectionBar.data = { lineColor: "#000000", lineWidth: 4, lineStyle: "solid" };
  const secNum = makeBlock("heading"); secNum.data = { text: "1.", level: 1 }; secNum.style = { ...secNum.style, fontSize: 48, fontWeight: "900", color: "#000000", paddingBottom: 0 };
  const secTitle = makeBlock("heading"); secTitle.data = { text: "Presentación", level: 2 }; secTitle.style = { ...secTitle.style, fontSize: 32, fontWeight: "300", color: "#000000", paddingTop: 0 };
  const aboutHeading = makeBlock("heading"); aboutHeading.data = { text: "NOSOTROS", level: 3 }; aboutHeading.style = { ...aboutHeading.style, fontSize: 13, fontWeight: "900", color: "#000000" };
  const aboutText = makeBlock("text"); aboutText.data.text = "Somos una agencia creativa formada por diferentes profesionales con distintas especialidades: diseño gráfico, diseño web, redes sociales, marketing digital, realización de video y contenido digital.";
  const aboutRight = makeBlock("text"); aboutRight.data.text = "A TU LADO EN CADA PASO\n\nEstaremos junto a ti en cada una de las decisiones que tomes, siempre que nos necesites, para asesorarte y aconsejarte.";

  const aboutHeaderRow = makeRow(1); aboutHeaderRow.columns[0].blocks = [sectionBar, secNum, secTitle]; aboutHeaderRow.columns[0].style.paddingLeft = 32;
  const aboutContentRow = makeRow(2); aboutContentRow.columns[0].blocks = [aboutHeading, aboutText]; aboutContentRow.columns[0].style.paddingLeft = 32; aboutContentRow.columns[1].blocks = [aboutRight]; aboutContentRow.columns[1].style.paddingRight = 32;

  const p2: EditorPage = { id: uid("pg"), pageNumber: 2, rows: [aboutHeaderRow, aboutContentRow] };

  const presBar = makeBlock("separator"); presBar.data = { lineColor: "#000000", lineWidth: 4, lineStyle: "solid" };
  const presNum = makeBlock("heading"); presNum.data = { text: "2.", level: 1 }; presNum.style = { ...presNum.style, fontSize: 48, fontWeight: "900", color: "#000000", paddingBottom: 0 };
  const presTitle = makeBlock("heading"); presTitle.data = { text: "Presupuesto", level: 2 }; presTitle.style = { ...presTitle.style, fontSize: 32, fontWeight: "300", color: "#000000", paddingTop: 0 };
  const presWidget = makeBlock("presupuesto");

  const presHeaderRow = makeRow(1); presHeaderRow.columns[0].blocks = [presBar, presNum, presTitle]; presHeaderRow.columns[0].style.paddingLeft = 32;
  const presBodyRow = makeRow(1); presBodyRow.columns[0].blocks = [presWidget]; presBodyRow.columns[0].style.paddingLeft = 32; presBodyRow.columns[0].style.paddingRight = 32;

  const p3: EditorPage = { id: uid("pg"), pageNumber: 3, rows: [presHeaderRow, presBodyRow] };

  const closingTitle = makeBlock("heading"); closingTitle.data = { text: "¡Gracias!", level: 1 }; closingTitle.style = { ...closingTitle.style, fontSize: 56, fontWeight: "700", color: "#3F4694", paddingTop: 100 };
  const closingSub = makeBlock("text"); closingSub.data.text = "SOMOS EL ALIADO QUE NECESITA TU MARCA"; closingSub.style = { ...closingSub.style, fontSize: 12, fontWeight: "700", color: "#000000", paddingBottom: 80 };
  const closeRow1 = makeRow(1); closeRow1.columns[0].blocks = [closingTitle, closingSub]; closeRow1.columns[0].style.paddingLeft = 48;

  const closeFooterRow = makeRow(3);
  closeFooterRow.style = { ...closeFooterRow.style, backgroundColor: "#3F4694", paddingTop: 24, paddingBottom: 24, paddingLeft: 24, paddingRight: 24 };
  const d2 = makeBlock("text"); d2.data.text = "Dirección\nDirección de tu empresa"; d2.style = { ...d2.style, color: "#ffffff", fontSize: 11 };
  const t2 = makeBlock("text"); t2.data.text = "Teléfono\n+34 600 000 000"; t2.style = { ...t2.style, color: "#ffffff", fontSize: 11 };
  const w2 = makeBlock("text"); w2.data.text = "Online\nwww.tuempresa.es\nhola@tuempresa.es"; w2.style = { ...w2.style, color: "#ffffff", fontSize: 11 };
  closeFooterRow.columns[0].blocks = [d2]; closeFooterRow.columns[1].blocks = [t2]; closeFooterRow.columns[2].blocks = [w2];
  closeFooterRow.columns.forEach(c => { c.style = { ...c.style, paddingTop: 4, paddingBottom: 4 }; });

  const p4: EditorPage = { id: uid("pg"), pageNumber: 4, rows: [closeRow1, closeFooterRow] };

  return [p1, p2, p3, p4];
}

// ═══════════════════════════════════════════════════════
// INLINE EDIT
// ═══════════════════════════════════════════════════════
function InlineEdit({ value, onChange, style, multiline = false, placeholder = "Escribe aquí..." }: {
  value: string; onChange: (v: string) => void; style?: Record<string, any>; multiline?: boolean; placeholder?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [focused, setFocused] = useState(false);

  useEffect(() => {
    if (ref.current && !focused) ref.current.textContent = value || "";
  }, [value, focused]);

  return (
    <div
      ref={ref}
      contentEditable
      suppressContentEditableWarning
      className={`outline-none transition-all ${!value && !focused ? "opacity-40" : ""}`}
      style={{ minHeight: "1em", whiteSpace: multiline ? "pre-wrap" : "normal", cursor: "text", ...style }}
      data-placeholder={placeholder}
      onFocus={() => setFocused(true)}
      onBlur={(e) => { setFocused(false); const t = e.currentTarget.textContent || ""; if (t !== value) onChange(t); }}
      onKeyDown={(e) => { if (!multiline && e.key === "Enter") { e.preventDefault(); (e.target as HTMLElement).blur(); } }}
    />
  );
}

// ═══════════════════════════════════════════════════════
// BLOCK RENDERERS
// ═══════════════════════════════════════════════════════
function RenderBlock({ block, onChange }: { block: EditorBlock; onChange: (d: Record<string, any>) => void }) {
  const s = block.style;
  const baseTextStyle: Record<string, any> = {
    fontFamily: s.fontFamily || "Catamaran",
    fontSize: s.fontSize || 14,
    fontWeight: s.fontWeight || "400",
    fontStyle: s.fontStyle || "normal",
    textDecoration: s.textDecoration || "none",
    textTransform: s.textTransform || "none",
    letterSpacing: s.letterSpacing || 0,
    lineHeight: s.lineHeight || 1.5,
    color: s.color || "#333",
    textAlign: s.textAlign || "left",
  };

  switch (block.type) {
    case "heading":
      return <InlineEdit value={block.data.text || ""} onChange={(v) => onChange({ ...block.data, text: v })} style={baseTextStyle} placeholder="Escribe un título..." />;
    case "text":
      return <InlineEdit value={block.data.text || ""} onChange={(v) => onChange({ ...block.data, text: v })} style={baseTextStyle} multiline placeholder="Escribe tu texto..." />;
    case "image":
      return block.data.url ? (
        <img src={block.data.url} alt={block.data.alt || ""} className="w-full rounded" style={{ objectFit: block.data.fit || "cover", borderRadius: s.borderRadius }} />
      ) : (
        <div className="w-full py-12 bg-gray-50 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center hover:border-[#3F4694]/30 transition-colors cursor-pointer">
          <Image className="w-8 h-8 text-gray-300 mb-2" />
          <span className="text-xs text-gray-400">Haz clic o arrastra una imagen</span>
        </div>
      );
    case "logo":
      return block.data.url || logoBlueSrc ? (
        <div style={{ textAlign: (block.data.alignment || "left") as any }}>
          <img src={block.data.url || logoBlueSrc} alt="Logo" style={{ maxWidth: block.data.maxWidth || 180, display: "inline-block" }} />
        </div>
      ) : (
        <div className="w-40 h-24 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center hover:border-[#3F4694]/30 transition-colors cursor-pointer">
          <Plus className="w-5 h-5 text-gray-300 mb-1" />
          <span className="text-[10px] text-gray-400">Añade tu logo</span>
        </div>
      );
    case "button": {
      const v = block.data.variant || "primary";
      const btnCls = v === "primary" ? "bg-[#F25075] text-white" : v === "secondary" ? "bg-[#3F4694] text-white" : "border-2 border-[#3F4694] text-[#3F4694]";
      return (
        <div style={{ textAlign: (s.textAlign || "center") as any }}>
          <span className={`inline-block px-8 py-3 rounded-md text-sm font-semibold ${btnCls}`} style={{ borderRadius: s.borderRadius }}>
            <InlineEdit value={block.data.text || ""} onChange={(v) => onChange({ ...block.data, text: v })} style={{ color: "inherit", fontSize: s.fontSize || 14, fontFamily: s.fontFamily }} placeholder="Texto del botón" />
          </span>
        </div>
      );
    }
    case "spacer":
      return (
        <div className="relative group flex items-center justify-center border border-dashed border-gray-200 rounded hover:border-[#3F4694]/30 transition-colors" style={{ height: block.data.height || 32 }}>
          <span className="opacity-0 group-hover:opacity-100 text-[10px] text-gray-400 transition-opacity">{block.data.height || 32}px</span>
        </div>
      );
    case "separator":
      return <hr style={{ borderColor: block.data.lineColor || "#e5e7eb", borderWidth: block.data.lineWidth || 1, borderStyle: block.data.lineStyle || "solid" }} />;
    case "social": {
      const icons: Record<string, string> = { instagram: "IG", linkedin: "in", behance: "Be", dribbble: "Dr", twitter: "X", facebook: "Fb" };
      return (
        <div className="flex gap-3 justify-center py-1">
          {(block.data.networks || []).map((n: string) => (
            <div key={n} className="w-9 h-9 rounded-full bg-[#3F4694] text-white flex items-center justify-center text-xs font-semibold">{icons[n] || n[0].toUpperCase()}</div>
          ))}
        </div>
      );
    }
    case "presupuesto":
      return <PresupuestoTable data={block.data} onChange={onChange} />;
    case "list":
      return (
        <ul className="space-y-1" style={{ ...baseTextStyle, listStyleType: block.data.listStyle || "disc", paddingLeft: 20 }}>
          {(block.data.items || []).map((item: string, i: number) => (
            <li key={i}><InlineEdit value={item} onChange={(v) => { const items = [...(block.data.items || [])]; items[i] = v; onChange({ ...block.data, items }); }} style={baseTextStyle} placeholder="Elemento..." /></li>
          ))}
        </ul>
      );
    case "quote":
      return (
        <div style={{ borderLeft: `${s.borderWidth || 3}px ${s.borderStyle || "solid"} ${s.borderColor || "#3F4694"}`, paddingLeft: s.paddingLeft || 16 }}>
          <InlineEdit value={block.data.text || ""} onChange={(v) => onChange({ ...block.data, text: v })} style={{ ...baseTextStyle, fontStyle: "italic" }} multiline placeholder="Cita o testimonio..." />
          <InlineEdit value={block.data.author || ""} onChange={(v) => onChange({ ...block.data, author: v })} style={{ fontSize: 12, fontWeight: "600", color: "#999", marginTop: 8 }} placeholder="— Autor" />
        </div>
      );
    case "counter":
      return (
        <div style={{ textAlign: (s.textAlign || "center") as any }}>
          <span style={{ fontSize: s.fontSize || 48, fontWeight: s.fontWeight || "900", color: s.color || "#3F4694", fontFamily: s.fontFamily }}>{block.data.number || "0"}{block.data.suffix || ""}</span>
          <p style={{ fontSize: 12, color: "#999", marginTop: 4 }}>{block.data.label || "Etiqueta"}</p>
        </div>
      );
    case "qrcode":
      return (
        <div style={{ textAlign: "center" }}>
          <div className="inline-block bg-gray-100 border border-gray-200 rounded-lg p-4" style={{ width: block.data.size || 120, height: block.data.size || 120 }}>
            <QrCode className="w-full h-full text-gray-600" />
          </div>
          <p className="text-[10px] text-gray-400 mt-1">Código QR</p>
        </div>
      );
    case "video":
      return (
        <div className="w-full py-10 bg-gray-900 rounded-lg flex flex-col items-center justify-center cursor-pointer">
          <Play className="w-10 h-10 text-white/60 mb-2" />
          <span className="text-xs text-white/40">{block.data.url || "Pega la URL del vídeo"}</span>
        </div>
      );
    case "map":
      return (
        <div className="w-full py-10 bg-gray-100 rounded-lg flex flex-col items-center justify-center border border-gray-200">
          <MapPin className="w-8 h-8 text-gray-400 mb-2" />
          <span className="text-xs text-gray-500">{block.data.address || "Tu dirección aquí"}</span>
        </div>
      );
    case "table":
      return (
        <table className="w-full text-xs border-collapse border border-gray-200">
          <tbody>
            {(block.data.cells || []).map((row: string[], ri: number) => (
              <tr key={ri}>{row.map((cell: string, ci: number) => (
                <td key={ci} className="border border-gray-200 p-2"><InlineEdit value={cell} onChange={(v) => { const cells = [...(block.data.cells || [])]; cells[ri] = [...cells[ri]]; cells[ri][ci] = v; onChange({ ...block.data, cells }); }} style={{ fontSize: 12 }} placeholder="..." /></td>
              ))}</tr>
            ))}
          </tbody>
        </table>
      );
    default:
      return <div className="text-xs text-gray-400 p-2">Bloque: {block.type}</div>;
  }
}

// ═══════════════════════════════════════════════════════
// PRESUPUESTO TABLE (smart widget)
// ═══════════════════════════════════════════════════════
function PresupuestoTable({ data, onChange }: { data: Record<string, any>; onChange: (d: Record<string, any>) => void }) {
  const items = data.items || [];
  const upd = (k: string, v: any) => onChange({ ...data, [k]: v });
  const updateItem = (idx: number, key: string, val: any) => {
    const newItems = [...items];
    newItems[idx] = { ...newItems[idx], [key]: ["cantidad", "precio", "descuento", "iva"].includes(key) ? Number(val) || 0 : val };
    upd("items", newItems);
  };
  const addItem = () => upd("items", [...items, { concepto: "", descripcion: "", cantidad: 1, precio: 0, descuento: 0, iva: 21 }]);
  const removeItem = (idx: number) => upd("items", items.filter((_: any, i: number) => i !== idx));

  const lineBase = (it: any) => { const s = it.cantidad * it.precio; return s * (1 - (it.descuento || 0) / 100); };
  const lineTotal = (it: any) => lineBase(it) * (1 + (it.iva || 0) / 100);
  const neto = items.reduce((s: number, i: any) => s + i.cantidad * i.precio, 0);
  const descTotal = items.reduce((s: number, i: any) => s + i.cantidad * i.precio * (i.descuento || 0) / 100, 0);
  const baseImp = neto - descTotal;
  const ivaTotal = items.reduce((s: number, i: any) => s + lineBase(i) * (i.iva || 0) / 100, 0);
  const total = baseImp + ivaTotal;

  return (
    <div data-testid="presupuesto-table">
      <div className="flex justify-between items-start mb-4 text-xs">
        <div>
          <span className="text-gray-400 font-semibold uppercase tracking-wider text-[10px]">CLIENTE</span>
          <InlineEdit value={data.clientName || ""} onChange={(v) => upd("clientName", v)} style={{ fontSize: 13, fontWeight: "700", color: "#000" }} placeholder="Nombre del cliente" />
        </div>
        <div className="text-right">
          <div className="text-gray-400"><span className="font-semibold">N.º:</span> <InlineEdit value={data.numero || ""} onChange={(v) => upd("numero", v)} style={{ display: "inline", fontSize: 12, fontWeight: "600" }} placeholder="0001" /></div>
          <div className="text-gray-400"><span className="font-semibold">FECHA:</span> <InlineEdit value={data.fecha || ""} onChange={(v) => upd("fecha", v)} style={{ display: "inline", fontSize: 12 }} placeholder="dd/mm/aaaa" /></div>
        </div>
      </div>
      <table className="w-full text-xs border-collapse">
        <thead>
          <tr className="border-b-2 border-black">
            <th className="text-left py-2 font-semibold text-gray-700 w-[36%]">Producto / Servicio</th>
            <th className="text-center py-2 font-semibold text-gray-700 w-[7%]">Cant.</th>
            <th className="text-right py-2 font-semibold text-gray-700 w-[11%]">Precio</th>
            <th className="text-center py-2 font-semibold text-gray-700 w-[7%]">Desc.</th>
            <th className="text-right py-2 font-semibold text-gray-700 w-[11%]">Importe</th>
            <th className="text-center py-2 font-semibold text-gray-700 w-[7%]">IVA</th>
            <th className="text-right py-2 font-semibold text-gray-700 w-[13%]">Total</th>
            <th className="w-[4%]"></th>
          </tr>
        </thead>
        <tbody>
          {items.map((item: any, idx: number) => (
            <tr key={idx} className="group border-b border-gray-100 hover:bg-gray-50/50">
              <td className="py-2 align-top pr-2">
                <InlineEdit value={item.concepto} onChange={(v) => updateItem(idx, "concepto", v)} style={{ fontSize: 12, fontWeight: "500", color: "#000" }} placeholder="Concepto" />
                <InlineEdit value={item.descripcion || ""} onChange={(v) => updateItem(idx, "descripcion", v)} style={{ fontSize: 10, color: "#999", marginTop: 2, lineHeight: 1.3 }} placeholder="Descripción..." multiline />
              </td>
              <td className="py-2 text-center align-top"><input type="number" value={item.cantidad} onChange={(e) => updateItem(idx, "cantidad", e.target.value)} className="w-10 text-center text-xs bg-transparent border-b border-transparent hover:border-gray-300 focus:border-[#3F4694] outline-none" /></td>
              <td className="py-2 text-right align-top"><input type="number" value={item.precio} onChange={(e) => updateItem(idx, "precio", e.target.value)} className="w-14 text-right text-xs bg-transparent border-b border-transparent hover:border-gray-300 focus:border-[#3F4694] outline-none" /></td>
              <td className="py-2 text-center align-top"><input type="number" value={item.descuento || 0} onChange={(e) => updateItem(idx, "descuento", e.target.value)} className="w-10 text-center text-xs bg-transparent border-b border-transparent hover:border-gray-300 focus:border-[#3F4694] outline-none" /><span className="text-[9px] text-gray-400">%</span></td>
              <td className="py-2 text-right align-top text-gray-600">{lineBase(item).toFixed(2)} €</td>
              <td className="py-2 text-center align-top text-gray-500">{item.iva}%</td>
              <td className="py-2 text-right align-top font-semibold">{lineTotal(item).toFixed(2)} €</td>
              <td className="py-2 align-top"><button onClick={() => removeItem(idx)} className="opacity-0 group-hover:opacity-100 text-gray-300 hover:text-red-500 transition-all"><Trash2 className="w-3 h-3" /></button></td>
            </tr>
          ))}
        </tbody>
      </table>
      <button onClick={addItem} className="w-full py-2 text-xs text-[#3F4694] hover:bg-[#3F4694]/5 transition-colors flex items-center justify-center gap-1 mt-1" data-testid="add-line">
        <Plus className="w-3 h-3" /> Añadir línea
      </button>
      <div className="flex justify-end mt-3">
        <div className="w-64 border-t-2 border-black pt-2 space-y-1 text-xs">
          <div className="flex justify-between"><span className="text-gray-500">Neto</span><span>{neto.toFixed(2)} €</span></div>
          <div className="flex justify-between"><span className="text-gray-500">Descuento</span><span>{descTotal.toFixed(2)} €</span></div>
          <div className="flex justify-between"><span className="text-gray-500">Base imp.</span><span>{baseImp.toFixed(2)} €</span></div>
          <div className="flex justify-between"><span className="text-gray-500">IVA</span><span>{ivaTotal.toFixed(2)} €</span></div>
          <div className="flex justify-between border-t border-gray-200 pt-1 text-sm font-bold"><span>Total</span><span>{total.toFixed(2)} €</span></div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// SORTABLE BLOCK
// ═══════════════════════════════════════════════════════
function SortableBlock({ block, rowId, colId, selection, onSelect, onUpdateBlock, onDeleteBlock, onDuplicateBlock }: {
  block: EditorBlock; rowId: string; colId: string;
  selection: Selection; onSelect: (s: Selection) => void;
  onUpdateBlock: (colId: string, blockId: string, data: Record<string, any>) => void;
  onDeleteBlock: (rowId: string, colId: string, blockId: string) => void;
  onDuplicateBlock: (rowId: string, colId: string, blockId: string) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: block.id,
    data: { type: "block", rowId, colId, blockId: block.id },
  });
  const isBlockSelected = selection?.type === "block" && (selection as any).blockId === block.id;
  const s = block.style;

  return (
    <div
      ref={setNodeRef}
      style={{
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.25 : (s.opacity != null ? s.opacity / 100 : 1),
        paddingTop: s.paddingTop || 0, paddingBottom: s.paddingBottom || 0,
        paddingLeft: s.paddingLeft || 0, paddingRight: s.paddingRight || 0,
        marginTop: s.marginTop || 0, marginBottom: s.marginBottom || 0,
        marginLeft: s.marginLeft || 0, marginRight: s.marginRight || 0,
        backgroundColor: s.gradient ? undefined : (s.backgroundColor || "transparent"),
        background: buildBackground(s),
        borderRadius: s.borderRadius || 0,
        borderWidth: s.borderWidth || 0, borderStyle: s.borderStyle || "none", borderColor: s.borderColor || "transparent",
        boxShadow: buildBoxShadow(s),
        minHeight: s.minHeight, width: s.width,
        position: "relative",
      }}
      className={`group/block transition-all ${
        isBlockSelected
          ? "ring-2 ring-[#F25075] ring-offset-1 rounded"
          : "hover:ring-1 hover:ring-[#F25075]/30 hover:ring-offset-1 rounded"
      }`}
      onClick={(e) => { e.stopPropagation(); onSelect({ type: "block", rowId, colId, blockId: block.id }); }}
      data-testid={`block-${block.id}`}
    >
      {/* Floating toolbar - appears on selection/hover */}
      <div className={`absolute -top-10 left-1/2 -translate-x-1/2 z-20 transition-all ${
        isBlockSelected ? "opacity-100 translate-y-0" : "opacity-0 translate-y-1 pointer-events-none group-hover/block:opacity-100 group-hover/block:translate-y-0 group-hover/block:pointer-events-auto"
      }`}>
        <div className="flex items-center gap-0.5 bg-white rounded-lg shadow-lg border border-gray-200 px-1 py-1">
          {/* Drag handle */}
          <button {...attributes} {...listeners} className="flex items-center gap-1 px-2 py-1.5 rounded-md text-gray-400 hover:text-[#3F4694] hover:bg-[#3F4694]/10 cursor-grab active:cursor-grabbing transition-colors" title="Mover" data-testid={`move-block-${block.id}`}>
            <GripVertical className="w-4 h-4" />
          </button>
          <div className="w-px h-5 bg-gray-200" />
          {/* Duplicate */}
          <button onClick={(e) => { e.stopPropagation(); onDuplicateBlock(rowId, colId, block.id); }} className="flex items-center gap-1 px-2 py-1.5 rounded-md text-gray-400 hover:text-[#3F4694] hover:bg-[#3F4694]/10 transition-colors" title="Duplicar" data-testid={`duplicate-block-${block.id}`}>
            <Copy className="w-4 h-4" />
          </button>
          <div className="w-px h-5 bg-gray-200" />
          {/* Delete */}
          <button onClick={(e) => { e.stopPropagation(); onDeleteBlock(rowId, colId, block.id); }} className="flex items-center gap-1 px-2 py-1.5 rounded-md text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Eliminar" data-testid={`delete-block-${block.id}`}>
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
        {/* Arrow pointing down */}
        <div className="absolute left-1/2 -translate-x-1/2 -bottom-1 w-2 h-2 bg-white border-b border-r border-gray-200 rotate-45" />
      </div>
      <RenderBlock block={block} onChange={(d) => onUpdateBlock(colId, block.id, d)} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// DROPPABLE COLUMN
// ═══════════════════════════════════════════════════════
function DroppableColumn({ col, rowId, selection, onSelect, onUpdateBlock, onDeleteBlock, onDuplicateBlock }: {
  col: EditorColumn; rowId: string;
  selection: Selection; onSelect: (s: Selection) => void;
  onUpdateBlock: (colId: string, blockId: string, data: Record<string, any>) => void;
  onDeleteBlock: (rowId: string, colId: string, blockId: string) => void;
  onDuplicateBlock: (rowId: string, colId: string, blockId: string) => void;
}) {
  const { setNodeRef: setDropRef, isOver } = useDroppable({
    id: `droppable-${col.id}`,
    data: { type: "column", rowId, colId: col.id },
  });
  const isColSelected = selection?.type === "column" && (selection as any).colId === col.id;
  const blockIds = col.blocks.map((b) => b.id);

  return (
    <div
      ref={setDropRef}
      className={`relative min-h-[40px] transition-all ${
        isOver ? "ring-2 ring-[#3F4694]/50 ring-inset bg-[#3F4694]/5" : isColSelected ? "ring-2 ring-green-400 ring-inset" : "hover:ring-1 hover:ring-gray-200 hover:ring-inset"
      }`}
      style={{
        width: col.width + "%",
        backgroundColor: isOver ? undefined : col.style.backgroundColor || "transparent",
        paddingTop: col.style.paddingTop || 0, paddingBottom: col.style.paddingBottom || 0,
        paddingLeft: col.style.paddingLeft || 0, paddingRight: col.style.paddingRight || 0,
        verticalAlign: col.style.verticalAlign || "top",
        borderRadius: col.style.borderRadius || 0,
        borderWidth: col.style.borderWidth || 0, borderColor: col.style.borderColor || "transparent", borderStyle: col.style.borderStyle || "none",
      }}
      onClick={(e) => { e.stopPropagation(); onSelect({ type: "column", rowId, colId: col.id }); }}
      data-testid={`col-${col.id}`}
    >
      <SortableContext items={blockIds} strategy={verticalListSortingStrategy}>
        {col.blocks.length === 0 ? (
          <div className={`flex items-center justify-center h-full min-h-[40px] text-[10px] border border-dashed rounded transition-colors ${
            isOver ? "border-[#3F4694] text-[#3F4694] bg-[#3F4694]/10" : "border-gray-200 text-gray-300"
          }`}>
            <Plus className="w-3 h-3 mr-1" /> {isOver ? "Soltar aquí" : "Bloque"}
          </div>
        ) : (
          col.blocks.map((block) => (
            <SortableBlock key={block.id} block={block} rowId={rowId} colId={col.id} selection={selection} onSelect={onSelect} onUpdateBlock={onUpdateBlock} onDeleteBlock={onDeleteBlock} onDuplicateBlock={onDuplicateBlock} />
          ))
        )}
        {col.blocks.length > 0 && isOver && (
          <div className="h-1 bg-[#3F4694] rounded-full mx-2 my-1 animate-pulse" />
        )}
      </SortableContext>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// SORTABLE ROW
// ═══════════════════════════════════════════════════════
function SortableRow({ row, selection, onSelect, onUpdateBlock, onDeleteRow, onDuplicateRow, onDeleteBlock, onDuplicateBlock }: {
  row: EditorRow; selection: Selection; onSelect: (s: Selection) => void;
  onUpdateBlock: (colId: string, blockId: string, data: Record<string, any>) => void;
  onDeleteRow: (rowId: string) => void;
  onDuplicateRow: (rowId: string) => void;
  onDeleteBlock: (rowId: string, colId: string, blockId: string) => void;
  onDuplicateBlock: (rowId: string, colId: string, blockId: string) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: row.id, data: { type: "row" },
  });
  const style = { transform: CSS.Transform.toString(transform), transition, opacity: isDragging ? 0.3 : row.visible === false ? 0.4 : 1 };
  const isRowSelected = selection?.type === "row" && selection.rowId === row.id;
  const rs = row.style;

  return (
    <div ref={setNodeRef} style={style} className={`group/row relative transition-all ${isRowSelected ? "ring-2 ring-blue-400 ring-offset-1" : ""}`} data-testid={`row-${row.id}`}>
      {/* Row floating toolbar - left side */}
      <div className={`absolute -left-2 top-1/2 -translate-y-1/2 -translate-x-full z-10 transition-all ${
        isRowSelected ? "opacity-100 translate-x-[-100%]" : "opacity-0 group-hover/row:opacity-100"
      }`} style={{ transform: 'translateY(-50%) translateX(calc(-100% - 8px))' }}>
        <div className="flex flex-col items-center gap-0.5 bg-white rounded-lg shadow-lg border border-gray-200 px-1 py-1">
          <button {...attributes} {...listeners} className="p-2 rounded-md text-gray-400 hover:text-blue-500 hover:bg-blue-50 cursor-grab active:cursor-grabbing transition-colors" title="Mover fila">
            <GripVertical className="w-4 h-4" />
          </button>
          <div className="h-px w-5 bg-gray-200" />
          <button onClick={(e) => { e.stopPropagation(); onDuplicateRow(row.id); }} className="p-2 rounded-md text-gray-400 hover:text-[#3F4694] hover:bg-[#3F4694]/10 transition-colors" title="Duplicar fila" data-testid={`duplicate-row-${row.id}`}>
            <Copy className="w-4 h-4" />
          </button>
          <div className="h-px w-5 bg-gray-200" />
          <button onClick={(e) => { e.stopPropagation(); onDeleteRow(row.id); }} className="p-2 rounded-md text-gray-400 hover:text-red-500 hover:bg-red-50 transition-colors" title="Eliminar fila" data-testid={`delete-row-${row.id}`}>
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
      <div
        onClick={(e) => { e.stopPropagation(); onSelect({ type: "row", rowId: row.id }); }}
        className="relative"
        style={{
          backgroundColor: rs.gradient ? undefined : (rs.backgroundColor || "transparent"),
          background: buildBackground(rs),
          paddingTop: rs.paddingTop || 0, paddingBottom: rs.paddingBottom || 0,
          paddingLeft: rs.paddingLeft || 0, paddingRight: rs.paddingRight || 0,
          borderRadius: rs.borderRadius || 0,
          borderWidth: rs.borderWidth || 0, borderColor: rs.borderColor || "transparent", borderStyle: rs.borderStyle || "none",
          minHeight: rs.minHeight,
        }}
      >
        <div className="flex" style={{ alignItems: rs.verticalAlign === "center" ? "center" : rs.verticalAlign === "bottom" ? "flex-end" : "flex-start" }}>
          {row.columns.map((col) => (
            <DroppableColumn key={col.id} col={col} rowId={row.id} selection={selection} onSelect={onSelect} onUpdateBlock={onUpdateBlock} onDeleteBlock={onDeleteBlock} onDuplicateBlock={onDuplicateBlock} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// DRAGGABLE CATALOG ITEM
// ═══════════════════════════════════════════════════════
function DraggableCatalogItem({ type, label, icon: Icon }: { type: string; label: string; icon: any }) {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `catalog-${type}`,
    data: { type: "catalog", blockType: type },
  });

  return (
    <div
      ref={setNodeRef} {...attributes} {...listeners}
      className={`flex flex-col items-center justify-center gap-1.5 p-3 border border-gray-200 rounded-xl hover:border-[#3F4694]/40 hover:bg-[#3F4694]/5 transition-all cursor-grab active:cursor-grabbing select-none ${
        isDragging ? "opacity-30 ring-2 ring-[#3F4694]" : ""
      }`}
      data-testid={`drag-block-${type}`}
    >
      <Icon className="w-6 h-6 text-gray-500" />
      <span className="text-[10px] text-gray-600 font-medium">{label}</span>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// ACCORDION CARD
// ═══════════════════════════════════════════════════════
function AccordionCard({ title, isOpen, onToggle, children }: { title: string; isOpen: boolean; onToggle: () => void; children: React.ReactNode }) {
  return (
    <div className="border border-gray-200 rounded-xl overflow-hidden">
      <button onClick={onToggle} className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold text-[#3F4694] hover:bg-gray-50 transition-colors" data-testid={`accordion-${title.toLowerCase().replace(/ /g, "-")}`}>
        {title}
        {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
      </button>
      {isOpen && <div className="px-4 pb-4 border-t border-gray-100">{children}</div>}
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// PADDING/MARGIN EDITOR
// ═══════════════════════════════════════════════════════
function SpacingEditor({ label, values, onChange }: { label: string; values: { top: number; right: number; bottom: number; left: number }; onChange: (p: { top: number; right: number; bottom: number; left: number }) => void }) {
  return (
    <div>
      <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1.5 block">{label}</label>
      <div className="grid grid-cols-4 gap-1">
        {(["top", "right", "bottom", "left"] as const).map((side) => (
          <div key={side} className="text-center">
            <input type="number" min={0} max={200} value={values[side]} onChange={(e) => onChange({ ...values, [side]: Number(e.target.value) || 0 })}
              className="w-full text-center text-[10px] border border-gray-200 rounded px-1 py-1 focus:border-[#3F4694] outline-none" />
            <span className="text-[8px] text-gray-400 capitalize">{side === "top" ? "Arr" : side === "bottom" ? "Abj" : side === "left" ? "Izq" : "Der"}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// COLOR SWATCH PICKER
// ═══════════════════════════════════════════════════════
function ColorSwatchPicker({ value, onChange, presets }: { value: string; onChange: (c: string) => void; presets?: string[] }) {
  const colors = presets || ["transparent", "#ffffff", "#f9fafb", "#f3f4f6", "#3F4694", "#1a1a1a", "#F25075", "#000000"];
  return (
    <div className="flex gap-1.5 flex-wrap items-center">
      {colors.map((c) => (
        <button key={c} onClick={() => onChange(c)}
          className={`w-6 h-6 rounded-full border-2 transition-all ${value === c || (!value && c === "transparent") ? "border-gray-800 scale-110" : "border-gray-200"}`}
          style={{ backgroundColor: c === "transparent" ? "#fff" : c, backgroundImage: c === "transparent" ? "linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%), linear-gradient(45deg, #ccc 25%, transparent 25%, transparent 75%, #ccc 75%)" : "none", backgroundSize: "6px 6px", backgroundPosition: "0 0, 3px 3px" }} />
      ))}
      <input type="color" value={value || "#ffffff"} onChange={(e) => onChange(e.target.value)} className="w-6 h-6 rounded-full border border-gray-200 cursor-pointer" />
    </div>
  );
}

// ═══════════════════════════════════════════════════════
// WIDGET CATALOG
// ═══════════════════════════════════════════════════════
const ROW_PRESETS = [
  { cols: 1, label: "1 columna", icon: Square },
  { cols: 2, label: "2 columnas", icon: Columns2 },
  { cols: 3, label: "3 columnas", icon: Columns3 },
];

const BLOCK_CATALOG = [
  { type: "heading", label: "Encabezado", icon: Type, color: "#3F4694" },
  { type: "image", label: "Imagen", icon: Image, color: "#3F4694" },
  { type: "button", label: "Botón", icon: Square, color: "#3F4694" },
  { type: "text", label: "Texto", icon: AlignLeft, color: "#3F4694" },
  { type: "spacer", label: "Espacio", icon: MoveVertical, color: "#999" },
  { type: "separator", label: "Separador", icon: Minus, color: "#999" },
  { type: "social", label: "Iconos RRSS", icon: Globe, color: "#3F4694" },
  { type: "logo", label: "Logo", icon: Stamp, color: "#F25075" },
  { type: "presupuesto", label: "Presupuesto", icon: Calculator, color: "#F25075" },
  { type: "list", label: "Lista", icon: List, color: "#3F4694" },
  { type: "quote", label: "Testimonio", icon: Quote, color: "#3F4694" },
  { type: "counter", label: "Contador", icon: Hash, color: "#3F4694" },
  { type: "table", label: "Tabla", icon: Table2, color: "#3F4694" },
  { type: "video", label: "Vídeo", icon: Play, color: "#999" },
  { type: "qrcode", label: "Código QR", icon: QrCode, color: "#999" },
  { type: "map", label: "Mapa", icon: MapPin, color: "#999" },
];

// ═══════════════════════════════════════════════════════
// STYLE PANEL (expanded)
// ═══════════════════════════════════════════════════════
function StylePanel({ selection, pages, currentPageIdx, onUpdateRowStyle, onUpdateColumnStyle, onUpdateBlockStyle, onUpdateBlockData,
  onSetColumns, onDeleteRow, onDuplicateRow, onDeleteBlock, onDuplicateBlock, onAddBlockToColumn, onToggleRowVisible,
}: {
  selection: Selection; pages: EditorPage[]; currentPageIdx: number;
  onUpdateRowStyle: (rowId: string, style: any) => void;
  onUpdateColumnStyle: (rowId: string, colId: string, style: any) => void;
  onUpdateBlockStyle: (rowId: string, colId: string, blockId: string, style: BlockStyle) => void;
  onUpdateBlockData: (rowId: string, colId: string, blockId: string, data: Record<string, any>) => void;
  onSetColumns: (rowId: string, count: number) => void;
  onDeleteRow: (rowId: string) => void;
  onDuplicateRow: (rowId: string) => void;
  onDeleteBlock: (rowId: string, colId: string, blockId: string) => void;
  onDuplicateBlock: (rowId: string, colId: string, blockId: string) => void;
  onAddBlockToColumn: (rowId: string, colId: string, blockType: string) => void;
  onToggleRowVisible: (rowId: string) => void;
}) {
  const page = pages[currentPageIdx];
  if (!selection) return (
    <div className="flex flex-col items-center justify-center h-32 text-gray-300 px-4">
      <MousePointer2 className="w-6 h-6 mb-2 opacity-40" />
      <p className="text-[10px] text-gray-400 font-medium text-center">Selecciona un elemento para editar</p>
    </div>
  );

  const row = page.rows.find((r) => r.id === selection.rowId);
  if (!row) return null;
  const col = selection.type !== "row" ? row.columns.find((c) => c.id === (selection as any).colId) : null;
  const block = selection.type === "block" ? col?.blocks.find((b) => b.id === (selection as any).blockId) : null;

  // ── ROW PANEL ──
  if (selection.type === "row") {
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
          <div className="w-6 h-6 rounded bg-blue-100 flex items-center justify-center"><LayoutList className="w-3.5 h-3.5 text-blue-600" /></div>
          <p className="text-xs font-bold text-gray-700">Fila</p>
        </div>
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Columnas</label>
          <div className="flex gap-1">
            {[1, 2, 3].map((n) => (
              <button key={n} onClick={() => onSetColumns(row.id, n)}
                className={`flex-1 py-1.5 rounded border text-xs font-semibold flex items-center justify-center gap-1 transition-all ${
                  row.columns.length === n ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>
                {n}
              </button>
            ))}
          </div>
        </div>
        <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Color de fondo</label>
          <ColorSwatchPicker value={row.style.backgroundColor || "transparent"} onChange={(c) => onUpdateRowStyle(row.id, { ...row.style, backgroundColor: c })} /></div>
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Gradiente</label>
          <label className="flex items-center gap-2 text-[10px] text-gray-600"><input type="checkbox" checked={!!row.style.gradient} onChange={(e) => onUpdateRowStyle(row.id, { ...row.style, gradient: e.target.checked, gradientColor1: row.style.gradientColor1 || "#3F4694", gradientColor2: row.style.gradientColor2 || "#F25075" })} className="accent-[#3F4694]" /> Activar gradiente</label>
          {row.style.gradient && (
            <div className="flex gap-2 mt-1">
              <input type="color" value={row.style.gradientColor1 || "#3F4694"} onChange={(e) => onUpdateRowStyle(row.id, { ...row.style, gradientColor1: e.target.value })} className="w-8 h-6 rounded border" />
              <input type="range" min={0} max={360} value={row.style.gradientDirection || 180} onChange={(e) => onUpdateRowStyle(row.id, { ...row.style, gradientDirection: Number(e.target.value) })} className="flex-1 accent-[#3F4694]" />
              <input type="color" value={row.style.gradientColor2 || "#F25075"} onChange={(e) => onUpdateRowStyle(row.id, { ...row.style, gradientColor2: e.target.value })} className="w-8 h-6 rounded border" />
            </div>
          )}
        </div>
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Borde</label>
          <div className="flex gap-2 items-center">
            <input type="number" min={0} max={10} value={row.style.borderWidth || 0} onChange={(e) => onUpdateRowStyle(row.id, { ...row.style, borderWidth: Number(e.target.value), borderStyle: "solid" })} className="w-12 text-center text-[10px] border rounded px-1 py-0.5" />
            <input type="color" value={row.style.borderColor || "#e5e7eb"} onChange={(e) => onUpdateRowStyle(row.id, { ...row.style, borderColor: e.target.value })} className="w-6 h-6 rounded border cursor-pointer" />
            <input type="number" min={0} max={50} value={row.style.borderRadius || 0} onChange={(e) => onUpdateRowStyle(row.id, { ...row.style, borderRadius: Number(e.target.value) })} className="w-12 text-center text-[10px] border rounded px-1 py-0.5" placeholder="Radio" />
          </div>
        </div>
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Alineación vertical</label>
          <div className="flex gap-1">
            {[{ v: "top", l: "Arriba" }, { v: "center", l: "Centro" }, { v: "bottom", l: "Abajo" }].map(({ v, l }) => (
              <button key={v} onClick={() => onUpdateRowStyle(row.id, { ...row.style, verticalAlign: v })} className={`flex-1 py-1 text-[10px] rounded border ${(row.style.verticalAlign || "top") === v ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>{l}</button>
            ))}
          </div>
        </div>
        <SpacingEditor label="Relleno" values={{ top: row.style.paddingTop || 0, bottom: row.style.paddingBottom || 0, left: row.style.paddingLeft || 0, right: row.style.paddingRight || 0 }}
          onChange={(p) => onUpdateRowStyle(row.id, { ...row.style, paddingTop: p.top, paddingBottom: p.bottom, paddingLeft: p.left, paddingRight: p.right })} />
        <div className="pt-2 border-t border-gray-100 space-y-1">
          <button onClick={() => onToggleRowVisible(row.id)} className="flex items-center gap-2 w-full p-1.5 text-[10px] text-gray-600 hover:bg-gray-50 rounded"><EyeOff className="w-3 h-3" /> {row.visible === false ? "Mostrar" : "Ocultar"}</button>
          <button onClick={() => onDuplicateRow(row.id)} className="flex items-center gap-2 w-full p-1.5 text-[10px] text-gray-600 hover:bg-gray-50 rounded"><Copy className="w-3 h-3" /> Duplicar</button>
          <button onClick={() => onDeleteRow(row.id)} className="flex items-center gap-2 w-full p-1.5 text-[10px] text-red-500 hover:bg-red-50 rounded"><Trash2 className="w-3 h-3" /> Eliminar</button>
        </div>
      </div>
    );
  }

  // ── COLUMN PANEL ──
  if (selection.type === "column" && col) {
    return (
      <div className="p-3 space-y-3">
        <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
          <div className="w-6 h-6 rounded bg-green-100 flex items-center justify-center"><Columns2 className="w-3.5 h-3.5 text-green-600" /></div>
          <p className="text-xs font-bold text-gray-700">Columna ({Math.round(col.width)}%)</p>
        </div>
        <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Color de fondo</label>
          <ColorSwatchPicker value={col.style.backgroundColor || "transparent"} onChange={(c) => onUpdateColumnStyle(row.id, col.id, { ...col.style, backgroundColor: c })} /></div>
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Alineación vertical</label>
          <div className="flex gap-1">
            {[{ v: "top", l: "Arriba" }, { v: "center", l: "Centro" }, { v: "bottom", l: "Abajo" }].map(({ v, l }) => (
              <button key={v} onClick={() => onUpdateColumnStyle(row.id, col.id, { ...col.style, verticalAlign: v })} className={`flex-1 py-1 text-[10px] rounded border ${(col.style.verticalAlign || "top") === v ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>{l}</button>
            ))}
          </div>
        </div>
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Borde</label>
          <div className="flex gap-2 items-center">
            <input type="number" min={0} max={10} value={col.style.borderWidth || 0} onChange={(e) => onUpdateColumnStyle(row.id, col.id, { ...col.style, borderWidth: Number(e.target.value), borderStyle: "solid" })} className="w-12 text-center text-[10px] border rounded px-1 py-0.5" />
            <input type="color" value={col.style.borderColor || "#e5e7eb"} onChange={(e) => onUpdateColumnStyle(row.id, col.id, { ...col.style, borderColor: e.target.value })} className="w-6 h-6 rounded border cursor-pointer" />
            <input type="number" min={0} max={50} value={col.style.borderRadius || 0} onChange={(e) => onUpdateColumnStyle(row.id, col.id, { ...col.style, borderRadius: Number(e.target.value) })} className="w-12 text-center text-[10px] border rounded px-1 py-0.5" />
          </div>
        </div>
        <SpacingEditor label="Relleno" values={{ top: col.style.paddingTop || 0, bottom: col.style.paddingBottom || 0, left: col.style.paddingLeft || 0, right: col.style.paddingRight || 0 }}
          onChange={(p) => onUpdateColumnStyle(row.id, col.id, { ...col.style, paddingTop: p.top, paddingBottom: p.bottom, paddingLeft: p.left, paddingRight: p.right })} />
        <div>
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Añadir bloque</label>
          <div className="grid grid-cols-3 gap-1">
            {[{ type: "heading", label: "Título", icon: Type }, { type: "text", label: "Texto", icon: AlignLeft }, { type: "image", label: "Imagen", icon: Image }, { type: "button", label: "Botón", icon: Square }, { type: "spacer", label: "Espacio", icon: MoveVertical }, { type: "separator", label: "Línea", icon: Minus }].map((b) => (
              <button key={b.type} onClick={() => onAddBlockToColumn(row.id, col.id, b.type)} className="p-1.5 border border-gray-100 rounded text-center hover:border-[#3F4694]/30 hover:bg-[#3F4694]/5 transition-all">
                <b.icon className="w-3.5 h-3.5 mx-auto text-gray-500" />
                <span className="text-[8px] text-gray-500 block">{b.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>
    );
  }

  // ── BLOCK PANEL ──
  if (selection.type === "block" && block && col) {
    const bs = block.style;
    const setStyle = (patch: Partial<BlockStyle>) => onUpdateBlockStyle(row.id, col.id, block.id, { ...bs, ...patch });
    const isTextBlock = ["heading", "text", "button", "quote", "counter", "list"].includes(block.type);

    return (
      <div className="p-3 space-y-3 text-xs">
        <div className="flex items-center gap-2 pb-2 border-b border-gray-100">
          <div className="w-6 h-6 rounded bg-[#F25075]/10 flex items-center justify-center"><Settings2 className="w-3.5 h-3.5 text-[#F25075]" /></div>
          <p className="text-xs font-bold text-gray-700 capitalize">{block.type === "presupuesto" ? "Widget Presupuesto" : block.type}</p>
        </div>

        {/* Typography */}
        {isTextBlock && (<>
          <div>
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Tipografía</label>
            <select value={bs.fontFamily || "Catamaran"} onChange={(e) => setStyle({ fontFamily: e.target.value })} className="w-full border border-gray-200 rounded px-2 py-1 text-[10px] focus:border-[#3F4694] outline-none bg-white">
              {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div className="flex gap-1.5">
            <div className="flex-1"><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Tamaño</label>
              <select value={bs.fontSize || 14} onChange={(e) => setStyle({ fontSize: Number(e.target.value) })} className="w-full border border-gray-200 rounded px-1.5 py-1 text-[10px] focus:border-[#3F4694] outline-none bg-white">
                {FONT_SIZES.map((s) => <option key={s} value={s}>{s}px</option>)}
              </select>
            </div>
            <div className="flex-1"><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Peso</label>
              <select value={bs.fontWeight || "400"} onChange={(e) => setStyle({ fontWeight: e.target.value })} className="w-full border border-gray-200 rounded px-1.5 py-1 text-[10px] focus:border-[#3F4694] outline-none bg-white">
                <option value="300">Light</option><option value="400">Normal</option><option value="500">Medium</option>
                <option value="600">Semibold</option><option value="700">Bold</option><option value="900">Black</option>
              </select>
            </div>
          </div>
          <div className="flex gap-0.5">
            {[{ k: "fontStyle", v: "italic", icon: Italic, label: "I" }, { k: "textDecoration", v: "underline", icon: Underline, label: "U" }].map(({ k, v, icon: Ic }) => (
              <button key={k} onClick={() => setStyle({ [k]: (bs as any)[k] === v ? "normal" : v } as any)}
                className={`flex-1 py-1 rounded border text-[10px] flex items-center justify-center ${(bs as any)[k] === v ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>
                <Ic className="w-3 h-3" />
              </button>
            ))}
          </div>
          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Transformar texto</label>
            <div className="flex gap-0.5">
              {[{ v: "none", l: "Aa" }, { v: "uppercase", l: "AA" }, { v: "lowercase", l: "aa" }, { v: "capitalize", l: "Ab" }].map(({ v, l }) => (
                <button key={v} onClick={() => setStyle({ textTransform: v })} className={`flex-1 py-1 rounded border text-[10px] font-semibold ${(bs.textTransform || "none") === v ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>{l}</button>
              ))}
            </div>
          </div>
          <div className="flex gap-1.5">
            <div className="flex-1"><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Interletrado</label>
              <input type="range" min={-2} max={10} step={0.5} value={bs.letterSpacing || 0} onChange={(e) => setStyle({ letterSpacing: Number(e.target.value) })} className="w-full accent-[#3F4694]" />
              <span className="text-[8px] text-gray-400">{bs.letterSpacing || 0}px</span>
            </div>
            <div className="flex-1"><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Alt. línea</label>
              <input type="range" min={0.8} max={3} step={0.1} value={bs.lineHeight || 1.5} onChange={(e) => setStyle({ lineHeight: Number(e.target.value) })} className="w-full accent-[#3F4694]" />
              <span className="text-[8px] text-gray-400">{bs.lineHeight || 1.5}</span>
            </div>
          </div>
          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Color de texto</label>
            <ColorSwatchPicker value={bs.color || "#333333"} onChange={(c) => setStyle({ color: c })} presets={["#000000", "#333333", "#555555", "#999999", "#ffffff", "#3F4694", "#F25075"]} /></div>
          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Alineación</label>
            <div className="flex gap-0.5">
              {[{ v: "left", icon: AlignLeft }, { v: "center", icon: AlignCenter }, { v: "right", icon: AlignRight }].map(({ v, icon: Icon }) => (
                <button key={v} onClick={() => setStyle({ textAlign: v })} className={`flex-1 py-1 rounded border flex items-center justify-center ${bs.textAlign === v ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>
                  <Icon className="w-3 h-3" />
                </button>
              ))}
            </div>
          </div>
        </>)}

        {/* Spacer */}
        {block.type === "spacer" && (
          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Altura</label>
            <input type="range" min={8} max={200} value={block.data.height || 32} onChange={(e) => onUpdateBlockData(row.id, col.id, block.id, { ...block.data, height: Number(e.target.value) })} className="w-full accent-[#3F4694]" />
            <span className="text-[10px] text-gray-400">{block.data.height || 32}px</span></div>
        )}

        {/* Separator */}
        {block.type === "separator" && (
          <div className="space-y-2">
            <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Color</label>
              <input type="color" value={block.data.lineColor || "#e5e7eb"} onChange={(e) => onUpdateBlockData(row.id, col.id, block.id, { ...block.data, lineColor: e.target.value })} className="w-8 h-6 rounded border cursor-pointer" /></div>
            <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Grosor</label>
              <input type="range" min={1} max={8} value={block.data.lineWidth || 1} onChange={(e) => onUpdateBlockData(row.id, col.id, block.id, { ...block.data, lineWidth: Number(e.target.value) })} className="w-full accent-[#3F4694]" /></div>
            <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Estilo</label>
              <div className="flex gap-1">{["solid", "dashed", "dotted", "double"].map((st) => (
                <button key={st} onClick={() => onUpdateBlockData(row.id, col.id, block.id, { ...block.data, lineStyle: st })} className={`flex-1 py-1 text-[9px] rounded border ${(block.data.lineStyle || "solid") === st ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>{st}</button>
              ))}</div></div>
          </div>
        )}

        {/* Button variant */}
        {block.type === "button" && (
          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Estilo del botón</label>
            <div className="flex gap-0.5">
              {[{ k: "primary", l: "Primario" }, { k: "secondary", l: "Secundario" }, { k: "outline", l: "Contorno" }].map((s) => (
                <button key={s.k} onClick={() => onUpdateBlockData(row.id, col.id, block.id, { ...block.data, variant: s.k })}
                  className={`flex-1 py-1 text-[9px] rounded border ${block.data.variant === s.k ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694] font-semibold" : "border-gray-200 text-gray-500"}`}>{s.l}</button>
              ))}
            </div></div>
        )}

        {/* Logo */}
        {block.type === "logo" && (
          <div className="space-y-2">
            <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Ancho máximo</label>
              <input type="range" min={40} max={400} value={block.data.maxWidth || 180} onChange={(e) => onUpdateBlockData(row.id, col.id, block.id, { ...block.data, maxWidth: Number(e.target.value) })} className="w-full accent-[#3F4694]" />
              <span className="text-[10px] text-gray-400">{block.data.maxWidth || 180}px</span></div>
            <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Alineación</label>
              <div className="flex gap-0.5">{["left", "center", "right"].map((a) => (
                <button key={a} onClick={() => onUpdateBlockData(row.id, col.id, block.id, { ...block.data, alignment: a })} className={`flex-1 py-1 text-[9px] rounded border ${(block.data.alignment || "left") === a ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>{a === "left" ? "Izq" : a === "center" ? "Centro" : "Der"}</button>
              ))}</div></div>
          </div>
        )}

        {block.type === "presupuesto" && (
          <div className="bg-[#F25075]/5 border border-[#F25075]/20 rounded-lg p-2">
            <p className="text-[10px] font-semibold text-[#F25075]">Widget Presupuesto</p>
            <p className="text-[9px] text-gray-500">Edita la tabla directamente en el canvas.</p>
          </div>
        )}

        {/* ── COMMON BLOCK STYLES ── */}
        <div className="border-t border-gray-100 pt-2 space-y-3">
          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Fondo</label>
            <ColorSwatchPicker value={bs.backgroundColor || "transparent"} onChange={(c) => setStyle({ backgroundColor: c })} /></div>

          <div>
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Gradiente</label>
            <label className="flex items-center gap-2 text-[10px] text-gray-600"><input type="checkbox" checked={!!bs.gradient} onChange={(e) => setStyle({ gradient: e.target.checked, gradientColor1: bs.gradientColor1 || "#3F4694", gradientColor2: bs.gradientColor2 || "#F25075" })} className="accent-[#3F4694]" /> Activar</label>
            {bs.gradient && (
              <div className="flex gap-2 mt-1">
                <input type="color" value={bs.gradientColor1 || "#3F4694"} onChange={(e) => setStyle({ gradientColor1: e.target.value })} className="w-7 h-5 rounded border" />
                <input type="range" min={0} max={360} value={bs.gradientDirection || 180} onChange={(e) => setStyle({ gradientDirection: Number(e.target.value) })} className="flex-1 accent-[#3F4694]" />
                <input type="color" value={bs.gradientColor2 || "#F25075"} onChange={(e) => setStyle({ gradientColor2: e.target.value })} className="w-7 h-5 rounded border" />
              </div>
            )}
          </div>

          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Borde</label>
            <div className="flex gap-1.5 items-center">
              <input type="number" min={0} max={10} value={bs.borderWidth || 0} onChange={(e) => setStyle({ borderWidth: Number(e.target.value), borderStyle: bs.borderStyle || "solid" })} className="w-10 text-center text-[10px] border rounded px-1 py-0.5" />
              <select value={bs.borderStyle || "solid"} onChange={(e) => setStyle({ borderStyle: e.target.value })} className="text-[10px] border rounded px-1 py-0.5 bg-white">
                <option value="solid">Sólido</option><option value="dashed">Guiones</option><option value="dotted">Puntos</option><option value="double">Doble</option><option value="none">Ninguno</option>
              </select>
              <input type="color" value={bs.borderColor || "#e5e7eb"} onChange={(e) => setStyle({ borderColor: e.target.value })} className="w-6 h-5 rounded border cursor-pointer" />
            </div></div>

          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Radio de borde</label>
            <input type="range" min={0} max={50} value={bs.borderRadius || 0} onChange={(e) => setStyle({ borderRadius: Number(e.target.value) })} className="w-full accent-[#3F4694]" />
            <span className="text-[8px] text-gray-400">{bs.borderRadius || 0}px</span></div>

          <div>
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Sombra</label>
            <label className="flex items-center gap-2 text-[10px] text-gray-600"><input type="checkbox" checked={!!bs.boxShadowEnabled} onChange={(e) => setStyle({ boxShadowEnabled: e.target.checked, boxShadowX: 0, boxShadowY: 2, boxShadowBlur: 8, boxShadowSpread: 0, boxShadowColor: "rgba(0,0,0,0.15)" })} className="accent-[#3F4694]" /> Activar</label>
            {bs.boxShadowEnabled && (
              <div className="mt-1 space-y-1">
                {[{ k: "boxShadowX" as const, l: "X", min: -20, max: 20 }, { k: "boxShadowY" as const, l: "Y", min: -20, max: 20 }, { k: "boxShadowBlur" as const, l: "Desenfoque", min: 0, max: 40 }, { k: "boxShadowSpread" as const, l: "Extensión", min: -10, max: 20 }].map(({ k, l, min, max }) => (
                  <div key={k} className="flex items-center gap-1"><span className="text-[8px] text-gray-400 w-14">{l}</span>
                    <input type="range" min={min} max={max} value={bs[k] || 0} onChange={(e) => setStyle({ [k]: Number(e.target.value) })} className="flex-1 accent-[#3F4694]" />
                    <span className="text-[8px] text-gray-400 w-6 text-right">{bs[k] || 0}</span></div>
                ))}
                <div className="flex items-center gap-1"><span className="text-[8px] text-gray-400 w-14">Color</span>
                  <input type="color" value={bs.boxShadowColor || "#000000"} onChange={(e) => setStyle({ boxShadowColor: e.target.value })} className="w-6 h-5 rounded border cursor-pointer" /></div>
              </div>
            )}
          </div>

          <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Opacidad</label>
            <input type="range" min={0} max={100} value={bs.opacity ?? 100} onChange={(e) => setStyle({ opacity: Number(e.target.value) })} className="w-full accent-[#3F4694]" />
            <span className="text-[8px] text-gray-400">{bs.opacity ?? 100}%</span></div>

          <SpacingEditor label="Relleno (padding)" values={{ top: bs.paddingTop || 0, bottom: bs.paddingBottom || 0, left: bs.paddingLeft || 0, right: bs.paddingRight || 0 }}
            onChange={(p) => setStyle({ paddingTop: p.top, paddingBottom: p.bottom, paddingLeft: p.left, paddingRight: p.right })} />
          <SpacingEditor label="Margen (margin)" values={{ top: bs.marginTop || 0, bottom: bs.marginBottom || 0, left: bs.marginLeft || 0, right: bs.marginRight || 0 }}
            onChange={(p) => setStyle({ marginTop: p.top, marginBottom: p.bottom, marginLeft: p.left, marginRight: p.right })} />
        </div>

        <div className="pt-2 border-t border-gray-100 space-y-1">
          <button onClick={() => onDuplicateBlock(row.id, col.id, block.id)} className="flex items-center gap-2 w-full p-1.5 text-[10px] text-gray-600 hover:bg-gray-50 rounded"><Copy className="w-3 h-3" /> Duplicar</button>
          <button onClick={() => onDeleteBlock(row.id, col.id, block.id)} className="flex items-center gap-2 w-full p-1.5 text-[10px] text-red-500 hover:bg-red-50 rounded"><Trash2 className="w-3 h-3" /> Eliminar</button>
        </div>
      </div>
    );
  }

  return null;
}

// ═══════════════════════════════════════════════════════
// MAIN EDITOR
// ═══════════════════════════════════════════════════════
export default function PresupuestoMaxEditor() {
  const [pages, setPages] = useState<EditorPage[]>(defaultPages);
  const [currentPageIdx, setCurrentPageIdx] = useState(0);
  const [selection, setSelection] = useState<Selection>(null);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [zoom, setZoom] = useState(90);
  const [docSettings, setDocSettings] = useState<DocumentSettings>(defaultDocSettings);
  const [activeDragData, setActiveDragData] = useState<{ type: string; blockType?: string; id: string } | null>(null);

  // Accordion states
  const [openPersonalizar, setOpenPersonalizar] = useState(false);
  const [openMetodos, setOpenMetodos] = useState(false);
  const [openRecurrencia, setOpenRecurrencia] = useState(false);
  const [openTipo, setOpenTipo] = useState(false);

  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 5 } }));
  const page = pages[currentPageIdx];

  useEffect(() => { if (selection) { /* auto-scroll to style */ } }, [selection]);

  // ── Immutable updaters ──
  const updatePage = useCallback((updater: (p: EditorPage) => EditorPage) => {
    setPages((prev) => prev.map((p, i) => i === currentPageIdx ? updater(p) : p));
  }, [currentPageIdx]);

  const addRow = (colCount: number, firstBlockType?: string) => {
    updatePage((p) => ({ ...p, rows: [...p.rows, makeRow(colCount, firstBlockType)] }));
  };

  const deleteRow = (rowId: string) => {
    updatePage((p) => ({ ...p, rows: p.rows.filter((r) => r.id !== rowId) }));
    if (selection?.rowId === rowId) setSelection(null);
  };

  const duplicateRow = (rowId: string) => {
    updatePage((p) => {
      const idx = p.rows.findIndex((r) => r.id === rowId);
      if (idx === -1) return p;
      const dup: EditorRow = JSON.parse(JSON.stringify(p.rows[idx]));
      dup.id = uid("row");
      dup.columns.forEach((c) => { c.id = uid("col"); c.blocks.forEach((b) => { b.id = uid("blk"); }); });
      const newRows = [...p.rows]; newRows.splice(idx + 1, 0, dup);
      return { ...p, rows: newRows };
    });
  };

  const toggleRowVisible = (rowId: string) => {
    updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id === rowId ? { ...r, visible: r.visible === false ? true : false } : r) }));
  };

  const setColumns = (rowId: string, count: number) => {
    updatePage((p) => ({
      ...p,
      rows: p.rows.map((r) => {
        if (r.id !== rowId) return r;
        const widths = count === 1 ? [100] : count === 2 ? [50, 50] : [33.33, 33.33, 33.34];
        const newCols: EditorColumn[] = widths.map((w, i) => {
          if (i < r.columns.length) return { ...r.columns[i], width: w };
          return { id: uid("col"), width: w, blocks: [], style: defaultColumnStyle() };
        });
        if (count < r.columns.length) {
          const extraBlocks = r.columns.slice(count).flatMap((c) => c.blocks);
          newCols[count - 1] = { ...newCols[count - 1], blocks: [...newCols[count - 1].blocks, ...extraBlocks] };
        }
        return { ...r, columns: newCols.slice(0, count) };
      }),
    }));
  };

  const updateRowStyle = (rowId: string, style: any) => { updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id === rowId ? { ...r, style } : r) })); };
  const updateColumnStyle = (rowId: string, colId: string, style: any) => { updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id !== rowId ? r : { ...r, columns: r.columns.map((c) => c.id === colId ? { ...c, style } : c) }) })); };
  const updateBlockStyle = (rowId: string, colId: string, blockId: string, style: BlockStyle) => { updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id !== rowId ? r : { ...r, columns: r.columns.map((c) => c.id !== colId ? c : { ...c, blocks: c.blocks.map((b) => b.id === blockId ? { ...b, style } : b) }) }) })); };
  const updateBlockData = (rowId: string, colId: string, blockId: string, data: Record<string, any>) => { updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id !== rowId ? r : { ...r, columns: r.columns.map((c) => c.id !== colId ? c : { ...c, blocks: c.blocks.map((b) => b.id === blockId ? { ...b, data } : b) }) }) })); };
  const addBlockToColumn = (rowId: string, colId: string, blockType: string) => { updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id !== rowId ? r : { ...r, columns: r.columns.map((c) => c.id !== colId ? c : { ...c, blocks: [...c.blocks, makeBlock(blockType)] }) }) })); };
  const deleteBlock = (rowId: string, colId: string, blockId: string) => { updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id !== rowId ? r : { ...r, columns: r.columns.map((c) => c.id !== colId ? c : { ...c, blocks: c.blocks.filter((b) => b.id !== blockId) }) }) })); if (selection?.type === "block" && (selection as any).blockId === blockId) setSelection(null); };
  const duplicateBlock = (rowId: string, colId: string, blockId: string) => { updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id !== rowId ? r : { ...r, columns: r.columns.map((c) => { if (c.id !== colId) return c; const idx = c.blocks.findIndex((b) => b.id === blockId); if (idx === -1) return c; const dup: EditorBlock = JSON.parse(JSON.stringify(c.blocks[idx])); dup.id = uid("blk"); const newBlocks = [...c.blocks]; newBlocks.splice(idx + 1, 0, dup); return { ...c, blocks: newBlocks }; }) }) })); };

  const updateBlockDataFromCanvas = (colId: string, blockId: string, data: Record<string, any>) => {
    const rowId = page.rows.find((r) => r.columns.some((c) => c.id === colId))?.id;
    if (rowId) updateBlockData(rowId, colId, blockId, data);
  };

  // ── Move block between columns ──
  const moveBlock = (fromRowId: string, fromColId: string, blockId: string, toRowId: string, toColId: string, toIndex: number) => {
    updatePage((p) => {
      let block: EditorBlock | null = null;
      const rows1 = p.rows.map((r) => { if (r.id !== fromRowId) return r; return { ...r, columns: r.columns.map((c) => { if (c.id !== fromColId) return c; const idx = c.blocks.findIndex((b) => b.id === blockId); if (idx === -1) return c; block = c.blocks[idx]; return { ...c, blocks: c.blocks.filter((b) => b.id !== blockId) }; }) }; });
      if (!block) return p;
      const rows2 = rows1.map((r) => { if (r.id !== toRowId) return r; return { ...r, columns: r.columns.map((c) => { if (c.id !== toColId) return c; const newBlocks = [...c.blocks]; newBlocks.splice(Math.min(toIndex, newBlocks.length), 0, block!); return { ...c, blocks: newBlocks }; }) }; });
      return { ...p, rows: rows2 };
    });
  };

  const findBlockLocation = (blockId: string): { rowId: string; colId: string; blockIdx: number } | null => {
    for (const row of page.rows) { for (const col of row.columns) { const blockIdx = col.blocks.findIndex((b) => b.id === blockId); if (blockIdx !== -1) return { rowId: row.id, colId: col.id, blockIdx }; } } return null;
  };

  const customCollisionDetection: CollisionDetection = useCallback((args) => {
    const pointerCollisions = pointerWithin(args);
    const columnCollisions = pointerCollisions.filter((c) => String(c.id).startsWith("droppable-"));
    if (columnCollisions.length > 0) return columnCollisions;
    const blockCollisions = pointerCollisions.filter((c) => { const loc = findBlockLocation(String(c.id)); return loc !== null; });
    if (blockCollisions.length > 0) return blockCollisions;
    return closestCenter(args);
  }, [page.rows]);

  const handleDragStart = (event: DragStartEvent) => {
    const { active } = event;
    const data = active.data.current;
    setActiveId(String(active.id));
    if (data?.type === "catalog") setActiveDragData({ type: "catalog", blockType: data.blockType, id: String(active.id) });
    else if (data?.type === "block") setActiveDragData({ type: "block", id: String(active.id) });
    else setActiveDragData({ type: "row", id: String(active.id) });
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveId(null); setActiveDragData(null);
    const { active, over } = event;
    if (!over) return;
    const activeData = active.data.current;
    const activeIdStr = String(active.id);
    const overIdStr = String(over.id);

    if (activeData?.type === "catalog") {
      const blockType = activeData.blockType as string;
      let targetRowId: string | null = null, targetColId: string | null = null, targetIndex = 0;
      if (overIdStr.startsWith("droppable-")) {
        targetColId = overIdStr.replace("droppable-", "");
        const r = page.rows.find((r) => r.columns.some((c) => c.id === targetColId));
        if (r) { targetRowId = r.id; const col = r.columns.find((c) => c.id === targetColId); targetIndex = col ? col.blocks.length : 0; }
      } else { const loc = findBlockLocation(overIdStr); if (loc) { targetRowId = loc.rowId; targetColId = loc.colId; targetIndex = loc.blockIdx + 1; } }
      if (targetRowId && targetColId) {
        const newBlock = makeBlock(blockType);
        updatePage((p) => ({ ...p, rows: p.rows.map((r) => r.id !== targetRowId ? r : { ...r, columns: r.columns.map((c) => { if (c.id !== targetColId) return c; const nb = [...c.blocks]; nb.splice(targetIndex, 0, newBlock); return { ...c, blocks: nb }; }) }) }));
        setSelection({ type: "block", rowId: targetRowId, colId: targetColId, blockId: newBlock.id });
      }
      return;
    }
    if (activeData?.type === "block") {
      const fromLoc = findBlockLocation(activeIdStr); if (!fromLoc) return;
      if (overIdStr.startsWith("droppable-")) {
        const targetColId = overIdStr.replace("droppable-", "");
        const targetRow = page.rows.find((r) => r.columns.some((c) => c.id === targetColId));
        if (targetRow) { if (fromLoc.colId === targetColId) return; const col = targetRow.columns.find((c) => c.id === targetColId); moveBlock(fromLoc.rowId, fromLoc.colId, activeIdStr, targetRow.id, targetColId, col ? col.blocks.length : 0); setSelection({ type: "block", rowId: targetRow.id, colId: targetColId, blockId: activeIdStr }); }
        return;
      }
      const toLoc = findBlockLocation(overIdStr);
      if (toLoc) {
        if (fromLoc.colId === toLoc.colId) { updatePage((p) => ({ ...p, rows: p.rows.map((r) => { if (r.id !== fromLoc.rowId) return r; return { ...r, columns: r.columns.map((c) => { if (c.id !== fromLoc.colId) return c; const oldIdx = c.blocks.findIndex((b) => b.id === activeIdStr); const newIdx = c.blocks.findIndex((b) => b.id === overIdStr); if (oldIdx === -1 || newIdx === -1) return c; return { ...c, blocks: arrayMove(c.blocks, oldIdx, newIdx) }; }) }; }) })); }
        else { moveBlock(fromLoc.rowId, fromLoc.colId, activeIdStr, toLoc.rowId, toLoc.colId, toLoc.blockIdx); setSelection({ type: "block", rowId: toLoc.rowId, colId: toLoc.colId, blockId: activeIdStr }); }
      }
      return;
    }
    if (active.id === over.id) return;
    updatePage((p) => { const oldIdx = p.rows.findIndex((r) => r.id === active.id); const newIdx = p.rows.findIndex((r) => r.id === over.id); if (oldIdx === -1 || newIdx === -1) return p; return { ...p, rows: arrayMove(p.rows, oldIdx, newIdx) }; });
  };

  const addPage = () => { setPages([...pages, { id: uid("pg"), pageNumber: pages.length + 1, rows: [] }]); setCurrentPageIdx(pages.length); };
  const removePage = (idx: number) => { if (pages.length <= 1) return; const updated = pages.filter((_, i) => i !== idx).map((p, i) => ({ ...p, pageNumber: i + 1 })); setPages(updated); setCurrentPageIdx(Math.min(currentPageIdx, updated.length - 1)); };

  const pageW = docSettings.orientation === "horizontal" ? 842 : 595;
  const pageH = docSettings.orientation === "horizontal" ? 595 : 842;

  return (
    <div className="h-full flex flex-col" data-testid="max-editor">
      {/* Toolbar - matches PDF */}
      <div className="flex items-center justify-between px-4 py-2 bg-white border-b border-gray-200 shrink-0">
        <div className="flex items-center gap-3">
          <Link href="/presupuestos"><span className="text-sm text-[#3F4694] font-semibold cursor-pointer hover:text-[#2e3570]" data-testid="link-back">Volver</span></Link>
          <Button variant="outline" className="text-xs h-8 border-gray-300 rounded-full gap-1.5 px-4" data-testid="button-save"><Save className="w-3.5 h-3.5" /> Guardar borrador</Button>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" className="text-xs h-8 border-[#3F4694] text-[#3F4694] rounded-full px-5" data-testid="button-emit">Emitir</Button>
          <Button className="text-xs h-8 bg-[#F25075] hover:bg-[#d9446a] text-white rounded-full px-5 gap-1.5" data-testid="button-emit-send"><Send className="w-3.5 h-3.5" /> Emitir y enviar</Button>
        </div>
      </div>

      <DndContext sensors={sensors} collisionDetection={customCollisionDetection} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
      <div className="flex flex-1 overflow-hidden">
        {/* Left: Page thumbnails + zoom */}
        <div className="w-[120px] min-w-[120px] bg-white border-r border-gray-100 flex flex-col">
          <div className="flex-1 p-2 overflow-y-auto">
            {pages.map((pg, idx) => (
              <div key={pg.id} onClick={() => { setCurrentPageIdx(idx); setSelection(null); }}
                className={`relative cursor-pointer rounded-lg border-2 p-1 mb-2 transition-all ${idx === currentPageIdx ? "border-[#3F4694] shadow-md" : "border-gray-200 hover:border-gray-300"}`} data-testid={`page-thumb-${idx}`}>
                <div className={`${docSettings.orientation === "horizontal" ? "aspect-[297/210]" : "aspect-[210/297]"} bg-gray-50 rounded text-center flex items-center justify-center overflow-hidden`}>
                  <span className="text-[8px] text-gray-400">Pág. {idx + 1}</span>
                </div>
                <div className="flex items-center justify-between mt-0.5 px-0.5">
                  <span className="text-[8px] text-gray-400">{idx + 1}/{pages.length}</span>
                  {pages.length > 1 && <button onClick={(e) => { e.stopPropagation(); removePage(idx); }} className="text-gray-300 hover:text-red-500"><Trash2 className="w-2.5 h-2.5" /></button>}
                </div>
              </div>
            ))}
            <button onClick={addPage} className="w-full p-2 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center hover:border-[#3F4694]/40 hover:bg-[#3F4694]/5 transition-all" data-testid="add-page">
              <Plus className="w-4 h-4 text-gray-400" />
            </button>
          </div>
          <div className="p-2 border-t border-gray-100">
            <div className="flex items-center gap-0.5 bg-gray-100 rounded-lg px-1 py-0.5">
              <button onClick={() => setZoom(Math.max(50, zoom - 10))} className="p-0.5 text-gray-400 hover:text-gray-600"><ZoomOut className="w-3 h-3" /></button>
              <span className="text-[9px] text-gray-500 flex-1 text-center">{zoom}%</span>
              <button onClick={() => setZoom(Math.min(150, zoom + 10))} className="p-0.5 text-gray-400 hover:text-gray-600"><ZoomIn className="w-3 h-3" /></button>
            </div>
          </div>
        </div>

        {/* Center: Banner + Page nav + Canvas */}
        <div className="flex-1 bg-gray-100 overflow-auto flex flex-col">
          {/* Draft banner */}
          <div className="mx-4 mt-3 bg-amber-50 border border-amber-200 rounded-xl px-4 py-2.5 shrink-0">
            <p className="text-xs font-bold text-gray-800">Borrador</p>
            <p className="text-[10px] text-gray-500">Todavía no has terminado este presupuesto. Prueba a emitirlo.</p>
          </div>
          {/* Page nav */}
          <div className="flex items-center justify-between px-4 py-2 shrink-0">
            <span className="text-xs text-gray-500 font-semibold">{currentPageIdx + 1}/{pages.length}</span>
            <button onClick={addPage} className="w-8 h-8 rounded-full border-2 border-gray-300 flex items-center justify-center hover:border-[#3F4694] hover:bg-[#3F4694]/5 transition-all" data-testid="add-page-center">
              <Plus className="w-4 h-4 text-gray-400" />
            </button>
            <button onClick={() => removePage(currentPageIdx)} className="text-[10px] text-gray-400 hover:text-red-500 transition-colors">Eliminar página</button>
          </div>
          {/* Canvas */}
          <div className="flex-1 overflow-auto px-6 pb-6">
            <div className="mx-auto" style={{ width: pageW, transform: `scale(${zoom / 100})`, transformOrigin: "top center" }}>
              <div className="bg-white shadow-xl rounded-sm relative pl-8" data-testid="canvas-page" style={{
                minHeight: pageH,
                backgroundColor: docSettings.pageBackground,
                border: docSettings.pageBorderEnabled ? `${docSettings.pageBorderWidth}px solid ${docSettings.pageBorderColor}` : "none",
                paddingTop: docSettings.pageMarginTop, paddingBottom: docSettings.pageMarginBottom,
                paddingLeft: docSettings.pageMarginLeft + 32, paddingRight: docSettings.pageMarginRight,
              }}>
                <SortableContext items={page.rows.map((r) => r.id)} strategy={verticalListSortingStrategy}>
                  {page.rows.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-40 text-gray-300">
                      <MousePointer2 className="w-10 h-10 mb-2 opacity-40" />
                      <p className="text-sm font-medium text-gray-400">Página vacía</p>
                      <p className="text-xs text-gray-300 mt-1">Arrastra bloques desde el panel derecho</p>
                    </div>
                  ) : (
                    page.rows.map((row) => (
                      <SortableRow key={row.id} row={row} selection={selection} onSelect={setSelection} onUpdateBlock={updateBlockDataFromCanvas} onDeleteRow={deleteRow} onDuplicateRow={duplicateRow} onDeleteBlock={deleteBlock} onDuplicateBlock={duplicateBlock} />
                    ))
                  )}
                </SortableContext>
                <div className="absolute bottom-2 right-4 text-[9px] text-gray-300">{currentPageIdx + 1} // {pages.length}</div>
              </div>
            </div>
          </div>
        </div>

        {/* Right panel */}
        <div className="w-[280px] min-w-[280px] bg-white border-l border-gray-100 flex flex-col overflow-hidden">
          <div className="flex-1 overflow-y-auto p-3 space-y-2">
            {/* Accordions */}
            <AccordionCard title="Personalizar" isOpen={openPersonalizar} onToggle={() => setOpenPersonalizar(!openPersonalizar)}>
              <div className="space-y-3 pt-2">
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Logo</label>
                  <div className="flex items-center gap-2">
                    <img src={docSettings.logoUrl || logoBlueSrc} alt="Logo" className="h-8 object-contain" />
                    <div className="flex gap-1">{["left", "center", "right"].map((p) => (
                      <button key={p} onClick={() => setDocSettings({ ...docSettings, logoPosition: p })} className={`px-2 py-0.5 text-[9px] rounded border ${docSettings.logoPosition === p ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>{p === "left" ? "Izq" : p === "center" ? "Centro" : "Der"}</button>
                    ))}</div>
                  </div>
                </div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Colores de marca</label>
                  <div className="grid grid-cols-2 gap-2">
                    {[{ k: "brandPrimary" as const, l: "Primario" }, { k: "brandSecondary" as const, l: "Secundario" }, { k: "brandAccent" as const, l: "Acento" }, { k: "brandBackground" as const, l: "Fondo" }].map(({ k, l }) => (
                      <div key={k} className="flex items-center gap-1.5">
                        <input type="color" value={docSettings[k]} onChange={(e) => setDocSettings({ ...docSettings, [k]: e.target.value })} className="w-6 h-6 rounded-full border cursor-pointer" />
                        <span className="text-[9px] text-gray-500">{l}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Tipografía por defecto</label>
                  <select value={docSettings.defaultFont} onChange={(e) => setDocSettings({ ...docSettings, defaultFont: e.target.value })} className="w-full border border-gray-200 rounded px-2 py-1 text-[10px] bg-white">
                    {FONTS.map((f) => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Orientación</label>
                  <div className="flex gap-1">
                    <button onClick={() => setDocSettings({ ...docSettings, orientation: "vertical" })} className={`flex-1 py-1.5 text-[10px] rounded border ${docSettings.orientation === "vertical" ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>Vertical</button>
                    <button onClick={() => setDocSettings({ ...docSettings, orientation: "horizontal" })} className={`flex-1 py-1.5 text-[10px] rounded border ${docSettings.orientation === "horizontal" ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>Horizontal</button>
                  </div>
                </div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Márgenes de página</label>
                  <div className="grid grid-cols-4 gap-1">
                    {(["pageMarginTop", "pageMarginRight", "pageMarginBottom", "pageMarginLeft"] as const).map((k, i) => (
                      <div key={k} className="text-center">
                        <input type="number" min={0} max={60} value={docSettings[k]} onChange={(e) => setDocSettings({ ...docSettings, [k]: Number(e.target.value) })} className="w-full text-center text-[10px] border border-gray-200 rounded px-1 py-0.5" />
                        <span className="text-[8px] text-gray-400">{["Arr", "Der", "Abj", "Izq"][i]}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Fondo de página</label>
                  <ColorSwatchPicker value={docSettings.pageBackground} onChange={(c) => setDocSettings({ ...docSettings, pageBackground: c })} presets={["#ffffff", "#FBFBFB", "#f5f0e8", "#1a1a1a", "#3F4694"]} /></div>
                <div>
                  <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Borde de página</label>
                  <label className="flex items-center gap-2 text-[10px] text-gray-600"><input type="checkbox" checked={docSettings.pageBorderEnabled} onChange={(e) => setDocSettings({ ...docSettings, pageBorderEnabled: e.target.checked })} className="accent-[#3F4694]" /> Activar</label>
                  {docSettings.pageBorderEnabled && (
                    <div className="flex gap-2 mt-1 items-center">
                      <input type="number" min={1} max={5} value={docSettings.pageBorderWidth} onChange={(e) => setDocSettings({ ...docSettings, pageBorderWidth: Number(e.target.value) })} className="w-10 text-center text-[10px] border rounded px-1 py-0.5" />
                      <input type="color" value={docSettings.pageBorderColor} onChange={(e) => setDocSettings({ ...docSettings, pageBorderColor: e.target.value })} className="w-6 h-6 rounded border cursor-pointer" />
                    </div>
                  )}
                </div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Estilo de encabezados</label>
                  <div className="flex gap-1.5 items-center">
                    <input type="color" value={docSettings.headingColor} onChange={(e) => setDocSettings({ ...docSettings, headingColor: e.target.value })} className="w-6 h-6 rounded border cursor-pointer" />
                    <select value={docSettings.headingWeight} onChange={(e) => setDocSettings({ ...docSettings, headingWeight: e.target.value })} className="text-[10px] border rounded px-1 py-0.5 bg-white flex-1">
                      <option value="400">Normal</option><option value="600">Semibold</option><option value="700">Bold</option><option value="900">Black</option>
                    </select>
                    <select value={docSettings.headingTransform} onChange={(e) => setDocSettings({ ...docSettings, headingTransform: e.target.value })} className="text-[10px] border rounded px-1 py-0.5 bg-white flex-1">
                      <option value="none">Normal</option><option value="uppercase">MAYÚSC</option><option value="capitalize">Capital</option>
                    </select>
                  </div>
                </div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-1 block">Estilo de textos</label>
                  <div className="flex gap-1.5 items-center">
                    <input type="color" value={docSettings.textColor} onChange={(e) => setDocSettings({ ...docSettings, textColor: e.target.value })} className="w-6 h-6 rounded border cursor-pointer" />
                    <span className="text-[9px] text-gray-400">Alt. línea:</span>
                    <input type="range" min={1} max={2.5} step={0.1} value={docSettings.textLineHeight} onChange={(e) => setDocSettings({ ...docSettings, textLineHeight: Number(e.target.value) })} className="flex-1 accent-[#3F4694]" />
                    <span className="text-[9px] text-gray-400">{docSettings.textLineHeight}</span>
                  </div>
                </div>
              </div>
            </AccordionCard>

            <AccordionCard title="Métodos de pago" isOpen={openMetodos} onToggle={() => setOpenMetodos(!openMetodos)}>
              <div className="space-y-2 pt-2">
                {["Transferencia bancaria", "Bizum", "PayPal", "Tarjeta", "Efectivo"].map((m) => (
                  <label key={m} className="flex items-center gap-2 text-[10px] text-gray-600">
                    <input type="checkbox" checked={docSettings.paymentMethods.includes(m.toLowerCase().split(" ")[0])} onChange={(e) => {
                      const key = m.toLowerCase().split(" ")[0];
                      setDocSettings({ ...docSettings, paymentMethods: e.target.checked ? [...docSettings.paymentMethods, key] : docSettings.paymentMethods.filter((p) => p !== key) });
                    }} className="accent-[#3F4694]" /> {m}
                  </label>
                ))}
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">IBAN</label>
                  <input type="text" value={docSettings.iban} onChange={(e) => setDocSettings({ ...docSettings, iban: e.target.value })} placeholder="ES00 0000 0000 0000 0000" className="w-full border border-gray-200 rounded px-2 py-1 text-[10px] focus:border-[#3F4694] outline-none" /></div>
                <div><label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-0.5 block">Notas de pago</label>
                  <textarea value={docSettings.paymentNotes} onChange={(e) => setDocSettings({ ...docSettings, paymentNotes: e.target.value })} rows={2} className="w-full border border-gray-200 rounded px-2 py-1 text-[10px] focus:border-[#3F4694] outline-none resize-none" placeholder="Condiciones de pago..." /></div>
              </div>
            </AccordionCard>

            <AccordionCard title="Recurrencia" isOpen={openRecurrencia} onToggle={() => setOpenRecurrencia(!openRecurrencia)}>
              <div className="space-y-2 pt-2">
                <label className="flex items-center gap-2 text-[10px] text-gray-600"><input type="checkbox" checked={docSettings.isRecurring} onChange={(e) => setDocSettings({ ...docSettings, isRecurring: e.target.checked })} className="accent-[#3F4694]" /> Presupuesto recurrente</label>
                {docSettings.isRecurring && (
                  <div className="flex gap-1">{["mensual", "trimestral", "anual"].map((f) => (
                    <button key={f} onClick={() => setDocSettings({ ...docSettings, recurringFrequency: f })} className={`flex-1 py-1 text-[10px] rounded border capitalize ${docSettings.recurringFrequency === f ? "border-[#3F4694] bg-[#3F4694]/10 text-[#3F4694]" : "border-gray-200 text-gray-500"}`}>{f}</button>
                  ))}</div>
                )}
              </div>
            </AccordionCard>

            <AccordionCard title="Tipo" isOpen={openTipo} onToggle={() => setOpenTipo(!openTipo)}>
              <div className="space-y-1.5 pt-2">
                {[{ v: "presupuesto", l: "Presupuesto" }, { v: "proforma", l: "Factura proforma" }, { v: "propuesta", l: "Propuesta comercial" }].map(({ v, l }) => (
                  <label key={v} className="flex items-center gap-2 text-[10px] text-gray-600">
                    <input type="radio" name="docType" checked={docSettings.docType === v} onChange={() => setDocSettings({ ...docSettings, docType: v })} className="accent-[#3F4694]" /> {l}
                  </label>
                ))}
              </div>
            </AccordionCard>

            {/* Widget catalog */}
            <div className="pt-2">
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Estructura (fila)</p>
              <div className="flex gap-1.5 mb-3">
                {ROW_PRESETS.map((rp) => (
                  <button key={rp.cols} onClick={() => addRow(rp.cols)} className="flex-1 flex flex-col items-center gap-1 p-2 border border-gray-200 rounded-xl hover:border-[#3F4694]/30 hover:bg-[#3F4694]/5 transition-all" data-testid={`add-row-${rp.cols}`}>
                    <rp.icon className="w-4 h-4 text-gray-500" />
                    <span className="text-[9px] text-gray-500">{rp.label}</span>
                  </button>
                ))}
              </div>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wider mb-2">Arrastra un bloque al canvas</p>
              <div className="grid grid-cols-2 gap-1.5">
                {BLOCK_CATALOG.map((b) => (
                  <DraggableCatalogItem key={b.type} type={b.type} label={b.label} icon={b.icon} />
                ))}
              </div>
            </div>

            {/* Style panel when selected */}
            {selection && (
              <div className="pt-2 border-t border-gray-200 mt-3">
                <p className="text-[10px] font-bold text-[#F25075] uppercase tracking-wider mb-2">Estilos del elemento</p>
                <StylePanel
                  selection={selection} pages={pages} currentPageIdx={currentPageIdx}
                  onUpdateRowStyle={updateRowStyle} onUpdateColumnStyle={updateColumnStyle}
                  onUpdateBlockStyle={updateBlockStyle} onUpdateBlockData={updateBlockData}
                  onSetColumns={setColumns} onDeleteRow={deleteRow} onDuplicateRow={duplicateRow}
                  onDeleteBlock={deleteBlock} onDuplicateBlock={duplicateBlock}
                  onAddBlockToColumn={addBlockToColumn} onToggleRowVisible={toggleRowVisible}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      <DragOverlay dropAnimation={null}>
        {activeDragData ? (
          activeDragData.type === "row" ? (
            <div className="bg-white border-2 border-blue-400 rounded-lg p-3 shadow-2xl opacity-90 text-xs text-blue-500 font-semibold flex items-center gap-2"><GripVertical className="w-3.5 h-3.5" /> Moviendo fila...</div>
          ) : activeDragData.type === "block" ? (
            <div className="bg-white border-2 border-[#F25075] rounded-lg p-3 shadow-2xl opacity-90 text-xs text-[#F25075] font-semibold flex items-center gap-2"><Layers className="w-3.5 h-3.5" /> Moviendo bloque...</div>
          ) : activeDragData.type === "catalog" ? (
            <div className="bg-white border-2 border-[#3F4694] rounded-lg p-3 shadow-2xl opacity-95 text-xs text-[#3F4694] font-semibold flex items-center gap-2">
              <Plus className="w-3.5 h-3.5" /> {BLOCK_CATALOG.find((b) => b.type === activeDragData.blockType)?.label || "Bloque"}
            </div>
          ) : null
        ) : null}
      </DragOverlay>
      </DndContext>
    </div>
  );
}
