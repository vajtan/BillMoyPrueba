import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  FileText,
  ClipboardList,
  ArrowUpCircle,
  Users,
  Package,
  ChevronRight,
} from "lucide-react";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useState } from "react";

const quickActions = [
  { label: "Crear factura", icon: FileText, href: "/facturas/nueva" },
  { label: "Crear presupuesto", icon: ClipboardList, href: "/presupuestos/nuevo" },
  { label: "Subir gasto", icon: ArrowUpCircle, href: "/gastos" },
  { label: "Crear contacto", icon: Users, href: "/contactos/nuevo" },
  { label: "Crear producto", icon: Package, href: "/productos" },
];

function StatusBadge({ status }: { status: string }) {
  const colors: Record<string, string> = {
    paid: "text-green-600",
    sent: "text-[#3F4694]",
    draft: "text-gray-400",
    accepted: "text-green-600",
    pending: "text-orange-500",
  };
  const labels: Record<string, string> = {
    paid: "Cobrada",
    sent: "Pendiente",
    draft: "Borrador",
    accepted: "Aceptado",
    pending: "Pendiente",
  };
  return (
    <span className={`text-xs font-medium ${colors[status] || "text-gray-400"}`}>
      {labels[status] || status}
    </span>
  );
}

export default function Dashboard() {
  const [period, setPeriod] = useState("6m");
  const { data: stats } = useQuery<any>({ queryKey: ["/api/dashboard/stats"] });
  const { data: clients } = useQuery<any[]>({ queryKey: ["/api/clients"] });

  const periods = [
    { key: "2y", label: "2 Años" },
    { key: "1y", label: "1 Año" },
    { key: "6m", label: "6 Meses" },
    { key: "1m", label: "1 Mes" },
  ];

  return (
    <div className="p-6">
      <h1
        className="text-2xl font-bold mb-6"
        style={{ color: "#3F4694" }}
        data-testid="text-page-title"
      >
        General
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        {/* Main content */}
        <div className="space-y-6">
          {/* KPI cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
              <p className="text-xs text-gray-400 mb-1">Marzo</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500 font-medium">Total Facturado</p>
                  <p className="text-xl font-bold text-gray-800" data-testid="text-total-invoiced">
                    {stats ? Number(stats.totalInvoiced).toLocaleString("es-ES", { minimumFractionDigits: 2 }) : "0,00"} €
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 font-medium">Total gastos</p>
                  <p className="text-xl font-bold text-[#F25075]" data-testid="text-total-expenses">
                    {stats ? Number(stats.totalExpenses).toLocaleString("es-ES", { minimumFractionDigits: 2 }) : "0,00"} €
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div>
                  <p className="text-[11px] text-gray-400">Impto. repercutidos</p>
                  <p className="text-sm font-semibold text-gray-700">{stats?.taxRepercutidos || "0"} €</p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400">Impto. soportados</p>
                  <p className="text-sm font-semibold text-[#F25075]">{stats?.taxSoportados || "0"} €</p>
                </div>
              </div>
            </div>
            <div className="bg-white rounded-lg p-5 shadow-sm border border-[#3F4694]/20">
              <p className="text-xs text-[#3F4694] font-semibold mb-1">1er Trimestre</p>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-xs text-gray-500 font-medium">Total Facturado</p>
                  <p className="text-xl font-bold text-[#3F4694]" data-testid="text-quarterly-invoiced">
                    {stats ? Number(stats.totalInvoiced).toLocaleString("es-ES", { minimumFractionDigits: 2 }) : "0,00"} €
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-500 font-medium">Total gastos</p>
                  <p className="text-xl font-bold text-[#F25075]" data-testid="text-quarterly-expenses">
                    {stats ? Number(stats.totalExpenses).toLocaleString("es-ES", { minimumFractionDigits: 2 }) : "0,00"} €
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-3">
                <div>
                  <p className="text-[11px] text-gray-400">Impto. repercutidos</p>
                  <p className="text-sm font-semibold text-[#3F4694]">{stats?.taxRepercutidos || "0"} €</p>
                </div>
                <div>
                  <p className="text-[11px] text-gray-400">Impto. soportados</p>
                  <p className="text-sm font-semibold text-[#F25075]">{stats?.taxSoportados || "0"} €</p>
                </div>
              </div>
            </div>
          </div>

          {/* Chart */}
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <div className="flex gap-4">
                <span className="text-sm font-semibold text-[#3F4694]">Ingresos</span>
                <span className="text-sm font-semibold text-[#F25075]">Gastos</span>
              </div>
              <div className="flex gap-1">
                {periods.map((p) => (
                  <button
                    key={p.key}
                    onClick={() => setPeriod(p.key)}
                    className={`px-3 py-1 text-xs rounded-md transition-colors ${
                      period === p.key
                        ? "text-[#3F4694] font-semibold bg-[#3F4694]/5"
                        : "text-gray-400 hover:text-gray-600"
                    }`}
                    data-testid={`button-period-${p.key}`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={stats?.monthlyData || []}>
                <defs>
                  <linearGradient id="colorIngresos" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3F4694" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#3F4694" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: "#999" }} />
                <YAxis tick={{ fontSize: 12, fill: "#999" }} />
                <Tooltip />
                <Area type="monotone" dataKey="ingresos" stroke="#3F4694" fill="url(#colorIngresos)" strokeWidth={2} />
                <Area type="monotone" dataKey="gastos" stroke="#F25075" fill="transparent" strokeWidth={2} strokeDasharray="5 5" />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Recent documents */}
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-[#3F4694]">Últimos documentos</h3>
              <select className="text-xs border rounded px-2 py-1 text-gray-500" data-testid="select-doc-filter">
                <option>Facturas Emitidas</option>
                <option>Presupuestos</option>
              </select>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {(stats?.recentDocuments || []).slice(0, 3).map((doc: any) => (
                <div
                  key={doc.id}
                  className="border border-[#3F4694]/15 rounded-lg p-4 hover:border-[#3F4694]/40 transition-colors cursor-pointer"
                  data-testid={`card-doc-${doc.id}`}
                >
                  <p className="text-xs text-gray-400">
                    {doc.number} | {doc.issueDate}
                  </p>
                  <p className="text-sm font-medium text-gray-700 mt-1">
                    Cliente #{doc.clientId}
                  </p>
                  <p className="text-sm font-bold text-[#F25075] mt-1">
                    {Number(doc.total).toLocaleString("es-ES", { minimumFractionDigits: 2 })} €
                  </p>
                  <StatusBadge status={doc.status} />
                </div>
              ))}
            </div>
          </div>

          {/* Frequent clients */}
          <div className="bg-white rounded-lg p-5 shadow-sm border border-gray-100">
            <h3 className="text-sm font-bold text-[#3F4694] mb-4">Clientes frecuentes</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {(clients || []).slice(0, 3).map((client: any) => (
                <div
                  key={client.id}
                  className="border border-[#3F4694]/15 rounded-lg p-4"
                  data-testid={`card-client-${client.id}`}
                >
                  <p className="text-sm font-semibold text-gray-700 mb-2">{client.name}</p>
                  <Link href={`/facturas/nueva`}>
                    <p className="text-xs text-[#3F4694] flex items-center gap-1 cursor-pointer hover:underline">
                      <FileText className="w-3 h-3" /> Crear factura
                    </p>
                  </Link>
                  <Link href={`/presupuestos/nuevo`}>
                    <p className="text-xs text-[#F25075] flex items-center gap-1 mt-1 cursor-pointer hover:underline">
                      <ClipboardList className="w-3 h-3" /> Crear presupuesto
                    </p>
                  </Link>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            {quickActions.map((action) => (
              <Link key={action.label} href={action.href}>
                <div
                  className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0 cursor-pointer hover:bg-gray-50 rounded px-2 -mx-2 transition-colors"
                  data-testid={`action-${action.label.toLowerCase().replace(/\s/g, "-")}`}
                >
                  <div className="flex items-center gap-3">
                    <action.icon className="w-5 h-5 text-[#3F4694]" />
                    <span className="text-sm text-gray-700">{action.label}</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </div>
              </Link>
            ))}
          </div>

          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="text-sm font-bold text-[#F25075]">Personalizar plantilla</h4>
            <p className="text-xs text-gray-500 mt-1">
              Prepara la plantilla una vez, y olvídate{" "}
              <span className="font-semibold">para siempre</span>.
            </p>
            <Link href="/presupuestos/max/nuevo">
              <button
                className="mt-3 px-4 py-1.5 bg-[#F25075] text-white text-xs font-semibold rounded-md hover:bg-[#d9446a] transition-colors"
                data-testid="button-customize-template"
              >
                Define tu estilo
              </button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
