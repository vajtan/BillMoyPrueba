import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, Plus, Image, Trash2, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import type { PortfolioItem } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Portfolio() {
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ title: "", description: "", category: "", imageUrl: "", externalLink: "" });

  const { data: items = [] } = useQuery<PortfolioItem[]>({ queryKey: ["/api/portfolio"] });

  const filtered = items.filter((p) =>
    search ? p.title.toLowerCase().includes(search.toLowerCase()) : true
  );

  const handleCreate = async () => {
    await apiRequest("POST", "/api/portfolio", { ...formData, userId: 1 });
    queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
    setShowForm(false);
    setFormData({ title: "", description: "", category: "", imageUrl: "", externalLink: "" });
  };

  const handleDelete = async (id: number) => {
    await apiRequest("DELETE", `/api/portfolio/${id}`);
    queryClient.invalidateQueries({ queryKey: ["/api/portfolio"] });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }} data-testid="text-page-title">
        Proyectos / Portfolio
      </h1>

      <div className="flex items-center justify-between mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            placeholder="Buscar proyecto..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 pr-3 py-1.5 text-sm border rounded-md w-60"
            data-testid="input-search"
          />
        </div>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button className="bg-[#F25075] hover:bg-[#d9446a] text-white text-sm" data-testid="button-create-project">
              <Plus className="w-4 h-4 mr-1" /> Nuevo proyecto
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Nuevo proyecto</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input
                placeholder="Título del proyecto"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                data-testid="input-project-title"
              />
              <Textarea
                placeholder="Descripción"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              />
              <Input
                placeholder="Categoría (ej: Branding, Web, Editorial)"
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              />
              <Input
                placeholder="URL de imagen (opcional)"
                value={formData.imageUrl}
                onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
              />
              <Input
                placeholder="Enlace externo (opcional)"
                value={formData.externalLink}
                onChange={(e) => setFormData({ ...formData, externalLink: e.target.value })}
              />
              <Button onClick={handleCreate} className="w-full bg-[#F25075] hover:bg-[#d9446a] text-white" data-testid="button-save-project">
                Guardar proyecto
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-12 text-center">
          <Image className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">No hay proyectos en tu portfolio todavía.</p>
          <p className="text-gray-400 text-xs mt-1">Añade trabajos anteriores para incluirlos en presupuestos MAX.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-lg shadow-sm border border-gray-100 overflow-hidden hover:border-[#3F4694]/30 transition-colors"
              data-testid={`card-project-${item.id}`}
            >
              {item.imageUrl ? (
                <div className="w-full h-36 bg-gray-100">
                  <img src={item.imageUrl} alt={item.title} className="w-full h-full object-cover" />
                </div>
              ) : (
                <div className="w-full h-36 bg-gray-50 flex items-center justify-center">
                  <Image className="w-10 h-10 text-gray-300" />
                </div>
              )}
              <div className="p-4">
                <div className="flex items-start justify-between">
                  <h3 className="text-sm font-semibold text-gray-700">{item.title}</h3>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="text-gray-300 hover:text-[#F25075] transition-colors"
                    data-testid={`button-delete-project-${item.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                {item.category && (
                  <span className="inline-block px-2 py-0.5 rounded-full text-xs font-medium bg-[#3F4694]/10 text-[#3F4694] mt-1">
                    {item.category}
                  </span>
                )}
                {item.description && (
                  <p className="text-xs text-gray-400 mt-2 line-clamp-2">{item.description}</p>
                )}
                {item.externalLink && (
                  <a href={item.externalLink} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-xs text-[#3F4694] mt-2 hover:underline">
                    <ExternalLink className="w-3 h-3" /> Ver proyecto
                  </a>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
