import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Search, ChevronRight, AlertCircle } from "lucide-react";
import type { Client } from "@shared/schema";
import { RowActions, useEntityActions } from "@/components/row-actions";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Contactos() {
  const [search, setSearch] = useState("");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });

  const filtered = clients.filter((c) =>
    search
      ? c.name.toLowerCase().includes(search.toLowerCase()) ||
        (c.email || "").toLowerCase().includes(search.toLowerCase())
      : true
  );

  const handleDelete = async (id: number) => {
    await apiRequest("DELETE", `/api/clients/${id}`);
    queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
    toast({ title: "Contacto eliminado" });
  };

  const handleDuplicate = async (client: Client) => {
    const { id, ...rest } = client;
    await apiRequest("POST", "/api/clients", { ...rest, name: `${rest.name} (copia)` });
    queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
    toast({ title: "Contacto duplicado" });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }} data-testid="text-page-title">
        Contactos
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100">
          <div className="flex items-center justify-between px-5 pt-4 pb-2">
            <div className="flex gap-4">
              <span className="text-sm text-[#3F4694] font-semibold border-b-2 border-[#3F4694] pb-2">Contactos</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input placeholder="Buscar..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-3 py-1.5 text-sm border rounded-md w-40" data-testid="input-search" />
              </div>
              <select className="text-xs border rounded px-2 py-1.5 text-gray-500">
                <option>Más nuevos</option>
                <option>A-Z</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-gray-400 text-left">
                  <th className="px-5 py-3 font-medium">Nombre</th>
                  <th className="px-3 py-3 font-medium">Teléfono</th>
                  <th className="px-3 py-3 font-medium">Email</th>
                  <th className="px-3 py-3 font-medium">Sector</th>
                  <th className="px-3 py-3 w-12"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-5 py-12 text-center">
                      <AlertCircle className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                      <p className="text-sm text-gray-400">No hay contactos todavía.</p>
                    </td>
                  </tr>
                )}
                {filtered.map((client) => (
                  <tr key={client.id} className="border-b border-gray-50 hover:bg-gray-50/50" data-testid={`row-client-${client.id}`}>
                    <td className="px-5 py-3">
                      <Link href={`/contactos/${client.id}`}>
                        <div className="flex items-center gap-3 cursor-pointer">
                          <div className="w-8 h-8 rounded-full bg-[#3F4694] text-white flex items-center justify-center text-xs font-semibold">
                            {client.name.charAt(0)}
                          </div>
                          <span className="text-gray-700 font-medium hover:text-[#3F4694]">{client.name}</span>
                        </div>
                      </Link>
                    </td>
                    <td className="px-3 py-3 text-gray-600">{client.phone || "—"}</td>
                    <td className="px-3 py-3 text-gray-600">{client.email || "—"}</td>
                    <td className="px-3 py-3 text-gray-600">{client.sector || "—"}</td>
                    <td className="px-3 py-3">
                      <RowActions
                        actions={useEntityActions({
                          onEdit: () => navigate(`/contactos/${client.id}`),
                          onDuplicate: () => handleDuplicate(client),
                          onDelete: () => handleDelete(client.id),
                        })}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filtered.length > 0 && (
            <div className="flex items-center justify-between px-5 py-3 text-sm text-gray-400 border-t border-gray-50">
              <span>{filtered.length} contacto{filtered.length !== 1 ? "s" : ""}</span>
            </div>
          )}
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">
          <Link href="/contactos/nuevo">
            <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer hover:bg-gray-50" data-testid="button-create-contact">
              <span className="text-sm font-semibold text-[#3F4694]">Crear contacto</span>
              <ChevronRight className="w-4 h-4 text-gray-400" />
            </div>
          </Link>

          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="text-sm font-semibold text-gray-700">Contactos totales</h4>
            <p className="text-xl font-bold text-[#3F4694]" data-testid="text-total-contacts">{clients.length}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
