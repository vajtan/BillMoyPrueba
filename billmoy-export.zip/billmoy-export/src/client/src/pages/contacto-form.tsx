import { Link } from "wouter";
import { ArrowLeft, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export default function ContactoForm() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }}>Contactos</h1>

      <div className="flex items-center justify-between mb-4">
        <Link href="/contactos">
          <span className="text-sm text-[#3F4694] font-semibold cursor-pointer flex items-center gap-1" data-testid="link-back">
            <ArrowLeft className="w-4 h-4" /> Volver
          </span>
        </Link>
        <Button className="h-9 bg-[#F25075] hover:bg-[#d9446a] text-white text-sm font-semibold" data-testid="button-save-client">
          Guardar cliente
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-6">
          <div className="grid grid-cols-1 md:grid-cols-[1fr_1fr] gap-8">
            <div>
              <h3 className="text-sm font-semibold text-gray-700 mb-4">Datos de cliente:</h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Nombre Fiscal</label>
                    <Input placeholder="Nombre Fiscal" className="h-9" data-testid="input-name" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">NIF</label>
                    <Input placeholder="NIF" className="h-9" data-testid="input-nif" />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Dirección</label>
                  <Input placeholder="Dirección" className="h-9" data-testid="input-address" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Ciudad</label>
                    <Input placeholder="Ciudad Real" className="h-9" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">C.P.</label>
                    <Input placeholder="C.P." className="h-9" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Provincia</label>
                    <Input placeholder="Provincia" className="h-9" />
                  </div>
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">País</label>
                    <Input value="España" className="h-9" readOnly />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-gray-500 mb-1 block">Teléfono</label>
                  <Input placeholder="Teléfono" className="h-9" data-testid="input-phone" />
                </div>
              </div>
            </div>

            <div className="flex items-start justify-center">
              <div className="w-full max-w-[240px] h-[240px] border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center text-gray-400 cursor-pointer hover:border-[#3F4694]/30 transition-colors" data-testid="upload-image">
                <Plus className="w-8 h-8 mb-2" />
                <span className="text-sm">Añadir imagen</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100 flex items-center justify-between cursor-pointer hover:bg-gray-50">
            <span className="text-sm font-semibold text-[#3F4694]">Crear contacto</span>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="text-sm font-semibold text-gray-700">Contactos totales</h4>
            <p className="text-xl font-bold text-[#3F4694]">135</p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-gray-700">Últimos contactos</h4>
              <select className="text-xs border rounded px-2 py-1 text-gray-500"><option>Julio</option></select>
            </div>
            <p className="text-xl font-bold text-[#3F4694]">25</p>
          </div>
        </div>
      </div>
    </div>
  );
}
