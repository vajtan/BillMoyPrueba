import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, Plus, FileText, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import type { ContractTemplate } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Contratos() {
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: "", type: "custom", body: "" });

  const { data: templates = [] } = useQuery<ContractTemplate[]>({ queryKey: ["/api/contract-templates"] });

  const filtered = templates.filter((t) =>
    search ? t.name.toLowerCase().includes(search.toLowerCase()) : true
  );

  const handleCreate = async () => {
    await apiRequest("POST", "/api/contract-templates", { ...formData, userId: 1 });
    queryClient.invalidateQueries({ queryKey: ["/api/contract-templates"] });
    setShowForm(false);
    setFormData({ name: "", type: "custom", body: "" });
  };

  const handleDelete = async (id: number) => {
    await apiRequest("DELETE", `/api/contract-templates/${id}`);
    queryClient.invalidateQueries({ queryKey: ["/api/contract-templates"] });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }} data-testid="text-page-title">
        Contratos
      </h1>

      <div className="flex items-center justify-between mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            placeholder="Buscar plantilla..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 pr-3 py-1.5 text-sm border rounded-md w-60"
            data-testid="input-search"
          />
        </div>
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogTrigger asChild>
            <Button className="bg-[#F25075] hover:bg-[#d9446a] text-white text-sm" data-testid="button-create-contract">
              <Plus className="w-4 h-4 mr-1" /> Nueva plantilla
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader>
              <DialogTitle>Nueva plantilla de contrato</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 mt-2">
              <Input
                placeholder="Nombre de la plantilla"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                data-testid="input-contract-name"
              />
              <select
                className="w-full text-sm border rounded-md px-3 py-2 text-gray-700"
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                data-testid="select-contract-type"
              >
                <option value="custom">Personalizada</option>
                <option value="freelance">Freelance</option>
                <option value="confidencialidad">Confidencialidad (NDA)</option>
                <option value="servicios">Prestación de servicios</option>
              </select>
              <Textarea
                placeholder="Cuerpo del contrato..."
                rows={10}
                value={formData.body}
                onChange={(e) => setFormData({ ...formData, body: e.target.value })}
                data-testid="input-contract-body"
              />
              <Button onClick={handleCreate} className="w-full bg-[#F25075] hover:bg-[#d9446a] text-white" data-testid="button-save-contract">
                Guardar plantilla
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white rounded-lg shadow-sm border border-gray-100 p-12 text-center">
          <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">No hay plantillas de contrato todavía.</p>
          <p className="text-gray-400 text-xs mt-1">Crea tu primera plantilla para adjuntarla a presupuestos y facturas.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((template) => (
            <div
              key={template.id}
              className="bg-white rounded-lg shadow-sm border border-gray-100 p-5 hover:border-[#3F4694]/30 transition-colors"
              data-testid={`card-contract-${template.id}`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <FileText className="w-5 h-5 text-[#3F4694]" />
                  <h3 className="text-sm font-semibold text-gray-700">{template.name}</h3>
                </div>
                <button
                  onClick={() => handleDelete(template.id)}
                  className="text-gray-300 hover:text-[#F25075] transition-colors"
                  data-testid={`button-delete-contract-${template.id}`}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              <span className="inline-block px-2 py-0.5 rounded-full text-xs font-medium bg-[#3F4694]/10 text-[#3F4694]">
                {template.type === "system" ? "Sistema" : "Personalizada"}
              </span>
              <p className="text-xs text-gray-400 mt-2 line-clamp-3">{template.body}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
