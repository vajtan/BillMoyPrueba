import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, Plus, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import type { Expense } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { RowActions, useEntityActions } from "@/components/row-actions";
import { useToast } from "@/hooks/use-toast";

const statusLabels: Record<string, string> = { paid: "Pagado", pending: "Pendiente" };
const statusColors: Record<string, string> = { paid: "bg-green-100 text-green-700", pending: "bg-orange-100 text-orange-700" };

export default function Gastos() {
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [formData, setFormData] = useState({ provider: "", date: "", category: "", amount: "", taxAmount: "", status: "pending" });
  const { toast } = useToast();

  const { data: expenses = [] } = useQuery<Expense[]>({ queryKey: ["/api/expenses"] });

  const filtered = expenses.filter((e) =>
    search ? e.provider.toLowerCase().includes(search.toLowerCase()) || (e.category || "").toLowerCase().includes(search.toLowerCase()) : true
  );

  const resetForm = () => {
    setFormData({ provider: "", date: "", category: "", amount: "", taxAmount: "", status: "pending" });
    setEditingId(null);
  };

  const handleSave = async () => {
    if (editingId) {
      await apiRequest("PATCH", `/api/expenses/${editingId}`, formData);
      toast({ title: "Gasto actualizado" });
    } else {
      await apiRequest("POST", "/api/expenses", { ...formData, userId: 1 });
      toast({ title: "Gasto registrado" });
    }
    queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    setShowForm(false);
    resetForm();
  };

  const handleEdit = (expense: Expense) => {
    setFormData({
      provider: expense.provider,
      date: expense.date || "",
      category: expense.category || "",
      amount: String(expense.amount),
      taxAmount: String(expense.taxAmount || "0"),
      status: expense.status || "pending",
    });
    setEditingId(expense.id);
    setShowForm(true);
  };

  const handleDelete = async (id: number) => {
    await apiRequest("DELETE", `/api/expenses/${id}`);
    queryClient.invalidateQueries({ queryKey: ["/api/expenses"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    toast({ title: "Gasto eliminado" });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }} data-testid="text-page-title">Gastos</h1>

      <div className="flex items-center justify-between mb-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input placeholder="Buscar..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 pr-3 py-1.5 text-sm border rounded-md w-60" data-testid="input-search" />
        </div>
        <Dialog open={showForm} onOpenChange={(open) => { setShowForm(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button className="bg-[#F25075] hover:bg-[#d9446a] text-white text-sm" data-testid="button-upload-expense">
              <Plus className="w-4 h-4 mr-1" /> Subir gasto
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>{editingId ? "Editar gasto" : "Nuevo gasto"}</DialogTitle></DialogHeader>
            <div className="space-y-3 mt-2">
              <Input placeholder="Proveedor" value={formData.provider} onChange={(e) => setFormData({ ...formData, provider: e.target.value })} />
              <Input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} />
              <Input placeholder="Categoría" value={formData.category} onChange={(e) => setFormData({ ...formData, category: e.target.value })} />
              <div className="grid grid-cols-2 gap-3">
                <Input placeholder="Importe" value={formData.amount} onChange={(e) => setFormData({ ...formData, amount: e.target.value })} />
                <Input placeholder="IVA soportado" value={formData.taxAmount} onChange={(e) => setFormData({ ...formData, taxAmount: e.target.value })} />
              </div>
              <div>
                <label className="text-xs text-gray-500 font-medium mb-1 block">Estado</label>
                <select
                  className="w-full text-sm border rounded-md px-3 py-2 text-gray-700"
                  value={formData.status}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                >
                  <option value="pending">Pendiente</option>
                  <option value="paid">Pagado</option>
                </select>
              </div>
              <Button onClick={handleSave} className="w-full bg-[#F25075] hover:bg-[#d9446a] text-white">
                {editingId ? "Actualizar" : "Guardar"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-100">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b text-gray-400 text-left">
              <th className="px-5 py-3 font-medium">Proveedor</th>
              <th className="px-3 py-3 font-medium">Fecha</th>
              <th className="px-3 py-3 font-medium">Categoría</th>
              <th className="px-3 py-3 font-medium">Importe</th>
              <th className="px-3 py-3 font-medium">Impuestos</th>
              <th className="px-3 py-3 font-medium">Estado</th>
              <th className="px-3 py-3 w-12"></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="px-5 py-12 text-center">
                  <AlertCircle className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                  <p className="text-sm text-gray-400">No hay gastos registrados.</p>
                </td>
              </tr>
            )}
            {filtered.map((expense) => (
              <tr key={expense.id} className="border-b border-gray-50 hover:bg-gray-50/50" data-testid={`row-expense-${expense.id}`}>
                <td className="px-5 py-3 text-gray-700 font-medium">{expense.provider}</td>
                <td className="px-3 py-3 text-gray-600">{expense.date || "—"}</td>
                <td className="px-3 py-3 text-gray-600">{expense.category || "—"}</td>
                <td className="px-3 py-3 text-gray-700 font-semibold">{Number(expense.amount).toLocaleString("es-ES", { minimumFractionDigits: 2 })} €</td>
                <td className="px-3 py-3 text-gray-600">{Number(expense.taxAmount).toLocaleString("es-ES", { minimumFractionDigits: 2 })} €</td>
                <td className="px-3 py-3">
                  <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${statusColors[expense.status || ""] || "bg-gray-100 text-gray-500"}`}>
                    {statusLabels[expense.status || ""] || expense.status}
                  </span>
                </td>
                <td className="px-3 py-3">
                  <RowActions
                    actions={useEntityActions({
                      onEdit: () => handleEdit(expense),
                      onDelete: () => handleDelete(expense.id),
                    })}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length > 0 && (
          <div className="flex items-center px-5 py-3 text-sm text-gray-400 border-t border-gray-50">
            <span>{filtered.length} gasto{filtered.length !== 1 ? "s" : ""}</span>
          </div>
        )}
      </div>
    </div>
  );
}
