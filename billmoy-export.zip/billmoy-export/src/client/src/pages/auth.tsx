import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type AuthView = "login" | "register" | "recover" | "done";

export default function AuthPage({ onLogin }: { onLogin: () => void }) {
  const [view, setView] = useState<AuthView>("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (view === "login" || view === "register") {
      onLogin();
    } else if (view === "recover") {
      setView("done");
    }
  };

  return (
    <div className="flex h-screen w-full">
      {/* Left panel */}
      <div className="hidden lg:flex flex-col justify-center w-1/2 px-16 bg-white">
        <h1
          className="text-3xl font-bold mb-4"
          style={{ color: "#3F4694" }}
          data-testid="text-brand"
        >
          Billmoy
        </h1>
        <h2 className="text-2xl font-bold text-gray-800 mb-3 leading-tight">
          Presupuestos que venden,
          <br />
          facturación que no molesta
        </h2>
        <p className="text-gray-500 text-sm leading-relaxed max-w-md">
          Software de facturación y presupuestos pensado para creativos y
          profesionales de servicios. Muestra tu trabajo con presupuestos
          visuales que convencen.
        </p>
      </div>

      {/* Right panel with floral bg */}
      <div
        className="flex-1 flex items-center justify-center relative"
        style={{
          background: "linear-gradient(135deg, #3F4694 0%, #2a2f5e 100%)",
        }}
      >
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              'url("https://images.unsplash.com/photo-1490750967868-88aa4f44baee?w=1200&q=80")',
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="relative z-10 bg-white rounded-xl shadow-2xl p-8 w-full max-w-md mx-4">
          {view === "done" ? (
            <div data-testid="view-done">
              <h2 className="text-2xl font-bold text-gray-800 mb-2">
                Hecho ;)
              </h2>
              <p className="text-gray-500 text-sm mb-6">
                Te hemos enviado un correo con las instrucciones para recuperar
                tu contraseña.
              </p>
              <Button
                className="w-full bg-[#F25075] hover:bg-[#d9446a] text-white"
                onClick={() => setView("login")}
                data-testid="button-back-login"
              >
                Volver al inicio
              </Button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              <h2
                className="text-2xl font-bold text-gray-800 mb-2"
                data-testid="text-auth-title"
              >
                {view === "login"
                  ? "Iniciar sesión"
                  : view === "register"
                  ? "Registro"
                  : "Recuperar contraseña"}
              </h2>
              <p className="text-gray-500 text-sm mb-6">
                {view === "recover"
                  ? "Introduce tu correo y te enviaremos las instrucciones."
                  : "Accede a tu cuenta para gestionar tus presupuestos y facturas."}
              </p>

              <div className="space-y-4">
                <Input
                  type="email"
                  placeholder={view === "recover" ? "Correo" : "Email"}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="h-11"
                  data-testid="input-email"
                />
                {view !== "recover" && (
                  <Input
                    type="password"
                    placeholder="Contraseña"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="h-11"
                    data-testid="input-password"
                  />
                )}
              </div>

              <Button
                type="submit"
                className="w-full mt-6 h-11 bg-[#F25075] hover:bg-[#d9446a] text-white font-semibold"
                data-testid="button-submit-auth"
              >
                {view === "login"
                  ? "Entrar"
                  : view === "register"
                  ? "Crear cuenta"
                  : "Recuperar contraseña"}
              </Button>

              {view === "login" && (
                <>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full mt-3 h-11 border-[#3F4694] text-[#3F4694] font-semibold"
                    onClick={() => setView("register")}
                    data-testid="button-go-register"
                  >
                    Crear cuenta
                  </Button>
                  <button
                    type="button"
                    className="w-full mt-3 text-sm text-gray-400 hover:text-[#3F4694]"
                    onClick={() => setView("recover")}
                    data-testid="button-go-recover"
                  >
                    ¿Has olvidado la contraseña?
                  </button>
                </>
              )}

              {view === "register" && (
                <button
                  type="button"
                  className="w-full mt-3 text-sm text-gray-400 hover:text-[#3F4694]"
                  onClick={() => setView("login")}
                  data-testid="button-go-login"
                >
                  Iniciar sesión
                </button>
              )}

              {view === "recover" && (
                <div className="flex flex-col items-center mt-4 gap-1">
                  <button
                    type="button"
                    className="text-sm text-gray-400 hover:text-[#3F4694]"
                    onClick={() => setView("login")}
                  >
                    Iniciar sesión
                  </button>
                  <button
                    type="button"
                    className="text-sm text-gray-400 hover:text-[#3F4694]"
                    onClick={() => setView("register")}
                  >
                    Crear cuenta
                  </button>
                </div>
              )}
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
