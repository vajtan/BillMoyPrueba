import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useState } from "react";
import { Search, ChevronDown, ChevronUp, AlertCircle } from "lucide-react";
import type { Document, Client } from "@shared/schema";
import { RowActions, useDocumentActions } from "@/components/row-actions";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const statusLabels: Record<string, string> = {
  paid: "Cobrada",
  sent: "Pendiente",
  draft: "Borrador",
  partial: "Parcial",
  archived: "Archivada",
};
const statusColors: Record<string, string> = {
  paid: "bg-green-100 text-green-700",
  sent: "bg-blue-100 text-blue-700",
  draft: "bg-gray-100 text-gray-500",
  partial: "bg-orange-100 text-orange-700",
  archived: "bg-gray-200 text-gray-500",
};

export default function Facturas() {
  const [tab, setTab] = useState("all");
  const [search, setSearch] = useState("");
  const [createOpen, setCreateOpen] = useState(false);
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: allDocs = [] } = useQuery<Document[]>({
    queryKey: ["/api/documents"],
  });
  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
  });
  const docs = allDocs.filter((d) => d.type === "invoice");
  const { data: stats } = useQuery<any>({ queryKey: ["/api/dashboard/stats"] });

  const clientMap = new Map(clients.map((c) => [c.id, c.name]));

  const filtered = docs
    .filter((d) => {
      if (tab === "drafts") return d.status === "draft";
      if (tab === "recurring") return false;
      if (tab === "archived") return d.status === "archived";
      return d.status !== "archived";
    })
    .filter((d) => {
      if (!search) return true;
      const clientName = clientMap.get(d.clientId || 0) || "";
      return (
        (d.number || "").toLowerCase().includes(search.toLowerCase()) ||
        clientName.toLowerCase().includes(search.toLowerCase())
      );
    });

  const handleDuplicate = async (doc: Document) => {
    const { id, ...rest } = doc;
    const numDocs = docs.length;
    await apiRequest("POST", "/api/documents", {
      ...rest,
      number: `FAC-${String(numDocs + 1).padStart(4, "0")}`,
      status: "draft",
    });
    queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
    toast({ title: "Factura duplicada", description: "Se ha creado un borrador de la factura." });
  };

  const handleDelete = async (id: number) => {
    await apiRequest("DELETE", `/api/documents/${id}`);
    queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
    queryClient.invalidateQueries({ queryKey: ["/api/dashboard/stats"] });
    toast({ title: "Factura eliminada" });
  };

  const handleArchive = async (doc: Document) => {
    await apiRequest("PATCH", `/api/documents/${doc.id}`, {
      status: doc.status === "archived" ? "draft" : "archived",
    });
    queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
    toast({ title: doc.status === "archived" ? "Factura restaurada" : "Factura archivada" });
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6" style={{ color: "#3F4694" }} data-testid="text-page-title">
        Facturas
      </h1>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-100">
          {/* Tabs */}
          <div className="flex items-center justify-between px-5 pt-4">
            <div className="flex gap-4">
              {[
                { key: "all", label: "Facturas" },
                { key: "recurring", label: "Recurrentes" },
                { key: "drafts", label: "Borradores" },
                { key: "archived", label: "Archivadas" },
              ].map((t) => (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={`text-sm pb-2 transition-colors ${
                    tab === t.key
                      ? "text-[#3F4694] font-semibold border-b-2 border-[#3F4694]"
                      : "text-gray-400 hover:text-gray-600"
                  }`}
                  data-testid={`tab-${t.key}`}
                >
                  {t.label}
                </button>
              ))}
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 pr-3 py-1.5 text-sm border rounded-md w-40"
                data-testid="input-search"
              />
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b text-gray-400 text-left">
                  <th className="px-5 py-3 font-medium">Nombre</th>
                  <th className="px-3 py-3 font-medium">N° de Factura</th>
                  <th className="px-3 py-3 font-medium">Fecha</th>
                  <th className="px-3 py-3 font-medium">Vencimiento</th>
                  <th className="px-3 py-3 font-medium">Total</th>
                  <th className="px-3 py-3 font-medium">Estado</th>
                  <th className="px-3 py-3 w-12"></th>
                </tr>
              </thead>
              <tbody>
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={7} className="px-5 py-12 text-center">
                      <AlertCircle className="w-10 h-10 text-gray-300 mx-auto mb-2" />
                      <p className="text-sm text-gray-400">No hay facturas todavía.</p>
                      <p className="text-xs text-gray-400 mt-1">Crea tu primera factura para empezar.</p>
                    </td>
                  </tr>
                )}
                {filtered.map((doc) => (
                  <tr
                    key={doc.id}
                    className="border-b border-gray-50 hover:bg-gray-50/50 transition-colors"
                    data-testid={`row-invoice-${doc.id}`}
                  >
                    <td className="px-5 py-3 text-gray-700 font-medium">
                      <Link href={`/facturas/${doc.id}`}>
                        <span className="cursor-pointer hover:text-[#3F4694]">
                          {clientMap.get(doc.clientId || 0) || "Sin cliente"}
                        </span>
                      </Link>
                    </td>
                    <td className="px-3 py-3 text-gray-600">{doc.number || "—"}</td>
                    <td className="px-3 py-3 text-gray-600">{doc.issueDate || "—"}</td>
                    <td className="px-3 py-3 text-gray-600">{doc.dueDate || "—"}</td>
                    <td className="px-3 py-3 text-gray-700 font-semibold">
                      {Number(doc.total).toLocaleString("es-ES", { minimumFractionDigits: 2 })} €
                    </td>
                    <td className="px-3 py-3">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${
                          statusColors[doc.status] || "bg-gray-100 text-gray-500"
                        }`}
                      >
                        {statusLabels[doc.status] || doc.status}
                      </span>
                    </td>
                    <td className="px-3 py-3">
                      <RowActions
                        actions={useDocumentActions({
                          onView: () => navigate(`/facturas/${doc.id}`),
                          onEdit: () => navigate(`/facturas/${doc.id}`),
                          onDuplicate: () => handleDuplicate(doc),
                          onDelete: () => handleDelete(doc.id),
                          onArchive: () => handleArchive(doc),
                        })}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {filtered.length > 0 && (
            <div className="flex items-center justify-between px-5 py-3 text-sm text-gray-400 border-t border-gray-50">
              <span>{filtered.length} factura{filtered.length !== 1 ? "s" : ""}</span>
            </div>
          )}
        </div>

        {/* Right sidebar */}
        <div className="space-y-4">
          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <button
              onClick={() => setCreateOpen(!createOpen)}
              className="flex items-center justify-between w-full text-sm font-semibold text-[#3F4694]"
              data-testid="button-create-invoice"
            >
              Crear factura
              {createOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
            {createOpen && (
              <div className="mt-3 space-y-2 border-t pt-3">
                <Link href="/facturas/nueva">
                  <div className="flex items-center gap-2 text-sm text-gray-600 hover:text-[#3F4694] cursor-pointer py-1">
                    Factura normal
                  </div>
                </Link>
                <Link href="/facturas/nueva">
                  <div className="flex items-center gap-2 text-sm text-gray-600 hover:text-[#F25075] cursor-pointer py-1 font-semibold">
                    Factura<span className="text-[#F25075]">PLUS</span>
                  </div>
                </Link>
              </div>
            )}
          </div>

          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="text-sm font-bold text-[#F25075]">Personalizar plantilla</h4>
            <p className="text-xs text-gray-500 mt-1">
              Prepara la plantilla una vez, y olvídate <span className="font-semibold">para siempre</span>.
            </p>
            <Link href="/presupuestos/max/nuevo">
              <button className="mt-3 px-4 py-1.5 bg-[#F25075] text-white text-xs font-semibold rounded-md hover:bg-[#d9446a]" data-testid="button-define-style">
                Define tu estilo
              </button>
            </Link>
          </div>

          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="text-sm font-semibold text-gray-700">Total facturado</h4>
            <p className="text-lg font-bold text-[#F25075]" data-testid="text-total-facturado">
              {stats ? Number(stats.totalInvoiced).toLocaleString("es-ES", { minimumFractionDigits: 2 }) : "0,00"} €
            </p>
          </div>

          <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-100">
            <h4 className="text-sm font-semibold text-gray-700">Número de Facturas</h4>
            <p className="text-lg font-bold text-[#3F4694]" data-testid="text-invoice-count">
              {stats?.invoiceCount || 0}
            </p>
            {(stats?.invoiceCount || 0) > 0 && (
              <>
                <div className="mt-2 flex items-center gap-2">
                  <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[#3F4694] rounded-full"
                      style={{ width: `${stats?.invoiceCount ? (stats.paidInvoices / stats.invoiceCount * 100) : 0}%` }}
                    />
                  </div>
                </div>
                <div className="flex gap-4 mt-2 text-xs">
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-[#3F4694]" /> Cobradas ({stats?.paidInvoices || 0})
                  </span>
                  <span className="flex items-center gap-1">
                    <span className="w-2 h-2 rounded-full bg-[#F25075]" /> Pendientes ({stats?.pendingInvoices || 0})
                  </span>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
