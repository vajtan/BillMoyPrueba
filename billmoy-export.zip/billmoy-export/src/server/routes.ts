import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(server: Server, app: Express) {
  // ── Auth ──
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    const user = await storage.getUserByEmail(email);
    if (!user || user.password !== password) {
      return res.status(401).json({ error: "Credenciales incorrectas" });
    }
    res.json({ id: user.id, name: user.name, email: user.email });
  });

  app.post("/api/auth/register", async (req, res) => {
    const { name, email, password } = req.body;
    const existing = await storage.getUserByEmail(email);
    if (existing) return res.status(400).json({ error: "Email ya registrado" });
    const user = await storage.createUser({ name, email, password });
    res.json({ id: user.id, name: user.name, email: user.email });
  });

  // ── Brand Settings ──
  app.get("/api/brand-settings/:userId", async (req, res) => {
    const bs = await storage.getBrandSettings(Number(req.params.userId));
    res.json(bs || null);
  });

  app.put("/api/brand-settings", async (req, res) => {
    const bs = await storage.upsertBrandSettings(req.body);
    res.json(bs);
  });

  // ── Clients ──
  app.get("/api/clients", async (req, res) => {
    const userId = Number(req.query.userId) || 1;
    res.json(await storage.getClients(userId));
  });

  app.get("/api/clients/:id", async (req, res) => {
    const client = await storage.getClient(Number(req.params.id));
    if (!client) return res.status(404).json({ error: "Not found" });
    res.json(client);
  });

  app.post("/api/clients", async (req, res) => {
    const client = await storage.createClient(req.body);
    res.json(client);
  });

  app.patch("/api/clients/:id", async (req, res) => {
    const client = await storage.updateClient(Number(req.params.id), req.body);
    if (!client) return res.status(404).json({ error: "Not found" });
    res.json(client);
  });

  app.delete("/api/clients/:id", async (req, res) => {
    await storage.deleteClient(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Products ──
  app.get("/api/products", async (req, res) => {
    const userId = Number(req.query.userId) || 1;
    res.json(await storage.getProducts(userId));
  });

  app.post("/api/products", async (req, res) => {
    const product = await storage.createProduct(req.body);
    res.json(product);
  });

  app.patch("/api/products/:id", async (req, res) => {
    const product = await storage.updateProduct(Number(req.params.id), req.body);
    if (!product) return res.status(404).json({ error: "Not found" });
    res.json(product);
  });

  app.delete("/api/products/:id", async (req, res) => {
    await storage.deleteProduct(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Documents ──
  app.get("/api/documents", async (req, res) => {
    const userId = Number(req.query.userId) || 1;
    const type = req.query.type as string | undefined;
    res.json(await storage.getDocuments(userId, type));
  });

  app.get("/api/documents/:id", async (req, res) => {
    const doc = await storage.getDocument(Number(req.params.id));
    if (!doc) return res.status(404).json({ error: "Not found" });
    res.json(doc);
  });

  app.post("/api/documents", async (req, res) => {
    const doc = await storage.createDocument(req.body);
    res.json(doc);
  });

  app.patch("/api/documents/:id", async (req, res) => {
    const doc = await storage.updateDocument(Number(req.params.id), req.body);
    if (!doc) return res.status(404).json({ error: "Not found" });
    res.json(doc);
  });

  app.delete("/api/documents/:id", async (req, res) => {
    await storage.deleteDocument(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Line Items ──
  app.get("/api/line-items/:documentId", async (req, res) => {
    res.json(await storage.getLineItems(Number(req.params.documentId)));
  });

  app.post("/api/line-items", async (req, res) => {
    const item = await storage.createLineItem(req.body);
    res.json(item);
  });

  app.patch("/api/line-items/:id", async (req, res) => {
    const item = await storage.updateLineItem(Number(req.params.id), req.body);
    if (!item) return res.status(404).json({ error: "Not found" });
    res.json(item);
  });

  app.delete("/api/line-items/:id", async (req, res) => {
    await storage.deleteLineItem(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Max Pages ──
  app.get("/api/max-pages/:documentId", async (req, res) => {
    res.json(await storage.getMaxPages(Number(req.params.documentId)));
  });

  app.post("/api/max-pages", async (req, res) => {
    const page = await storage.createMaxPage(req.body);
    res.json(page);
  });

  app.patch("/api/max-pages/:id", async (req, res) => {
    const page = await storage.updateMaxPage(Number(req.params.id), req.body);
    if (!page) return res.status(404).json({ error: "Not found" });
    res.json(page);
  });

  app.delete("/api/max-pages/:id", async (req, res) => {
    await storage.deleteMaxPage(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Max Blocks ──
  app.get("/api/max-blocks/:pageId", async (req, res) => {
    res.json(await storage.getMaxBlocks(Number(req.params.pageId)));
  });

  app.post("/api/max-blocks", async (req, res) => {
    const block = await storage.createMaxBlock(req.body);
    res.json(block);
  });

  app.patch("/api/max-blocks/:id", async (req, res) => {
    const block = await storage.updateMaxBlock(Number(req.params.id), req.body);
    if (!block) return res.status(404).json({ error: "Not found" });
    res.json(block);
  });

  app.delete("/api/max-blocks/:id", async (req, res) => {
    await storage.deleteMaxBlock(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Expenses ──
  app.get("/api/expenses", async (req, res) => {
    const userId = Number(req.query.userId) || 1;
    res.json(await storage.getExpenses(userId));
  });

  app.post("/api/expenses", async (req, res) => {
    const expense = await storage.createExpense(req.body);
    res.json(expense);
  });

  app.patch("/api/expenses/:id", async (req, res) => {
    const expense = await storage.updateExpense(Number(req.params.id), req.body);
    if (!expense) return res.status(404).json({ error: "Not found" });
    res.json(expense);
  });

  app.delete("/api/expenses/:id", async (req, res) => {
    await storage.deleteExpense(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Portfolio Items ──
  app.get("/api/portfolio", async (req, res) => {
    const userId = Number(req.query.userId) || 1;
    res.json(await storage.getPortfolioItems(userId));
  });

  app.post("/api/portfolio", async (req, res) => {
    const item = await storage.createPortfolioItem(req.body);
    res.json(item);
  });

  app.delete("/api/portfolio/:id", async (req, res) => {
    await storage.deletePortfolioItem(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Contract Templates ──
  app.get("/api/contract-templates", async (req, res) => {
    const userId = Number(req.query.userId) || 1;
    res.json(await storage.getContractTemplates(userId));
  });

  app.post("/api/contract-templates", async (req, res) => {
    const template = await storage.createContractTemplate(req.body);
    res.json(template);
  });

  app.delete("/api/contract-templates/:id", async (req, res) => {
    await storage.deleteContractTemplate(Number(req.params.id));
    res.json({ ok: true });
  });

  // ── Dashboard Stats ──
  app.get("/api/dashboard/stats", async (req, res) => {
    const userId = Number(req.query.userId) || 1;
    const docs = await storage.getDocuments(userId);
    const expenses = await storage.getExpenses(userId);

    const invoices = docs.filter(d => d.type === "invoice");
    const totalInvoiced = invoices.reduce((sum, d) => sum + Number(d.total || 0), 0);
    const totalExpenses = expenses.reduce((sum, e) => sum + Number(e.amount || 0), 0);
    const taxRepercutidos = invoices.reduce((sum, d) => sum + Number(d.taxTotal || 0), 0);
    const taxSoportados = expenses.reduce((sum, e) => sum + Number(e.taxAmount || 0), 0);

    const paidInvoices = invoices.filter(d => d.status === "paid").length;
    const pendingInvoices = invoices.filter(d => d.status !== "paid" && d.status !== "draft").length;

    const quotes = docs.filter(d => d.type === "quote_normal" || d.type === "quote_max");
    const totalQuoted = quotes.reduce((sum, d) => sum + Number(d.total || 0), 0);
    const acceptedQuotes = quotes.filter(d => d.status === "accepted").length;
    const pendingQuotes = quotes.filter(d => d.status !== "accepted" && d.status !== "draft").length;

    res.json({
      totalInvoiced: totalInvoiced.toFixed(2),
      totalExpenses: totalExpenses.toFixed(2),
      taxRepercutidos: taxRepercutidos.toFixed(2),
      taxSoportados: taxSoportados.toFixed(2),
      invoiceCount: invoices.length,
      paidInvoices,
      pendingInvoices,
      quoteCount: quotes.length,
      totalQuoted: totalQuoted.toFixed(2),
      acceptedQuotes,
      pendingQuotes,
      recentDocuments: docs.slice(-6).reverse(),
      monthlyData: [
        { month: "ENE", ingresos: 0, gastos: 0 },
        { month: "FEB", ingresos: 0, gastos: 0 },
        { month: "MAR", ingresos: 0, gastos: 0 },
        { month: "ABR", ingresos: 0, gastos: 0 },
        { month: "MAY", ingresos: 0, gastos: 0 },
        { month: "JUN", ingresos: 0, gastos: 0 },
      ],
    });
  });
}
