import {
  type User, type InsertUser,
  type BrandSettings, type InsertBrandSettings,
  type Client, type InsertClient,
  type Product, type InsertProduct,
  type PortfolioItem, type InsertPortfolioItem,
  type ContractTemplate, type InsertContractTemplate,
  type Document, type InsertDocument,
  type DocumentLineItem, type InsertDocumentLineItem,
  type MaxDocumentPage, type InsertMaxDocumentPage,
  type MaxBlock, type InsertMaxBlock,
  type Expense, type InsertExpense,
} from "@shared/schema";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Brand Settings
  getBrandSettings(userId: number): Promise<BrandSettings | undefined>;
  upsertBrandSettings(settings: InsertBrandSettings): Promise<BrandSettings>;

  // Clients
  getClients(userId: number): Promise<Client[]>;
  getClient(id: number): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: number, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: number): Promise<void>;

  // Products
  getProducts(userId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<void>;

  // Portfolio Items
  getPortfolioItems(userId: number): Promise<PortfolioItem[]>;
  createPortfolioItem(item: InsertPortfolioItem): Promise<PortfolioItem>;
  deletePortfolioItem(id: number): Promise<void>;

  // Contract Templates
  getContractTemplates(userId: number): Promise<ContractTemplate[]>;
  createContractTemplate(template: InsertContractTemplate): Promise<ContractTemplate>;
  deleteContractTemplate(id: number): Promise<void>;

  // Documents
  getDocuments(userId: number, type?: string): Promise<Document[]>;
  getDocument(id: number): Promise<Document | undefined>;
  createDocument(doc: InsertDocument): Promise<Document>;
  updateDocument(id: number, doc: Partial<InsertDocument>): Promise<Document | undefined>;
  deleteDocument(id: number): Promise<void>;

  // Document Line Items
  getLineItems(documentId: number): Promise<DocumentLineItem[]>;
  createLineItem(item: InsertDocumentLineItem): Promise<DocumentLineItem>;
  updateLineItem(id: number, item: Partial<InsertDocumentLineItem>): Promise<DocumentLineItem | undefined>;
  deleteLineItem(id: number): Promise<void>;

  // Max Document Pages
  getMaxPages(documentId: number): Promise<MaxDocumentPage[]>;
  createMaxPage(page: InsertMaxDocumentPage): Promise<MaxDocumentPage>;
  updateMaxPage(id: number, page: Partial<InsertMaxDocumentPage>): Promise<MaxDocumentPage | undefined>;
  deleteMaxPage(id: number): Promise<void>;

  // Max Blocks
  getMaxBlocks(pageId: number): Promise<MaxBlock[]>;
  createMaxBlock(block: InsertMaxBlock): Promise<MaxBlock>;
  updateMaxBlock(id: number, block: Partial<InsertMaxBlock>): Promise<MaxBlock | undefined>;
  deleteMaxBlock(id: number): Promise<void>;

  // Expenses
  getExpenses(userId: number): Promise<Expense[]>;
  createExpense(expense: InsertExpense): Promise<Expense>;
  updateExpense(id: number, expense: Partial<InsertExpense>): Promise<Expense | undefined>;
  deleteExpense(id: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private brandSettings: Map<number, BrandSettings> = new Map();
  private clientsMap: Map<number, Client> = new Map();
  private productsMap: Map<number, Product> = new Map();
  private portfolioItemsMap: Map<number, PortfolioItem> = new Map();
  private contractTemplatesMap: Map<number, ContractTemplate> = new Map();
  private documentsMap: Map<number, Document> = new Map();
  private lineItemsMap: Map<number, DocumentLineItem> = new Map();
  private maxPagesMap: Map<number, MaxDocumentPage> = new Map();
  private maxBlocksMap: Map<number, MaxBlock> = new Map();
  private expensesMap: Map<number, Expense> = new Map();
  private nextId: Record<string, number> = {};

  constructor() {
    this.seedData();
  }

  private getId(entity: string): number {
    if (!this.nextId[entity]) this.nextId[entity] = 1;
    return this.nextId[entity]++;
  }

  private seedData() {
    // Demo user
    const user: User = { id: this.getId("user"), name: "Demo Studio", email: "demo@billmoy.com", password: "demo123" };
    this.users.set(user.id, user);

    // Brand settings
    const brand: BrandSettings = {
      id: this.getId("brand"), userId: user.id, logoUrl: null,
      primaryColor: "#3F4694", accentColor: "#F25075", backgroundColor: "#FBFBFB",
      fontFamily: "Catamaran", defaultOrientation: "portrait",
      companyName: "Demo Studio SL", taxId: "B12345678",
      address: "Calle Mayor 10", city: "Madrid", province: "Madrid",
      country: "España", zipCode: "28001", phone: "+34 600 000 000",
    };
    this.brandSettings.set(brand.userId, brand);

    // Seed clients
    const clientNames = [
      { name: "Owlotech Progres SL", sector: "Tecnología", email: "info@owlotech.com", phone: "+34 965 588 84" },
      { name: "Cafetería La Nube", sector: "Hostelería", email: "hola@lanube.com", phone: "+34 911 234 567" },
      { name: "Estudio Azul", sector: "Diseño", email: "contacto@estudioazul.es", phone: "+34 622 333 444" },
      { name: "Reformas Martínez", sector: "Construcción", email: "info@reformasmartinez.com", phone: "+34 655 777 888" },
      { name: "Laura Gómez Fotografía", sector: "Fotografía", email: "laura@lauragomez.com", phone: "+34 677 111 222" },
    ];
    clientNames.forEach(c => {
      const client: Client = {
        id: this.getId("client"), userId: user.id, name: c.name, taxId: "X7682389N",
        address: "Dirección", city: "Ciudad Real", province: "Ciudad Real",
        country: "España", zipCode: "13001", phone: c.phone, email: c.email,
        sector: c.sector, notes: null, imageUrl: null,
      };
      this.clientsMap.set(client.id, client);
    });

    // Seed products
    const prods = [
      { name: "Diseño de logotipo", price: "800", cat: "Branding" },
      { name: "Manual de marca", price: "1200", cat: "Branding" },
      { name: "Diseño web corporativa", price: "3500", cat: "Web" },
      { name: "Fotografía de producto", price: "450", cat: "Fotografía" },
      { name: "Diseño de catálogo", price: "1500", cat: "Editorial" },
      { name: "Community Management mensual", price: "600", cat: "RRSS" },
    ];
    prods.forEach(p => {
      const product: Product = {
        id: this.getId("product"), userId: user.id, name: p.name,
        description: `Servicio de ${p.name.toLowerCase()}`, basePrice: p.price,
        taxRate: "21", category: p.cat, isService: true,
      };
      this.productsMap.set(product.id, product);
    });

    // No seed documents — start empty
    // No seed expenses — start empty
  }

  // Users
  async getUser(id: number) { return this.users.get(id); }
  async getUserByEmail(email: string) { return [...this.users.values()].find(u => u.email === email); }
  async createUser(user: InsertUser) {
    const u: User = { id: this.getId("user"), ...user };
    this.users.set(u.id, u);
    return u;
  }

  // Brand Settings
  async getBrandSettings(userId: number) { return this.brandSettings.get(userId); }
  async upsertBrandSettings(settings: InsertBrandSettings) {
    const existing = this.brandSettings.get(settings.userId);
    if (existing) {
      const updated = { ...existing, ...settings };
      this.brandSettings.set(settings.userId, updated);
      return updated;
    }
    const bs: BrandSettings = { id: this.getId("brand"), ...settings };
    this.brandSettings.set(settings.userId, bs);
    return bs;
  }

  // Clients
  async getClients(userId: number) { return [...this.clientsMap.values()].filter(c => c.userId === userId); }
  async getClient(id: number) { return this.clientsMap.get(id); }
  async createClient(client: InsertClient) {
    const c: Client = { id: this.getId("client"), ...client };
    this.clientsMap.set(c.id, c);
    return c;
  }
  async updateClient(id: number, data: Partial<InsertClient>) {
    const c = this.clientsMap.get(id);
    if (!c) return undefined;
    const updated = { ...c, ...data };
    this.clientsMap.set(id, updated);
    return updated;
  }
  async deleteClient(id: number) { this.clientsMap.delete(id); }

  // Products
  async getProducts(userId: number) { return [...this.productsMap.values()].filter(p => p.userId === userId); }
  async getProduct(id: number) { return this.productsMap.get(id); }
  async createProduct(product: InsertProduct) {
    const p: Product = { id: this.getId("product"), ...product };
    this.productsMap.set(p.id, p);
    return p;
  }
  async updateProduct(id: number, data: Partial<InsertProduct>) {
    const p = this.productsMap.get(id);
    if (!p) return undefined;
    const updated = { ...p, ...data };
    this.productsMap.set(id, updated);
    return updated;
  }
  async deleteProduct(id: number) { this.productsMap.delete(id); }

  // Portfolio Items
  async getPortfolioItems(userId: number) { return [...this.portfolioItemsMap.values()].filter(p => p.userId === userId); }
  async createPortfolioItem(item: InsertPortfolioItem) {
    const p: PortfolioItem = { id: this.getId("portfolio"), ...item };
    this.portfolioItemsMap.set(p.id, p);
    return p;
  }
  async deletePortfolioItem(id: number) { this.portfolioItemsMap.delete(id); }

  // Contract Templates
  async getContractTemplates(userId: number) {
    return [...this.contractTemplatesMap.values()].filter(t => t.userId === userId || t.type === "system");
  }
  async createContractTemplate(template: InsertContractTemplate) {
    const t: ContractTemplate = { id: this.getId("contract"), ...template };
    this.contractTemplatesMap.set(t.id, t);
    return t;
  }
  async deleteContractTemplate(id: number) { this.contractTemplatesMap.delete(id); }

  // Documents
  async getDocuments(userId: number, type?: string) {
    return [...this.documentsMap.values()].filter(d => d.userId === userId && (!type || d.type === type));
  }
  async getDocument(id: number) { return this.documentsMap.get(id); }
  async createDocument(doc: InsertDocument) {
    const d: Document = { id: this.getId("doc"), ...doc };
    this.documentsMap.set(d.id, d);
    return d;
  }
  async updateDocument(id: number, data: Partial<InsertDocument>) {
    const d = this.documentsMap.get(id);
    if (!d) return undefined;
    const updated = { ...d, ...data };
    this.documentsMap.set(id, updated);
    return updated;
  }
  async deleteDocument(id: number) { this.documentsMap.delete(id); }

  // Line Items
  async getLineItems(documentId: number) { return [...this.lineItemsMap.values()].filter(li => li.documentId === documentId); }
  async createLineItem(item: InsertDocumentLineItem) {
    const li: DocumentLineItem = { id: this.getId("li"), ...item };
    this.lineItemsMap.set(li.id, li);
    return li;
  }
  async updateLineItem(id: number, data: Partial<InsertDocumentLineItem>) {
    const li = this.lineItemsMap.get(id);
    if (!li) return undefined;
    const updated = { ...li, ...data };
    this.lineItemsMap.set(id, updated);
    return updated;
  }
  async deleteLineItem(id: number) { this.lineItemsMap.delete(id); }

  // Max Pages
  async getMaxPages(documentId: number) {
    return [...this.maxPagesMap.values()].filter(p => p.documentId === documentId).sort((a, b) => a.pageNumber - b.pageNumber);
  }
  async createMaxPage(page: InsertMaxDocumentPage) {
    const p: MaxDocumentPage = { id: this.getId("maxpage"), ...page };
    this.maxPagesMap.set(p.id, p);
    return p;
  }
  async updateMaxPage(id: number, data: Partial<InsertMaxDocumentPage>) {
    const p = this.maxPagesMap.get(id);
    if (!p) return undefined;
    const updated = { ...p, ...data };
    this.maxPagesMap.set(id, updated);
    return updated;
  }
  async deleteMaxPage(id: number) { this.maxPagesMap.delete(id); }

  // Max Blocks
  async getMaxBlocks(pageId: number) {
    return [...this.maxBlocksMap.values()].filter(b => b.pageId === pageId).sort((a, b) => a.position - b.position);
  }
  async createMaxBlock(block: InsertMaxBlock) {
    const b: MaxBlock = { id: this.getId("maxblock"), ...block };
    this.maxBlocksMap.set(b.id, b);
    return b;
  }
  async updateMaxBlock(id: number, data: Partial<InsertMaxBlock>) {
    const b = this.maxBlocksMap.get(id);
    if (!b) return undefined;
    const updated = { ...b, ...data };
    this.maxBlocksMap.set(id, updated);
    return updated;
  }
  async deleteMaxBlock(id: number) { this.maxBlocksMap.delete(id); }

  // Expenses
  async getExpenses(userId: number) { return [...this.expensesMap.values()].filter(e => e.userId === userId); }
  async createExpense(expense: InsertExpense) {
    const e: Expense = { id: this.getId("expense"), ...expense };
    this.expensesMap.set(e.id, e);
    return e;
  }
  async updateExpense(id: number, data: Partial<InsertExpense>) {
    const e = this.expensesMap.get(id);
    if (!e) return undefined;
    const updated = { ...e, ...data };
    this.expensesMap.set(id, updated);
    return updated;
  }
  async deleteExpense(id: number) { this.expensesMap.delete(id); }
}

export const storage = new MemStorage();
